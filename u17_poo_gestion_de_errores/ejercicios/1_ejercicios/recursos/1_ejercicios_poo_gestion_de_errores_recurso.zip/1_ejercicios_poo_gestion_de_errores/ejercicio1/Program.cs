﻿using System;

public class CalculadoraAvanzada
{
    
    public static void Main()
    {
        
    }
}