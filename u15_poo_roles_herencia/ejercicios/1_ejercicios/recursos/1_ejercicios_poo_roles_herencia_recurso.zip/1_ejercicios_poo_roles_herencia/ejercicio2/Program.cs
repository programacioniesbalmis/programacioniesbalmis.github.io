﻿
using System;
using System.Collections.Generic;

namespace Ejercicio2
{
	//TODO: Crea las clases necesarias para implementar el código que se pide en los ejercicios
	public class Program
	{
		static void Main(string[] args)
		{
			GestionCines();
			Console.WriteLine("\nPresiona cualquier tecla para salir...");
			Console.ReadKey();
		}

		//TODO: Implementa el método GestionCines
	}
}

	  