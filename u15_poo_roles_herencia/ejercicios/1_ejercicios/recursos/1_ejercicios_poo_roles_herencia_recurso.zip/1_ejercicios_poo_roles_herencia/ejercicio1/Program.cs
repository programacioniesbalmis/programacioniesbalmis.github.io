﻿
using System;

namespace Ejercicio1
{
	//TODO: Crea las clases necesarias para implementar el enunciado del ejercicio
	public class Program
	{
		static void Main(string[] args)
		{
			GestionHerramientas();
			Console.WriteLine("\nPresiona cualquier tecla para salir...");
			Console.ReadKey();
		}

		//TODO: Implementa el método GestionHerramientas
	}

	
}