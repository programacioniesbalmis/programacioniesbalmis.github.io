﻿
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.CompilerServices;

namespace Ejercicio4
{
    //TODO: Implementa las clases necesarias para cumplimentar el ejercicio4
    public class Program
    {
        //TODO: Crea el método GestionHerramientasPolimorfismo
        static void Main(string[] args)
        {
            GestionHerramientasPolimorfismo();
            Console.WriteLine("\nPresiona cualquier tecla para salir...");
            Console.ReadKey();
        }
    }
}
