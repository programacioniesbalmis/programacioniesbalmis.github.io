﻿
using System;
using System.Collections.Generic;
using System.Linq;

namespace Ejercicio5
{
    //TODO: Implementar las clases necesarias para el ejercicio 5
    public class Program
    {
        static void Main(string[] args)
        {
            GestionAlbergues();

            Console.WriteLine("\nPulse una tecla para continuar...");
            Console.ReadKey();
        }

        //TODO: Crea los métodos necesarios

        public static void GestionAlbergues()
        {
             var albergues = new List<Albergue>
            {
                new AlbergueRural("Montaña Verde", 40, "Granada", "España", 22.00) { Servicios = new List<string>{"Desayuno","Cena","Rutas"} },
                new AlbergueUrbano("City Hostel", 80, "Madrid", "España", 18.00) { Servicios = new List<string>{"WiFi","Lavandería"} },
                new AlbergueCostero("Surf Point", 55, "Tarifa", "España", 20.00) { Servicios = new List<string>{"Clases de surf","Parking"} }
            };
            // Reservas iniciales
            albergues[0].RegistraReserva(3, false);
            albergues[1].RegistraReserva(5, false);
            albergues[2].RegistraReserva(10, false);

            //TODO: Crea el código del menú con las llamadas a los métodos
    
        }

            public static void AñadeAlbergue(List<Albergue> lista)
        {
            Console.Write("Tipo (R=Rural, U=Urbano, C=Costero): ");
            string tipo = Console.ReadLine().Trim().ToUpper();
            Console.Write("Nombre: ");
            string nombre = Console.ReadLine();
            int capacidad = 0;
            do
            {
                Console.Write("Capacidad (>0): ");
                capacidad = int.Parse(Console.ReadLine());
            } while (capacidad <= 0);
            double precioBase = 0;
            do
            {
                Console.Write("Precio base (>0): ");
                precioBase = double.Parse(Console.ReadLine());
            } while (precioBase <= 0);
            Console.Write("Ciudad: ");
            string ciudad = Console.ReadLine();
            Console.Write("País: ");
            string pais = Console.ReadLine();
            Console.Write("Servicios (separados por coma): ");
            string[] servicios = Console.ReadLine().Split(',', StringSplitOptions.RemoveEmptyEntries);

            Albergue nuevo = tipo switch
            {
                "R" => new AlbergueRural(nombre, capacidad, ciudad, pais, precioBase),
                "U" => new AlbergueUrbano(nombre, capacidad, ciudad, pais, precioBase),
                "C" => new AlbergueCostero(nombre, capacidad, ciudad, pais, precioBase),
                _ => null
            };

            if (nuevo != null)
            {
                foreach (var s in servicios) nuevo.AgregaServicio(s);
                lista.Add(nuevo);
                Console.WriteLine($"Albergue '{nombre}' añadido.");
            }
            else Console.WriteLine("Tipo no válido.");
        }

        public static void RegistraReserva(List<Albergue> lista)
        {
            Console.WriteLine("Listado de albergues:");
            for (int i = 0; i < lista.Count; i++)
                Console.WriteLine($" ({i}) {lista[i].Nombre}");
            Console.Write("Elija índice: ");
            int idx = int.Parse(Console.ReadLine());
            Console.Write("Plazas a reservar: ");
            int plazas = int.Parse(Console.ReadLine());
            Console.Write("¿Temporada alta? (S/N): ");
            bool alta = Console.ReadLine().Trim().ToUpper() == "S";
            bool ok = lista[idx].RegistraReserva(plazas, alta);
            string tipo = alta ? "ALTA" : "BAJA";
            string estado = ok ? "ACEPTADA" : "RECHAZADA";
            Console.WriteLine($"[Reserva] {lista[idx].Nombre}: {plazas} plazas ({tipo}) => {estado}. Ocupación ahora {lista[idx].PlazasOcupadas}/{lista[idx].Capacidad} ({lista[idx].PorcentajeOcupacion}%)");
        }

        public static void MuestraEstado(List<Albergue> lista)
        {
            Console.WriteLine("\n=== ESTADO ACTUAL ===");
            foreach (var a in lista)
            {
                Console.WriteLine(a);
            }

        }

        public static void MuestraInfoComplementaria(List<Albergue> lista)
        {
            Console.WriteLine("Información complementaria:");
            foreach (var a in lista)
                Console.WriteLine($"{a.Nombre} => {a.InformacionComplementaria()}");
        }
    }

}
