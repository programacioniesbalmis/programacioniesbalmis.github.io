﻿using System;

namespace Ejercicio4
{

    /// TODO: Define el código necesario para el ejercicio
    public class Program
    {
        ///TODO: Define el código necesario para el ejercicio
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 4. Refactorización con Delegados Genéricos\n");
            ///TODO: Define el código necesario para el ejercicio
            Console.WriteLine("Pulsar una tecla para finalizar...");
            Console.ReadKey(true);

        }
    }

}    