﻿using System;

namespace Ejercicio6
{
    public class Program
    {

        ///TODO: Define el código necesario para el ejercicio
        static void Main()
        {
            Console.WriteLine("Ejercicio 6. Delegados genéricos con múltiples parámetros\n");

           ///TODO: Define el código necesario para el ejercicio

            Console.WriteLine("\nPulsa una tecla para finalizar...");
            Console.ReadKey(true);
        }
    }
}
