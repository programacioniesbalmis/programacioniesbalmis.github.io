﻿using System;

namespace Ejercicio3
{
    public class Principal
    {

        ///TODO: Define el código necesario para el ejercicio 
        public static void Main()
        {

            float[][] mNumeros = new float[][] { new float[] { 3, 4, 5 }, new float[] { 2.4f, 4.4f, 5 } };
            String[][] mPalabras = new String[][] { new String[] { "SAL", "AGUA", "AZUCAR", "VINO" }, new String[] { "COLA", "CAFE", "ZUMO", "LECHE" } };

            Console.WriteLine("Ejercicio 3. Delegado genérico Comparador\n");

            ///TODO: Define el código necesario para el ejercicio
            Console.WriteLine("Pulsar una tecla para finalizar...");
            Console.ReadKey(true);

        }
    }
}
