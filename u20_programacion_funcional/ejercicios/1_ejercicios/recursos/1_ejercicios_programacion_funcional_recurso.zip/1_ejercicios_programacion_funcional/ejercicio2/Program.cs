﻿using System;

namespace Ejercicio2
{
    
    /// TODO: Define el código necesario para implementar el ejercicio
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 2. Delegados con parámetros variados");
            
            // Caso 1: VIP, mucha cantidad
            double importe1 = 1000;
            int cantidad1 = 12;
            bool esVip1 = true;

            Console.WriteLine($"\nPedido 1: Importe={importe1}, Cantidad={cantidad1}, VIP={esVip1}");
            
            Console.WriteLine("-> Usando DescuentoPorCantidad:");
            ///TODO: Llamar a ProcesaPedido con la regla de descuento DescuentoPorCantidad
            Console.WriteLine("-> Usando DescuentoVip:");
           ///TODO: Llamar a ProcesaPedido con la regla de descuento DescuentoVip

            Console.WriteLine("-> Usando DescuentoCombinado:");
            ///TODO: Llamar a ProcesaPedido con la regla de descuento DescuentoCombinado

            // Caso 2: No VIP, poca cantidad
            double importe2 = 500;
            int cantidad2 = 3;
            bool esVip2 = false;

            Console.WriteLine($"\nPedido 2: Importe={importe2}, Cantidad={cantidad2}, VIP={esVip2}");
            
            Console.WriteLine("-> Usando DescuentoPorCantidad:");
            ///TODO: Llamar a ProcesaPedido con la regla de descuento DescuentoPorCantidad
            
            Console.WriteLine("-> Usando DescuentoCombinado:");
            ///TODO: Llamar a ProcesaPedido con la regla de descuento DescuentoCombinado
            Console.WriteLine("Pulsar una tecla para finalizar...");
            Console.ReadKey(true);
        }

       
    }
}
