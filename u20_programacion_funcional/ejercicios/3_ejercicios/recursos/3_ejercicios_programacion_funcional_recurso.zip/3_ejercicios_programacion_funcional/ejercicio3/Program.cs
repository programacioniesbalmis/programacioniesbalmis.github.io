﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Ejercicio3
{
  
    ///TODO: Completar el código del ejercicio aquí
    public class Program
    {
        public static void Main(string[] args)
        {

            Console.WriteLine("Ejercicio 3. Auditoría de Pedidos");

           
            ///TODO: Completar el código del ejercicio aquí
           
            Console.WriteLine("Pulsa una tecla para finalizar...");
           // Console.ReadKey();
        }
    }
}