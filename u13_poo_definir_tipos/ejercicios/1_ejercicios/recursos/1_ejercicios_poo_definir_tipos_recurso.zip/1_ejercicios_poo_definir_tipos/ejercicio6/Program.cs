using System;

//TODO: Implementa la lógica pedida en el ejercicio

public static class Program
{
    public static void Main()
    {
        Console.WriteLine("Ejercicio 6: Diagrama UML con diferentes tipos de definición\n");

        //TODO: Implementa la lógica pedida en el ejercicio
        Console.WriteLine("Pulsa cualquier tecla para continuar...");
        Console.ReadKey();
    }
}
