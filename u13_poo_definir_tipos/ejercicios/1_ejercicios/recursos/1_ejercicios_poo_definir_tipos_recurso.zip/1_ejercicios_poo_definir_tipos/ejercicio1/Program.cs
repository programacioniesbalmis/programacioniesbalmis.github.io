﻿using System;


//TODO: Implementar las clases necesarias para la gestión de empleados

public class Program
{
   

    //TODO: Implementar los métodos necesarios para conseguir la lógica pedida

    static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio 1: Clase Empleado con métodos Get/Set");
        Console.WriteLine();

        //TODO: Implementar la lógica necesaria para gestionar empleados    

        Console.WriteLine("Presiona cualquier tecla para salir...");
        Console.ReadKey();
    }
}
