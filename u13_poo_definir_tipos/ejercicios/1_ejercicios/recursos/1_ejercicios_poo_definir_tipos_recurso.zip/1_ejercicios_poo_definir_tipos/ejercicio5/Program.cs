﻿using System;
//TODO: Implementa la lógica pedida en el ejercicio

public static class Program
{
    //TODO: Implementa la lógica pedida en el ejercicio
    public static void Main()
    {
        Console.WriteLine("Ejercicio 5: Records como Value Objects\n");
        GestionJuguete();
        Console.WriteLine();
        GestionTemperatura();
        Console.WriteLine("Pulsa cualquier tecla para continuar...");
        Console.ReadKey();
    }

    
}
