﻿using System;

public class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("=== Programa para Practicar Depuración ===");
        
        int puntos = 0;
        int nivel = 1;
        double saldo = 1000.0;
        string jugador = "Principiante";
        bool activo = true;
        char categoria = 'C';
        
        Console.WriteLine("=== INICIO DEL JUEGO ===");
        Console.WriteLine($"Jugador: {jugador}");
        Console.WriteLine($"Puntos: {puntos}");
        Console.WriteLine($"Nivel: {nivel}");
        Console.WriteLine($"Saldo: {saldo:C}");
        
        Console.WriteLine("\n--- Fase 1: Completando misiones ---");
        puntos += 50;
        Console.WriteLine($"Misión 1 completada. Puntos: {puntos}");
        
        puntos += 75;
        Console.WriteLine($"Misión 2 completada. Puntos: {puntos}");
        
        puntos += 100;
        Console.WriteLine($"Misión 3 completada. Puntos: {puntos}");
        
        if (puntos >= 200)
        {
            nivel = 3;
            jugador = "Experto";
            categoria = 'A';
        }
        else if (puntos >= 100)
        {
            nivel = 2;
            jugador = "Intermedio";
            categoria = 'B';
        }
        
        Console.WriteLine($"\n¡Subiste de nivel! Ahora eres: {jugador}");
        Console.WriteLine($"Nivel actual: {nivel}");
        Console.WriteLine($"Categoría: {categoria}");
        
        Console.WriteLine("\n--- Fase 2: Comprando mejoras ---");
        double costoMejora = 0;
        
        switch (categoria)
        {
            case 'A':
                costoMejora = 300.0;
                break;
            case 'B':
                costoMejora = 200.0;
                break;
            case 'C':
                costoMejora = 100.0;
                break;
        }
        
        Console.WriteLine($"Costo de mejora para categoría {categoria}: {costoMejora:C}");
        
        if (saldo >= costoMejora)
        {
            saldo -= costoMejora;
            puntos += 50;
            Console.WriteLine($"Mejora comprada. Saldo restante: {saldo:C}");
            Console.WriteLine($"Puntos bonus: +50. Total: {puntos}");
        }
        else
        {
            Console.WriteLine("Saldo insuficiente para la mejora");
        }
        
        Console.WriteLine("\n--- Fase 3: Bonificaciones ---");
        int bonificacion = 0;
        double multiplicador = 1.0;
        
        if (nivel >= 3)
        {
            bonificacion = 200;
            multiplicador = 1.5;
        }
        else if (nivel >= 2)
        {
            bonificacion = 100;
            multiplicador = 1.2;
        }
        else
        {
            bonificacion = 50;
            multiplicador = 1.0;
        }
        
        Console.WriteLine($"Bonificación por nivel: {bonificacion}");
        puntos += bonificacion;
        
        saldo *= multiplicador;
        Console.WriteLine($"Multiplicador aplicado: x{multiplicador}");
        Console.WriteLine($"Nuevo saldo: {saldo:C}");

        Console.WriteLine("\n--- Fase 4: Resumen final ---");
        
        if (saldo > 0 && puntos > 0)
        {
            activo = true;
            Console.WriteLine("Estado: ACTIVO");
        }
        else
        {
            activo = false;
            Console.WriteLine("Estado: INACTIVO");
        }
        
        string rendimiento = puntos switch
        {
            >= 400 => "Excelente",
            >= 300 => "Muy bueno",
            >= 200 => "Bueno",
            >= 100 => "Regular",
            _ => "Necesita mejorar"
        };
        
        Console.WriteLine($"Rendimiento: {rendimiento}");
        
        Console.WriteLine("\n=== ESTADÍSTICAS FINALES ===");
        Console.WriteLine($"Jugador: {jugador}");
        Console.WriteLine($"Nivel: {nivel}");
        Console.WriteLine($"Categoría: {categoria}");
        Console.WriteLine($"Puntos totales: {puntos}");
        Console.WriteLine($"Saldo final: {saldo:C}");
        Console.WriteLine($"Estado: {(activo ? "ACTIVO" : "INACTIVO")}");
        Console.WriteLine($"Rendimiento: {rendimiento}");
        
        Console.WriteLine("\nPresione Enter para salir...");
        Console.ReadLine();
    }
}