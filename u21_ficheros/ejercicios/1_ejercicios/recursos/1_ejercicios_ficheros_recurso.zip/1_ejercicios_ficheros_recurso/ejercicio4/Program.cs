using System;
using System.Collections.Generic;
using System.IO;

namespace Ejercicio4
{
    ///Añade la clase Producto con las propiedades Nombre, Precio y Cantidad. Crea una lista de productos y guarda esta lista en un archivo binario. Luego, lee el archivo binario para mostrar los productos en la consola. Finalmente, guarda la lista de productos en un archivo de texto y lee el archivo de texto para mostrar los productos nuevamente en la consola.

    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 4. Gestión de Inventario\n");
            EjecutaGestionInventario();
            Console.WriteLine("Pulsa una tecla para finalizar...");
            Console.ReadKey();
        }

        public static void EjecutaGestionInventario()
        {
            List<Producto> productos = new List<Producto>
            {
                new Producto("Manzana", 0.50, 100),
                new Producto("Pan", 1.20, 50),
                new Producto("Leche", 0.90, 30),
                new Producto("Huevos", 2.50, 20)
            };

            ProcesaBinario(productos);
            ProcesaTexto(productos);
        }

        /// Añade los métodos ProcesaBinario y ProcesaTexto para guardar y leer los productos en archivos binarios y de texto respectivamente.

    }
}
