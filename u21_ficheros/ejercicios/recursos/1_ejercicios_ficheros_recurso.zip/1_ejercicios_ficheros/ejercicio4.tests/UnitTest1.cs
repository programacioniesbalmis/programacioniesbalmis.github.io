﻿using Xunit;
using Ejercicio4;
using System;
using System.IO;
using System.Collections.Generic;

namespace ejercicio4.tests
{
    public class UnitTest1
    {
        [Fact]
        public void ProcesarBinario_EscribeYLeeCorrectamente()
        {
            var productos = new List<Producto>
            {
                new Producto("TestProd", 99.99, 5)
            };
            
            var output = new StringWriter();
            Console.SetOut(output);

            Program.ProcesaBinario(productos);

            Assert.True(File.Exists("inventario.bin"));
            var result = output.ToString();
            Assert.Contains("TestProd", result);
            Assert.Contains("99", result); // Chequeo parcial para evitar problemas de cultura con decimales

            File.Delete("inventario.bin");
        }

        [Fact]
        public void ProcesarTexto_ExportaFormatoCSV()
        {
            var productos = new List<Producto>
            {
                new Producto("CSVProd", 10.5, 20)
            };

            Program.ProcesaTexto(productos);

            Assert.True(File.Exists("inventario.csv"));
            string content = File.ReadAllText("inventario.csv");
            
            // Verificar formato: Nombre;Precio;Stock
            // Nota: 10.5 puede ser 10,5 dependiendo de la cultura del sistema
            Assert.Contains("CSVProd", content);
            Assert.Contains("20", content);
            Assert.Contains(";", content);

            File.Delete("inventario.csv");
        }

        [Fact]
        public void EjecutarGestionInventario_FlujoCompleto()
        {
            var output = new StringWriter();
            Console.SetOut(output);

            Program.EjecutaGestionInventario();

            Assert.True(File.Exists("inventario.bin"));
            Assert.True(File.Exists("inventario.csv"));
            
            // Cleanup
            File.Delete("inventario.bin");
            File.Delete("inventario.csv");
        }
    }
}
