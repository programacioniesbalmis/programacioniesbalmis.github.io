using System;
using System.IO;

namespace Ejercicio2
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 2. Gestión de Archivos y Directorios\n");
            EjecutaGestionArchivos();
            Console.WriteLine("Pulsa una tecla para finalizar...");
            Console.ReadKey();
        }

        public static void EjecutaGestionArchivos()
        {
            //TODO: Completar aquí
        }

        public static void Muestra(string ruta)
        {
           //Muestra los archivos en la ruta dada
        }
    }
}
