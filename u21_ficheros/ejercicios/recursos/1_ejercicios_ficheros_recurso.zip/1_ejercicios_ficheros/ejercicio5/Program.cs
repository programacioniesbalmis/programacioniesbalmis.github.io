using System;
using System.IO;

namespace Ejercicio5
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 5. Diario de Entradas\n");
            GestionaDiario();
            Console.WriteLine("Pulsa una tecla para finalizar...");
            Console.ReadKey();
        }

        public static void GestionaDiario()
        {
            
        }
    }
}
