using System;
using System.IO;

namespace Ejercicio3
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 3. Copia de Ficheros Byte a Byte\n");

            EjecutaCopia();
            Console.WriteLine("Pulsa una tecla para finalizar...");
            Console.ReadKey();
        }

        public static void EjecutaCopia()
        {
           
        }

        public static void GeneraFicheroOrigen(string ruta)
        {
           
        }

        public static void CopiaFichero(string origen, string destino)
        {
           
        }

        public static void VerificaCopia(string destino, string origen)
        {
           
        }
    }
}
