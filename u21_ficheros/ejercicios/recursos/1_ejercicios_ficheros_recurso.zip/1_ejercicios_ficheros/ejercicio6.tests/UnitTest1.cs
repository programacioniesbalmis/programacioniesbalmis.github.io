﻿using Xunit;
using System;
using System.IO;


namespace ejercicio6.Tests
{
    public class GestorArchivosYProcesadorTextoTests
    {
        [Fact]
        public void LeerArchivo_RutaVacia_LanzaArgumentException()
        {
            Assert.Throws<ArgumentException>(() => GestorArchivos.LeerArchivo(""));
        }

        [Fact]
        public void LeerArchivo_ExtensionNoTxt_LanzaNotSupportedException()
        {
            Assert.Throws<NotSupportedException>(() => GestorArchivos.LeerArchivo("archivo.pdf"));
        }

        [Fact]
        public void LeerArchivo_ArchivoNoExiste_LanzaArchivoLecturaException()
        {
            var ex = Assert.Throws<ArchivoLecturaException>(() => GestorArchivos.LeerArchivo("noexiste.txt"));
            Assert.IsType<FileNotFoundException>(ex.InnerException);
        }

        [Fact]
        public void ContarPalabras_TextoVacio_LanzaArgumentException()
        {
            Assert.Throws<ArgumentException>(() => ProcesadorTexto.ContarPalabras(""));
        }

        [Fact]
        public void ContarPalabras_TextoNormal_DevuelveNumeroPalabras()
        {
            string texto = "Hola mundo esto es una prueba";
            int esperado = 6;
            Assert.Equal(esperado, ProcesadorTexto.ContarPalabras(texto));
        }
    }
}