﻿using System;
using System.IO;


public class GestorArchivos
{
    public static string LeerArchivo(string ruta)
    {
        
    }
}

public class ProcesadorTexto
{
    public static int ContarPalabras(string texto)
    {
        
    }
}

class Program
{
    static void Main()
    {
        
            Console.Write("Introduce la ruta del archivo: ");
            string ruta = Console.ReadLine() ?? "";
            string contenido = GestorArchivos.LeerArchivo(ruta);
            int numPalabras = ProcesadorTexto.ContarPalabras(contenido);
            Console.WriteLine($"El archivo tiene {numPalabras} palabras.");
        
    }
}