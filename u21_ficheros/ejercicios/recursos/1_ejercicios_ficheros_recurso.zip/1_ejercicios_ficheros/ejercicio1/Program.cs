using System;
using System.IO;

namespace Ejercicio1
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 1. Jugando con Rutas\n");
            EjecutaEjercicio();
            Console.WriteLine("Pulsa una tecla para finalizar...");
            Console.ReadKey();

        }

        public static void EjecutaEjercicio()
        {


            Console.Write("Introduce nombre de archivo: ");
            string nombreArchivo = Console.ReadLine();

            Console.Write("Introduce nombre de carpeta: ");
            string nombreCarpeta = Console.ReadLine();
            ///TODO: Completar aquí
        }
    }
}
