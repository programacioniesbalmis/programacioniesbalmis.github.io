﻿using Xunit;
using Ejercicio3;
using System;
using System.IO;

namespace ejercicio3.tests
{
    public class UnitTest1
    {
        [Fact]
        public void GenerarFicheroOrigen_CreaFicheroBinario()
        {
            string file = "test_origen.dat";
            if(File.Exists(file)) File.Delete(file);

            Program.GeneraFicheroOrigen(file);

            Assert.True(File.Exists(file));
            Assert.Equal(100, new FileInfo(file).Length);
            
            File.Delete(file);
        }

        [Fact]
        public void CopiarFichero_ReplicaContenidoByteAByte()
        {
            string source = "source_test.dat";
            string dest = "dest_test.dat";
            byte[] data = { 10, 20, 30, 40, 50 };
            
            File.WriteAllBytes(source, data);

            Program.CopiaFichero(source, dest);

            Assert.True(File.Exists(dest));
            byte[] readData = File.ReadAllBytes(dest);
            Assert.Equal(data, readData);

            File.Delete(source);
            File.Delete(dest);
        }

        [Fact]
        public void VerificarCopia_ConfirmaIgualdadDeArchivos()
        {
            string source = "source_verify.dat";
            string dest = "dest_verify.dat";
            
            File.WriteAllBytes(source, new byte[50]);
            File.WriteAllBytes(dest, new byte[50]); // Mismo tamaño

            var output = new StringWriter();
            Console.SetOut(output);

            Program.VerificaCopia(dest, source);
            
            Assert.Contains("Verificación exitosa", output.ToString());

            File.Delete(source);
            File.Delete(dest);
        }

        [Fact]
        public void EjecutarCopia_EjecutaFlujoCompleto()
        {
            var output = new StringWriter();
            Console.SetOut(output); // Capturar salida para no ensuciar el test runner log

            Program.EjecutaCopia();

            Assert.True(File.Exists("datos_origen.dat"));
            Assert.True(File.Exists("datos_destino.dat"));
            Assert.Equal(new FileInfo("datos_origen.dat").Length, new FileInfo("datos_destino.dat").Length);

            // Cleanup
            File.Delete("datos_origen.dat");
            File.Delete("datos_destino.dat");
        }
    }
}
