using System;
using System.IO;

namespace Ejercicio1
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 1. Jugando con Rutas\n");
            EjecutarEjercicio();
            Console.WriteLine("Pulsa una tecla para finalizar...");
            Console.ReadKey();

        }

        public static void EjecutarEjercicio()
        {


            Console.Write("Introduce nombre de archivo: ");
            string nombreArchivo = Console.ReadLine();

            Console.Write("Introduce nombre de carpeta: ");
            string nombreCarpeta = Console.ReadLine();

            string rutaCombinada = Path.Combine(nombreCarpeta, "Documentos", nombreArchivo);
            Console.WriteLine($"Ruta combinada: {rutaCombinada}");

            string extension = Path.GetExtension(nombreArchivo);
            Console.WriteLine($"Extensión: {extension}");

            string nombreSinExtension = Path.GetFileNameWithoutExtension(nombreArchivo);
            Console.WriteLine($"Nombre sin extensión: {nombreSinExtension}");

            string rutaCambiada = Path.ChangeExtension(rutaCombinada, ".bak");
            Console.WriteLine($"Ruta con extensión cambiada: {rutaCambiada}");

            string nombreAleatorio = Path.GetRandomFileName();
            Console.WriteLine($"Nombre aleatorio generado: {nombreAleatorio}");
        }
    }
}
