﻿using Xunit;
using Ejercicio5;
using System;
using System.IO;

namespace ejercicio5.tests
{
    public class UnitTest1
    {
        [Fact]
        public void GestionarDiario_AgregaEntradasYLee()
        {
            // Arrange
            string archivo = "diario.txt";
            if (File.Exists(archivo)) File.Delete(archivo);

            string[] entradas = { "Primera linea", "Segunda linea", "FIN" };
            var input = new StringReader(string.Join(Environment.NewLine, entradas));
            Console.SetIn(input);

            var output = new StringWriter();
            Console.SetOut(output);

            // Act
            Program.GestionaDiario();

            // Assert
            string consola = output.ToString();
            Assert.Contains("Primera linea", consola);
            Assert.Contains("Segunda linea", consola);

            Assert.True(File.Exists(archivo));
            string contenidoArchivo = File.ReadAllText(archivo);
            Assert.Contains("Primera linea", contenidoArchivo);
            
            // Cleanup
            File.Delete(archivo);
        }
    }
}
