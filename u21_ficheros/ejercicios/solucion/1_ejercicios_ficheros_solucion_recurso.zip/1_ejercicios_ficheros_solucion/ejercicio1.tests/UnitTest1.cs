﻿using Xunit;
using Ejercicio1;
using System;
using System.IO;

namespace ejercicio1.tests
{
    public class UnitTest1
    {
        [Fact]
        public void EjecutarEjercicio_VerificaSalidaDeConsola()
        {
            // Arrange
            var input = new StringReader("informe.docx" + Environment.NewLine + "Proyectos" + Environment.NewLine);
            Console.SetIn(input);
            var output = new StringWriter();
            Console.SetOut(output);

            // Act
            Program.EjecutarEjercicio();

            // Assert
            var result = output.ToString();
            
            // Verificamos que contenga las partes esperadas de la ruta
            Assert.Contains("Ruta combinada:", result);
            Assert.Contains("Documentos", result);
            Assert.Contains("informe.docx", result);
            
            Assert.Contains("Extensión: .docx", result);
            Assert.Contains("Nombre sin extensión: informe", result);
            Assert.Contains(".bak", result);
            Assert.Contains("Nombre aleatorio generado:", result);
        }
    }
}
