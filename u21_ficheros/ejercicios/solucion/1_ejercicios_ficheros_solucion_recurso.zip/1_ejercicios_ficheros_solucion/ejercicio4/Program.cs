using System;
using System.Collections.Generic;
using System.IO;

namespace Ejercicio4
{
    public class Producto
    {
        public string Nombre { get; set; }
        public double Precio { get; set; }
        public int Stock { get; set; }

        public Producto(string nombre, double precio, int stock)
        {
            Nombre = nombre;
            Precio = precio;
            Stock = stock;
        }

        public override string ToString()
        {
            return $"Producto: {Nombre}, Precio: {Precio}, Stock: {Stock}";
        }
    }

    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 4. Gestión de Inventario\n");
            EjecutaGestionInventario();
            Console.WriteLine("Pulsa una tecla para finalizar...");
            Console.ReadKey();
        }

        public static void EjecutaGestionInventario()
        {
            List<Producto> productos = new List<Producto>
            {
                new Producto("Manzana", 0.50, 100),
                new Producto("Pan", 1.20, 50),
                new Producto("Leche", 0.90, 30),
                new Producto("Huevos", 2.50, 20)
            };

            ProcesaBinario(productos);
            ProcesaTexto(productos);
        }

        public static void ProcesaBinario(List<Producto> productos)
        {
            string archivoBinario = "inventario.bin";
            
            using (BinaryWriter writer = new BinaryWriter(File.Open(archivoBinario, FileMode.Create)))
            {
                foreach (Producto p in productos)
                {
                    writer.Write(p.Nombre);
                    writer.Write(p.Precio);
                    writer.Write(p.Stock);
                }
            }
            Console.WriteLine($"Datos guardados en {archivoBinario} (Binario).");

            Console.WriteLine("Leyendo datos desde binario:");
            using (BinaryReader reader = new BinaryReader(File.Open(archivoBinario, FileMode.Open)))
            {
                while (reader.BaseStream.Position < reader.BaseStream.Length)
                {
                    string nombre = reader.ReadString();
                    double precio = reader.ReadDouble();
                    int stock = reader.ReadInt32();
                    Console.WriteLine(new Producto(nombre, precio, stock));
                }
            }
        }

        public static void ProcesaTexto(List<Producto> productos)
        {
            string archivoCsv = "inventario.csv";

            using (StreamWriter writer = new StreamWriter(archivoCsv))
            {
                foreach (Producto p in productos)
                {
                    writer.WriteLine($"{p.Nombre};{p.Precio};{p.Stock}");
                }
            }
            Console.WriteLine($"Datos exportados a {archivoCsv} (CSV).");
        }
    }
}
