﻿using Xunit;
using Ejercicio2;
using System;
using System.IO;

namespace ejercicio2.tests
{
    public class UnitTest1
    {
        [Fact]
        public void EjecutarGestionArchivos_RealizaOperacionesYBorrado()
        {
            // Arrange
            // Simulamos input 'S' para borrar al final y dejar limpio el entorno
            var input = new StringReader("S" + Environment.NewLine);
            Console.SetIn(input);
            var output = new StringWriter();
            Console.SetOut(output);

            // Asegurarse de que no existe previamente para evitar errores
            if (Directory.Exists("Laboratorio"))
            {
                Directory.Delete("Laboratorio", true);
            }

            // Act
            Program.EjecutarGestionArchivos();

            // Assert
            var result = output.ToString();
            Assert.Contains("Carpeta Laboratorio creada", result);
            Assert.Contains("Subcarpetas Originales y Copias creadas", result);
            Assert.Contains("Fichero mensaje.txt creado", result);
            Assert.Contains("Fichero copiado", result);
            Assert.Contains("Fichero original movido", result);
            Assert.Contains("Archivos en Copias:", result);
            Assert.Contains("Laboratorio y contenido eliminados", result);

            // Verificamos que se haya borrado
            Assert.False(Directory.Exists("Laboratorio"));
        }

        [Fact]
        public void MostrarArchivos_ListaArchivosEnDirectorio()
        {
            // Arrange
            string testDir = "TestDir_MostrarArchivos";
            Directory.CreateDirectory(testDir);
            File.WriteAllText(Path.Combine(testDir, "archivo1.txt"), "contenido");
            File.WriteAllText(Path.Combine(testDir, "archivo2.log"), "contenido");
            
            var output = new StringWriter();
            Console.SetOut(output);

            // Act
            Program.MostrarArchivos(testDir);

            // Assert
            var result = output.ToString();
            Assert.Contains("archivo1.txt", result);
            Assert.Contains("archivo2.log", result);

            // Cleanup
            Directory.Delete(testDir, true);
        }
    }
}
