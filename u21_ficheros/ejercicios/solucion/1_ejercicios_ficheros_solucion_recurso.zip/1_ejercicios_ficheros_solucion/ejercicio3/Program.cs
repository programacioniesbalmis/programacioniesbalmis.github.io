using System;
using System.IO;

namespace Ejercicio3
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 3. Copia de Ficheros Byte a Byte\n");

            EjecutaCopia();
            Console.WriteLine("Pulsa una tecla para finalizar...");
            Console.ReadKey();
        }

        public static void EjecutaCopia()
        {
            string origen = "datos_origen.dat";
            string destino = "datos_destino.dat";

            GeneraFicheroOrigen(origen);
            Console.WriteLine($"Fichero {origen} creado con 100 bytes aleatorios.");

            CopiaFichero(origen, destino);
            Console.WriteLine("Copia finalizada.");

            VerificaCopia(destino, origen);
        }

        public static void GeneraFicheroOrigen(string ruta)
        {
            byte[] datos = new byte[100];
            new Random().NextBytes(datos);
            File.WriteAllBytes(ruta, datos);
        }

        public static void CopiaFichero(string origen, string destino)
        {
            using (FileStream fsOrigen = new FileStream(origen, FileMode.Open, FileAccess.Read))
            using (FileStream fsDestino = new FileStream(destino, FileMode.Create, FileAccess.Write))
            {
                int byteLeido;
                while ((byteLeido = fsOrigen.ReadByte()) != -1)
                {
                    fsDestino.WriteByte((byte)byteLeido);
                }
            }
        }

        public static void VerificaCopia(string destino, string origen)
        {
            if (File.Exists(destino))
            {
                long tamanoOrigen = new FileInfo(origen).Length;
                long tamanoDestino = new FileInfo(destino).Length;

                if (tamanoOrigen == tamanoDestino)
                {
                    Console.WriteLine($"Verificación exitosa: {destino} existe y tiene el mismo tamaño ({tamanoDestino} bytes).");
                }
                else
                {
                    Console.WriteLine("Error: Los tamaños no coinciden.");
                }
            }
            else
            {
                Console.WriteLine("Error: El fichero de destino no existe.");
            }
        }
    }
}
