using System;
using System.IO;

namespace Ejercicio5
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 5. Diario de Entradas\n");
            GestionaDiario();
            Console.WriteLine("Pulsa una tecla para finalizar...");
            Console.ReadKey();
        }

        public static void GestionaDiario()
        {
            string archivoDiario = "diario.txt";
            string entrada;

            do
            {
                Console.Write("Escribe una entrada (FIN para salir): ");
                entrada = Console.ReadLine();

                if (entrada != "FIN")
                {
                    using (StreamWriter writer = new StreamWriter(archivoDiario, true))
                    {
                        writer.WriteLine($"{DateTime.Now} - {entrada}");
                    }
                    Console.WriteLine("Entrada guardada.");
                }

            } while (entrada != "FIN");

            Console.WriteLine("\n--- LEYENDO DIARIO ---");
            if (File.Exists(archivoDiario))
            {
                using (StreamReader reader = new StreamReader(archivoDiario))
                {
                    string linea;
                    int contador = 1;
                    while ((linea = reader.ReadLine()) != null)
                    {
                        Console.WriteLine($"{contador}. {linea}");
                        contador++;
                    }
                }
            }
        }
    }
}
