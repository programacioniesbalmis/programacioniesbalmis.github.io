using System;
using System.IO;

namespace Ejercicio2
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 2. Gestión de Archivos y Directorios\n");
            EjecutarGestionArchivos();
            Console.WriteLine("Pulsa una tecla para finalizar...");
            Console.ReadKey();
        }

        public static void EjecutarGestionArchivos()
        {
            string directorioBase = "Laboratorio";
            string directorioOriginales = Path.Combine(directorioBase, "Originales");
            string directorioCopias = Path.Combine(directorioBase, "Copias");
            string archivoOriginal = Path.Combine(directorioOriginales, "mensaje.txt");
            string archivoCopia = Path.Combine(directorioCopias, "mensaje_copia.txt");
            string archivoMovido = Path.Combine(directorioBase, "mensaje_movido.txt");

            if (Directory.Exists(directorioBase))
            {
                Directory.Delete(directorioBase, true);
            }

            Directory.CreateDirectory(directorioBase);
            Console.WriteLine("Carpeta Laboratorio creada.");

            Directory.CreateDirectory(directorioOriginales);
            Directory.CreateDirectory(directorioCopias);
            Console.WriteLine("Subcarpetas Originales y Copias creadas.");

            File.WriteAllText(archivoOriginal, "Este es el contenido original.");
            Console.WriteLine("Fichero mensaje.txt creado en Originales.");

            File.Copy(archivoOriginal, archivoCopia);
            Console.WriteLine("Fichero copiado a Copias como mensaje_copia.txt.");

            File.Move(archivoOriginal, archivoMovido);
            Console.WriteLine("Fichero original movido a raiz Laboratorio como mensaje_movido.txt.");

            Console.WriteLine("Archivos en Copias:");
            MostrarArchivos(directorioCopias);

            Console.WriteLine("Archivos en Laboratorio:");
            MostrarArchivos(directorioBase);

            Console.WriteLine("¿Quieres borrar todo? (S/N)");
            string respuesta = Console.ReadLine();

            if (respuesta.ToUpper() == "S")
            {
                Directory.Delete(directorioBase, true);
                Console.WriteLine("Carpeta Laboratorio y contenido eliminados.");
            }
        }

        public static void MostrarArchivos(string ruta)
        {
            string[] archivos = Directory.GetFiles(ruta);
            foreach (string archivo in archivos)
            {
                Console.WriteLine(Path.GetFileName(archivo));
            }
        }
    }
}
