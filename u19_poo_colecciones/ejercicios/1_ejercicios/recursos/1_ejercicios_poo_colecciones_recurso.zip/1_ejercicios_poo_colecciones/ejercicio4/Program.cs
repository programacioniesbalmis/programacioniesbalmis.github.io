﻿using System;
using System.Collections.Generic;

namespace ejercicio4
{
    public class Program
    {

        ///TODO: Implementar el método GestionPalabras
        public static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 4. Diccionario contador de palabras");
            Console.WriteLine();
            GestionPalabras();
            Console.WriteLine("\nPulsar Enter para salir...");
            Console.ReadLine();
        }

       
    }
}