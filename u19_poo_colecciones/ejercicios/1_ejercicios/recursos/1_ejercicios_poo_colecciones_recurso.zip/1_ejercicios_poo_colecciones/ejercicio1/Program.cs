﻿using System;
using System.Collections.Generic;

namespace ejercicio1
{
   ///TODO: Completa la clase Plato y el enum Categoria aquí

    public class Program
    {
        public static void Main(string[] args)
        {
            List<Plato> listaPlatos = new List<Plato>
            {
                new Plato("Ensalada", 10.5m, Categoria.Entrante),
                new Plato("Solomillo", 20.0m, Categoria.Principal),
                new Plato("Tarta de Queso", 6.5m, Categoria.Postre)
            };

            Console.WriteLine(" Ejercicio 1. Gestión de lista de Platos\n");
            ///TODO: Llama a los métodos para mostrar la lista, buscar, añadir y eliminar platos aquí
            Console.WriteLine("Presiona Enter para salir...");
            Console.ReadLine();
        }

        //TODO: Implementa los métodos para mostrar, buscar, añadir y eliminar platos aquí
    }
}