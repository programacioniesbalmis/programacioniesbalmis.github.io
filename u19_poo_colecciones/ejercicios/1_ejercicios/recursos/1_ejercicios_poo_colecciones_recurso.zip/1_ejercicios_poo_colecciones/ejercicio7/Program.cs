﻿using System;
using System.Collections.Generic;

namespace ejercicio7
{
    ///TODO: Implementar las clases Cancion y ReproductorMusical usando LinkedList

    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 7. Reproductor de Música con LinkedList");
            Console.WriteLine();
            ///TODO: Crear instancia de ReproductorMusical y añadir canciones, reproducirlas, etc.
            Console.WriteLine("\nPulsar Enter para salir...");
            Console.ReadLine();
        }
    }
}