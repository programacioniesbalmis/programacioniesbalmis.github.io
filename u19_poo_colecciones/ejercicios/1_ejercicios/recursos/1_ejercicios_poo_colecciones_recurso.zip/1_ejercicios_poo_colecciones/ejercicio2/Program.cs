﻿using System;
using System.Collections.Generic;

namespace ejercicio2
{
   ///TODO: Completa la clase Automovil y el enum Color aquí
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 2: Gestión de lista de automóviles");
            Console.WriteLine();

            ///TODO: Crea una lista de automóviles con al menos 5 elementos aquí
            Console.WriteLine();
            Console.WriteLine("Fin de la demostración.");
            Console.ReadLine();
        }

       ///TODO: Implementa el método MostrarAutomoviles aquí
    }
}