﻿using System;
using System.Collections.Generic;

namespace ejercicio5
{
    ///TODO: Implementar la clase ClaveProducto
    
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 5. Diccionario con Clave Personalizada");
            Console.WriteLine();
            GestionInventario();
            Console.WriteLine("\nPulsar Enter para salir...");
            Console.ReadLine();

        }

       
    }
}