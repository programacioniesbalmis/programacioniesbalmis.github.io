﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;

namespace ejercicio2
{
    class Program
    {
        static void Main(string[] args)
        {
           
            //TODO: Añade el código necesario para crear las especificaciones del ejercicio
          
            Console.WriteLine("\nOperaciones completadas.");
            Console.ReadLine();
        }

    }
}
