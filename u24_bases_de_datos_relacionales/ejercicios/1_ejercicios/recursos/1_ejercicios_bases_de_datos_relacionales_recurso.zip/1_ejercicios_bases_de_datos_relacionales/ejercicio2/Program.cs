﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;

namespace ejercicio2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Clase Vivero, Consultas y Transacciones\n");
            Vivero vivero = new Vivero();
            //TODO: Añade el código necesario para crear la base de datos y la tabla 'planta'

            vivero.Plantas.Add(new Planta(0, "Margarita", "Argyranthemum", 3.50, 60));
            vivero.Plantas.Add(new Planta(0, "Girasol", "Helianthus annuus", 4.00, 40));
            vivero.Plantas.Add(new Planta(0, "Lavanda", "Lavandula", 6.75, 30));
            vivero.Plantas.Add(new Planta(0, "Cactus", "Cactaceae", 8.00, 25));
            vivero.Plantas.Add(new Planta(0, "Bonsai", "Ficus retusa", 45.00, 5));

            //TODO: Añade la conexión
            //TODO: Añade la transacción
            {
                try
                {
                    foreach (var p in vivero.Plantas)
                    {
                        vivero.InsertaPlanta(p, connection, transaction);
                    }
                    //TODO: Confirma la transacción
                }
                catch
                {
                    //TODO: Cancela la transacción
                }
            }

            vivero.ModificaStock(1, 999);
            vivero.EliminaPlanta(2);

            var listado = vivero.ObtenPlantas();
            foreach (var p in listado)
            {
                Console.WriteLine(p);
            }
            Console.WriteLine("\nOperaciones completadas.");
            Console.ReadLine();
        }

    }
}
