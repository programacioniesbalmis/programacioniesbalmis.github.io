﻿using Microsoft.Data.Sqlite;

namespace ejercicio1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 1: Gestión de Plantas\n");
            ///TODO: Crear elcódigo necesario para crear la base de datos y la tabla 'planta'
        }

        public static void CreaTabla(SqliteConnection connection)
        {
           ///TODO: Añade el código necesario
        }

        public static void InsertaPlanta(SqliteConnection connection, string nombreComun, string nombreCientifico, double precio, int stock)
        {
            ///TODO: Añade el código necesario
        }
    }
}
