﻿using Microsoft.Data.Sqlite;
using Xunit;
using ejercicio2;
using System.IO;
using System.Linq;

namespace ejercicio2.tests
{
    public class UnitTest1 : IDisposable
    {
        private const string TestDbFile = "test_vivero_ej2.db";
        private readonly Vivero _vivero;

        public UnitTest1()
        {
            // Setup: Aseguramos que empezamos con una BD limpia
            if (File.Exists(TestDbFile))
            {
                File.Delete(TestDbFile);
            }

            _vivero = new Vivero
            {
                ConnectionString = $"Data Source={TestDbFile}",
                Nombre = "Vivero Test",
                Direccion = "Calle Test"
            };

            _vivero.CreaTabla();
        }

        [Fact]
        public void TestFlujoCompletoVivero()
        {
            // 1. Insertar una planta
            var planta = new Planta(0, "TestPlanta", "TestSpp", 10.0, 50);
            _vivero.InsertaPlanta(planta);

            // 2. Comprobar que se ha insertado
            var plantas = _vivero.ObtenPlantas();
            Assert.Single(plantas);
            var plantaInsertada = plantas.First();
            Assert.Equal("TestPlanta", plantaInsertada.NombreComun);
            Assert.Equal(50, plantaInsertada.Stock);

            // 3. Modificar Stock
            _vivero.ModificaStock(plantaInsertada.Id, 20);
            
            // Verificar modificación
            plantas = _vivero.ObtenPlantas();
            Assert.Equal(20, plantas.First().Stock);

            // 4. Eliminar planta
            _vivero.EliminaPlanta(plantaInsertada.Id);

            // Verificar eliminación
            plantas = _vivero.ObtenPlantas();
            Assert.Empty(plantas);
        }

        public void Dispose()
        {
            // Cleanup final
            try
            {
                if (File.Exists(TestDbFile))
                {
                    // Forzar limpieza de pools si es necesario, aunque Sqlite se porta bien si se dispone correctamente en la app
                    SqliteConnection.ClearAllPools();
                    File.Delete(TestDbFile);
                }
            }
            catch
            {
                // Ignorar errores de limpieza en tests si el archivo está en uso
            }
        }
    }
}
