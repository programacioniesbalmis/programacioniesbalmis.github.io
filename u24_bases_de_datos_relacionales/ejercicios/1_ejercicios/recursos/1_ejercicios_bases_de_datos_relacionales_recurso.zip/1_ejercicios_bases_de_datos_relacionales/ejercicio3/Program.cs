﻿using System;
using System.IO;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using System.Linq;

namespace ejercicio3
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Patrón DAO (Data Access Object)\n");
            ///TODO: Crear elcódigo necesario 
            Console.WriteLine("\nOperaciones completadas.");
            Console.ReadLine();
        }

        public static void CreaTabla(string connectionString)
        {
            ///TODO: Añade el código necesario

        }
    }
}

