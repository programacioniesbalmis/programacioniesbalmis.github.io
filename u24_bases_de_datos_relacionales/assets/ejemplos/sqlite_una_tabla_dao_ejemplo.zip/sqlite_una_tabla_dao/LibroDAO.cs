using System.Data;
using Microsoft.Data.Sqlite;

namespace Biblioteca
{
    public class LibroDAO : IDisposable
    {
        private SqliteConnection? Conexion { get; }

        private bool _disposed = false;

        public LibroDAO(string cadenaConexion)
        {
            Conexion = new SqliteConnection(cadenaConexion);
            Conexion.Open();
        }

        public void Create(Libro libro)
        {
            string insertarDatos = "INSERT INTO libro (titulo, autor) VALUES (@titulo, @autor)";
            using var comando = new SqliteCommand(insertarDatos, Conexion);
            comando.Parameters.AddWithValue("@titulo", libro.Titulo);
            comando.Parameters.AddWithValue("@autor", libro.Autor);
            comando.ExecuteNonQuery();
        }

        public IEnumerable<Libro> Read()
        {
            string verLibros = "SELECT * FROM libro";
            using var query = new SqliteCommand(verLibros, Conexion);
            using var rs = query.ExecuteReader();

            while (rs.Read())
            {
                yield return new
                (
                    id: Convert.ToInt32(rs["id"]),
                    titulo: rs["titulo"].ToString()!,
                    autor: rs["autor"].ToString()!
                );
            }
        }

        public Libro? Read(int id)
        {
            string verLibro = "SELECT * FROM libro WHERE id = @id";
            using var query = new SqliteCommand(verLibro, Conexion);
            query.Parameters.AddWithValue("@id", id);
            using var rs = query.ExecuteReader();

            return rs.Read()
            ? new Libro
            (
                id: Convert.ToInt32(rs["id"]),
                titulo: rs["titulo"].ToString()!,
                autor: rs["autor"].ToString()!
            )
            : null;
        }

        public Libro? Read(string titulo)
        {
            string verLibro = "SELECT * FROM libro WHERE titulo = @titulo";
            using var query = new SqliteCommand(verLibro, Conexion);
            query.Parameters.AddWithValue("@titulo", titulo);
            using var rs = query.ExecuteReader();

            return rs.Read()
            ? new Libro
            (
                id: Convert.ToInt32(rs["id"]),
                titulo: rs["titulo"].ToString()!,
                autor: rs["autor"].ToString()!
            )
            : null;
        }

        public record class LibrosPorAutorDTO(string Autor, int Titulos);

        public IEnumerable<LibrosPorAutorDTO> ReadLibrosPorAutor()
        {
            string verLibros = """
                SELECT autor, COUNT(*) AS cantidad
                FROM libro
                GROUP BY autor
                ORDER BY cantidad DESC
                """;
            using var query = new SqliteCommand(verLibros, Conexion);
            using var rs = query.ExecuteReader();

            List<LibrosPorAutorDTO> librosXAutor = [];
            while (rs.Read())
            {
                librosXAutor.Add(new LibrosPorAutorDTO(
                    Autor: rs["autor"].ToString()!,
                    Titulos: Convert.ToInt32(rs["cantidad"])
                ));
            }
            return librosXAutor;
        }

        public void Update(Libro libro)
        {
            if (Read(libro.Id) == null)
                throw new ArgumentException("El libro no tiene un ID válido");

            string actualizarDatos = "UPDATE libro SET titulo = @titulo, autor = @autor WHERE id = @id";
            using var comando = new SqliteCommand(actualizarDatos, Conexion);
            comando.Parameters.AddWithValue("@titulo", libro.Titulo);
            comando.Parameters.AddWithValue("@autor", libro.Autor);
            comando.Parameters.AddWithValue("@id", libro.Id);
            comando.ExecuteNonQuery();
        }

        public void Delete(int id)
        {
            if (Read(id) == null)
                throw new ArgumentException($"El id {id} no existe en la base de datos");

            string borrarDatos = "DELETE FROM libro WHERE id = @id";
            using var comando = new SqliteCommand(borrarDatos, Conexion);
            comando.Parameters.AddWithValue("@id", id);
            comando.ExecuteNonQuery();
        }

        public int Count()
        {
            string query = "SELECT COUNT(*) FROM libro";
            using var comando = new SqliteCommand(query, Conexion);
            return Convert.ToInt32(comando.ExecuteScalar());
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    if (Conexion != null && Conexion.State != ConnectionState.Closed)
                    {
                        Conexion.Close();
                    }
                }
                _disposed = true;
            }
        }
    }
}