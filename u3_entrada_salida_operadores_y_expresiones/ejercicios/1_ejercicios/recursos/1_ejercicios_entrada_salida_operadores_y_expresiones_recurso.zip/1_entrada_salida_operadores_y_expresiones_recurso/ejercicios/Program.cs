﻿using System;

public class Program
{
    public static void CalculaAreaYPerimetroDelRectangulo()
    {
        Console.WriteLine("Ejercicio 1: Área y perímetro de un rectángulo");
        // TODO: Pedir al usuario el ancho
        // TODO: Pedir al usuario el alto
        // TODO: Calcular el área
        // TODO: Calcular el perímetro
        // TODO: Mostrar el resultado del área
        // TODO: Mostrar el resultado del perímetro
    }

    public static void SaludaConNombre()
    {
        Console.WriteLine("Ejercicio 2: Saludo");
        // TODO: Implementa la lógica de este método
    }

    public static void ConvierteDolaresAEuros()
    {
        Console.WriteLine("Ejercicio 3: Conversión de moneda");
        // TODO: Implementa la lógica de este método        
    }

    public static void CalculaIMC()
    {
        Console.WriteLine("Ejercicio 4: Calculadora de IMC");
        // TODO: Implementa la lógica de este método
    }

    public static void MuestraTextoFormateado()
    {
        Console.WriteLine("Ejercicio 5: Formateando salida");
        // TODO: Implementa la lógica de este método   
 }

    public static void CalculaPrecioConDescuento()
    {
        Console.WriteLine("Ejercicio 6: Calculadora de descuento");
        // TODO: Implementa la lógica de este método
    }

    public static void CalculaEdadActual()
    {
        Console.WriteLine("Ejercicio 7: Calculadora de edad");
        // TODO: Implementa la lógica de este método
    }

    public static void ElevaNumeroAPotencia()
    {
        Console.WriteLine("Ejercicio 8: Calculadora de potencia");
        // TODO: Implementa la lógica de este método
    }

    public static void MuestraNumeroEnFormatos()
    {
        Console.WriteLine("Ejercicio 9: Mostrar número con formatos");
        // TODO: Implementa la lógica de este método
    }

    public static void LongitudArea()
    {
        Console.WriteLine("Ejercicio 10: Longitud y área de un círculo");
        // TODO: Implementa la lógica de este método
    }

    static void Main()
    {
        CalculaAreaYPerimetroDelRectangulo();
        SaludaConNombre();
        ConvierteDolaresAEuros();
        CalculaIMC();
        MuestraTextoFormateado();
        CalculaPrecioConDescuento();
        CalculaEdadActual();
        ElevaNumeroAPotencia();
        MuestraNumeroEnFormatos();
        Console.ReadLine();
    }

}