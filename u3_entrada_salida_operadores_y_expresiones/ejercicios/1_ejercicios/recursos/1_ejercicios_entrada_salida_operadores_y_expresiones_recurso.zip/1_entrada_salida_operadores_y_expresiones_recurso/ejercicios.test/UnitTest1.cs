﻿

using System.Runtime.InteropServices;
using System.Text;
using Xunit;


namespace TestsProject1;

public class UnitTest1
{
    [Fact]
    public void CalculaAreaYPerimetroDelRectangulo_Test()
    {
        var input = "5\n3\n";
        var output = new StringWriter();
        Console.SetIn(new StringReader(input));
        Console.SetOut(output);


        Program.CalculaAreaYPerimetroDelRectangulo();

        var result = output.ToString();
        Assert.Contains("Área: 15", result);
        Assert.Contains("Perímetro: 16", result);
    }

    [Fact]
    public void SaludaConNombre_Test()
    {
        var input = "Juan\n";
        var output = new StringWriter();
        Console.SetIn(new StringReader(input));
        Console.SetOut(output);

        Program.SaludaConNombre();

        var result = output.ToString();
        Assert.Contains("Hola Juan", result);
    }

    [Fact]
    public void ConvierteDolaresAEuros_Test()
    {
        var input = "10\n0,9\n";
        var output = new StringWriter();
        Console.SetIn(new StringReader(input));
        Console.SetOut(output);

        Program.ConvierteDolaresAEuros();

        var result = output.ToString();
        Assert.Contains("Equivalente en euros: 9,00", result);
    }

    [Fact]
    public void CalculaIMC_Test()
    {
        var input = "70\n1,75\n";
        var output = new StringWriter();
        Console.SetIn(new StringReader(input));
        Console.SetOut(output);

        Program.CalculaIMC();

        var result = output.ToString();
        Assert.Contains("Tu IMC es: 22,86", result);
    }

    [Fact]
    public void MuestraTextoFormateado_Test()
    {
        var output = new StringWriter();
        Console.SetOut(output);

        Program.MuestraTextoFormateado();

        var result = output.ToString();
        Assert.Contains("abc", result);
        Assert.Contains("abcdef", result);
        Assert.Contains("54,87", result);
    }

    [Fact]
    public void CalculaPrecioConDescuento_Test()
    {
        var input = "100\n20\n";
        var output = new StringWriter();
        Console.SetIn(new StringReader(input));
        Console.SetOut(output);

        Program.CalculaPrecioConDescuento();

        var result = output.ToString();
        Assert.Contains("Precio final tras descuento: 80,00", result);
    }

    [Fact]
    public void CalculaEdadActual_Test()
    {
        int year = DateTime.Now.Year - 25;
        var input = $"{year}\n";
        var output = new StringWriter();
        Console.SetIn(new StringReader(input));
        Console.SetOut(output);

        Program.CalculaEdadActual();

        var result = output.ToString();
        Assert.Contains("Tu edad es: 25 años", result);
    }

    [Fact]
    public void ElevaNumeroAPotencia_Test()
    {
        var input = "2\n3\n";
        var output = new StringWriter();
        Console.SetIn(new StringReader(input));
        Console.SetOut(output);

        Program.ElevaNumeroAPotencia();

        var result = output.ToString();
        Assert.Contains("2 ^ 3 = 8", result);
    }

    [Fact]
    public void MuestraNumeroEnFormatos_Test()
    {
        var output = new StringWriter();
        Console.SetOut(output);

        Program.MuestraNumeroEnFormatos();

        var result = output.ToString();
        Assert.Contains("Decimal: 15", result);
        Assert.Contains("Hexadecimal: F", result);
    }

    [Fact]
    public void LongitudArea_Test()
    {
        var input = "5\n";
        var output = new StringWriter();
        Console.SetIn(new StringReader(input));
        Console.SetOut(output);

        Program.LongitudArea();

        var result = output.ToString();
        Assert.Contains("Longitud: 31,42", result);
        Assert.Contains("Área: 78,54", result);
    }
    

}
