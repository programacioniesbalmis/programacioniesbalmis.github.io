﻿using System;
using System.Diagnostics;

#region Ej07_Multicine
namespace Ej07_Multicine
{
    class Ej07_Multicine
    {
        /* Escribe un programa que se encargue de controlar el aforo de un Multicine. El Cine tendrá Tres Salas (A, B, C),
         * en las cuales se pasarán diariamente tres sesiones (1ª, 2ª, 3ª). El número máximo de personas de cada una de las
         * salas es: sala A 200personas, sala B 150 y sala C 125personas. Tendremos un menú con dos opciones, venta de entradas
         * y estadistica de aforo. Para salir delprograma se tendrá que pulsar la tecla ESC. Cada vez que se realice una
         * venta de entradas se pedirá: el número de entradas que se van a comprar, para que sala y a que sesión se quiere
         * asistir. Las entradas vendidas quedarán registradas en el array. Si el número de entradas sobrepasa el aforo máximo
         * de la sala, se indicará mediante un mensaje por pantalla.*/

        static int PideSala()
        {
            char sala;
            int numeroDeSala;
            bool salaInorrecta;

            do
            {
                Console.Write("Indique Sala (A,B,C): ");
                sala = char.Parse(Console.ReadLine());
                sala = char.ToUpper(sala);

                salaInorrecta = sala != 'A' && sala != 'B' && sala != 'C';
                if (salaInorrecta)
                    Console.WriteLine("\aERROR: Sala inexistente");

            } while (salaInorrecta);

            switch (sala)
            {
                case 'A':
                    numeroDeSala = 0;
                    break;
                case 'B':
                    numeroDeSala = 1;
                    break;
                case 'C':
                    numeroDeSala = 2;
                    break;
                default:
                    numeroDeSala = -1;
                    Debug.Assert(false);
                    break;
            }

            return numeroDeSala;
        }

        static int PideSesion()
        {
            int sesion;
            bool sesionIncorrecta;

            do
            {
                Console.Write("Indique Sesion (1,2,3): ");
                sesion = int.Parse(Console.ReadLine());

                sesionIncorrecta = sesion != 1 && sesion != 2 && sesion != 3;
                if (sesionIncorrecta)
                    Console.WriteLine("\aERROR: Sesion inexistente");

            } while (sesionIncorrecta);

            return sesion - 1;
        }

        static void VendeEntradas(int[,] aforoSalaPorSesion)
        {
            int[] aforosMaximosPorSala = new int[] { 200, 150, 125 };

            Console.WriteLine("\n\n");
            int numeroEntradas;

            Console.Write("Introduzca numeroero de entradas: ");
            numeroEntradas = int.Parse(Console.ReadLine());
            int sala = PideSala();
            int sesion = PideSesion();

            if (aforoSalaPorSesion[sala, sesion] + numeroEntradas <= aforosMaximosPorSala[sala])
                aforoSalaPorSesion[sala, sesion] += numeroEntradas;
            else
                Console.WriteLine("\aEspacio insuficiente, sobrepasa el aforo. Quedan {0} entradas disponibles",
                                       aforosMaximosPorSala[sala] - aforoSalaPorSesion[sala, sesion]);
        }

        static char LetraSala(int sala)
        {
            char letra;

            switch (sala)
            {
                case 0:
                    letra = 'A';
                    break;
                case 1:
                    letra = 'B';
                    break;
                case 2:
                    letra = 'C';
                    break;
                default:
                    Debug.Assert(false);
                    letra = '\0';
                    break;
            }
            return letra;
        }

        static void Estadistica(int[,] aforoSalaPorSesion)
        {
            Console.WriteLine("\n\n");
            Console.WriteLine("\tSESION 1\tSESION 2\tSESION 3");
            for (int i = 0; i < aforoSalaPorSesion.GetLength(0); i++)
            {
                for (int j = 0; j < aforoSalaPorSesion.GetLength(1); j++)
                {
                    string valorEnColumna = "";
                    if (j == 0)
                        valorEnColumna += "SALA " + LetraSala(i) + "\t";
                    valorEnColumna += aforoSalaPorSesion[i, j] + "\t\t";
                    Console.Write(valorEnColumna);
                }
                Console.WriteLine();
            }
        }

        static void Main()
        {
            ConsoleKeyInfo opcion;
            int[,] aforoSalaPorSesion = new int[3, 3];

            do
            {
                Console.WriteLine("\nMENU");
                Console.WriteLine("1.   Venta de entradas");
                Console.WriteLine("2.   Estadistica de aforo");
                Console.WriteLine("ESC. Salir");
                Console.Write("\nIntroduzca una opción: ");
                opcion = Console.ReadKey();

                switch (opcion.KeyChar)
                {
                    case '1':
                        VendeEntradas(aforoSalaPorSesion);
                        break;
                    case '2':
                        Estadistica(aforoSalaPorSesion);
                        break;
                    default:
                        if (opcion.Key != ConsoleKey.Escape)
                            Console.WriteLine("\aERROR: Opcion no reconocida");
                        break;
                }
            } while (opcion.Key != ConsoleKey.Escape);
        }
    }
}
#endregion