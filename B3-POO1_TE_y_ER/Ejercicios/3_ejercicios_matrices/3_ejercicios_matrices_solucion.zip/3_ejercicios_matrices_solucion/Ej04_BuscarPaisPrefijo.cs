﻿using System;
using System.Diagnostics;

#region Ej08_BuscarPaisPrefijo
namespace Ej04_BuscarPaisPrefijo
{
    class Ej04_BuscarPaisPrefijo
    {
        /* Tenemos una tabla dentada de caracteres que tiene almacenados los nombres de 20 países.
         * Se pide diseñar un programa que realice tantas veces como sea requerido por el usuario
         * la siguiente operación: buscar un país y pedir y añadir al final del nombre del país
         * el prefijo telefónico de dicho país (2 caracteres para el prefijo de teléfono) dejando
         * un espacio en blanco entre el nombre y el código telefónico. Cuando se acabe el bucle
         * el programa debe presentar en pantalla todos los países en orden alfabético. Para eso
         * utilizaremos una función con un método de ordenación seleccionado que nos ordene el array.*/

        static bool BuscaPais(char[][] paises, char[] pais, out int indice)
        {
            bool encontrado = false;
            indice = -1;

            for (int i = 0; i < paises.Length; i++)
            {
                string textoPais1 = new String(paises[i]);
                string textoPais2 = new String(pais);
                if (textoPais1.ToLower() == textoPais2.ToLower())
                {
                    encontrado = true;
                    indice = i;
                    break;
                }
            }

            return encontrado;
        }

        static char[] AñadePrefijo(char[] pais, char[] prefijo)
        {
            if(pais==null || prefijo==null || prefijo.Length != 2) Console.WriteLine("Ha ocurrido un problema");
            Array.Resize(ref pais, pais.Length+3);
            pais[pais.Length-1]=prefijo[1];
            pais[pais.Length-2]=prefijo[0];
            pais[pais.Length-3]=' ';
            return pais;
        }
        static void AñadePrefijo(char[][] paises)
        {
             Console.Write("Introduzca el nombre del pais al que quieres añadir el prefijo: ");
             string pais = Console.ReadLine();
             int posicionPais;
             if (BuscaPais(paises, pais.ToCharArray(), out posicionPais) == true)
             {
                    Console.Write("Introduzca prefijo: ");
                    string prefijo = Console.ReadLine();

                    paises[posicionPais]=AñadePrefijo(paises[posicionPais], prefijo.ToCharArray());
             }
             else Console.Write("El país no existe");

        }

        static void OrdenaAscendentemente(char[][] vector)
        {
            int i, j;

            for (i = 0; i < vector.Length; i++)
            {
                for (j = 0; j < vector.Length; j++)
                {
                    if (new String(vector[j]).CompareTo(new String(vector[i])) > 0)
                    {
                        char[] swap = (char[])vector[i].Clone();
                        vector[i] = vector[j];
                        vector[j] = swap;
                    }
                }
            }
        }
        static void MuestraPaises(char[][] paises)
        {
              Console.Write("\n");
             for (int i = 0; i < paises.GetLength(0); i++)
              Console.WriteLine(new String(paises[i]));
        }

        static void Main()
        {
            char[][] paises =
                {
                     "España".ToCharArray(),
                    new char[] { 'I','t','a','l','i','a' },
                    new char[] { 'R','u','s','i','a' },
                    new char[] { 'F','r','a','c','i','a' },
                    new char[] { 'C','h','i','n','a' },
                    new char[] { 'M','e','x','i','c','o' },
                    new char[] { 'J','a','p','o','n' },
                    new char[] { 'E','s','t','a','d','o','s',' ','U','n','i','d','o','s' },
                    new char[] { 'A','l','e','m','a','n','i','a' },
                    new char[] { 'M','a','l','t','a' },
                    new char[] { 'A','r','g','e','n','t','i','n','a' },
                    new char[] { 'A','l','b','a','n','i','a' },
                    new char[] { 'D','i','n','a','m','a','r','c','a' },
                    new char[] { 'N','o','r','u','e','g','a' },
                    new char[] { 'P','u','e','r','t','o',' ','R','i','c','o' },
                    new char[] { 'P','o','r','t','u','g','a','l' },
                    new char[] { 'U','r','u','g','u','a','y' },
                    new char[] { 'T','u','r','q','u','i','a' },
                    new char[] { 'S','u','i','z','a' },
                    new char[] { 'M','a','d','a','g','a','s','c','a','r' },
                };

            int eleccion;
            do
            {
               
             Console.WriteLine("1. Buscar un país.\n2. Mostrar países.\n3. Ordenar países.\n4. Añadir prefijo a un país.\n5. Salir\n");
             eleccion=int.Parse(Console.ReadLine());
             switch(eleccion)
             {
                 case 1:
                    Console.Write("Introduzca el nombre del pais a buscar: ");
                    string pais = Console.ReadLine();
                    int posicionPais;
                    Console.WriteLine(BuscaPais(paises, pais.ToCharArray(), out posicionPais)?"El país está en la posición "+ posicionPais:"El país no está");
                    break;
                 case 2:
                    MuestraPaises(paises);
                 break;
                 case 3:
                    OrdenaAscendentemente(paises);
                 break;
                 case 4:
                     AñadePrefijo(paises);
                 break;
             }

            } while (eleccion!=5);
        }
    }
}
#endregion

