using System;
using System.Diagnostics;

#region Ej02A_MultiplicaMatrices
namespace Ej09_MultiplicaMatrices
{
    class Ej09_MultiplicaMatrices
    {
        static void Main()
        {
			static int SumaProductosFilaIm1PorColumnaJm2(int filaM1, int columnaM2, int[,] m1, int[,] m2)
			{
				int sumaProductos = 0;
				int dimensionFilaIColumnaJ = m1.GetLength(1);

				for (int i = 0; i < dimensionFilaIColumnaJ; i++)
					sumaProductos += m1[filaM1, i] * m2[i, columnaM2];
				return sumaProductos;
			}

			static int[,] MultiplicaMatricesEnteras(int[,] m1, int[,] m2)
			{
				int fm1 = m1.GetLength(0);
				int cm1 = m1.GetLength(1);
				int fm2 = m2.GetLength(0);
				int cm2 = m2.GetLength(1);
				Debug.Assert(cm1 == fm2, "No se pueden multiplicar las matrices.");

				int[,] resultado = new int[fm1, cm2];

				for (int i = 0; i < fm1; i++)
					for (int j = 0; j < cm2; j++)
						resultado[i, j] = SumaProductosFilaIm1PorColumnaJm2(i, j, m1, m2);

				return resultado;
			}

			static void Main()
			{
				int[,] m1 = new int[,] { { 1, 3, 5 }, { 2, 4, 6 } };
				int[,] m2 = new int[,] { { 6, 5 }, { 4, 3 }, { 2, 1 } };

				int[,] m3 = MultiplicaMatricesEnteras(m1, m2);
			}
        }
    }
}
#endregion