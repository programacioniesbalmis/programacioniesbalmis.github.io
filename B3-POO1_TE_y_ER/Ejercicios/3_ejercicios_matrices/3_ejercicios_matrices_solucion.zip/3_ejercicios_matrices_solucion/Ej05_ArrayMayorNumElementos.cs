﻿using System;

#region Ej05_ArrayMayorNumElementos
namespace Ej05_ArrayMayorNumElementos
{
	/* Haz un programa que busque en la tabla y posteriormente muestre, 
	 * el array con mas número de elementos, usando solo bucles foreach.
     * Nota: No hace falta que crees ningún método auxiliar.*/
    class Ej05_ArrayMayorNumElementos
    {
        static void Main()
        {
            int[][] tabla = new int[][]
            {
                new int[] { 1, 2, 3, 4 },
                new int[] { 5, 6, 7 },
                new int[] { 9, 10, 11, 12, 5 },
                new int[] { 9, 10 }
            };

            int[] mayor = tabla[0];
            foreach (int[] array in tabla)
                if (array.Length > mayor.Length)
                    mayor = array;

            foreach (var valor in mayor)
                Console.Write(valor + " ");
            Console.Write("\n\n");
        }
    }
}
#endregion



