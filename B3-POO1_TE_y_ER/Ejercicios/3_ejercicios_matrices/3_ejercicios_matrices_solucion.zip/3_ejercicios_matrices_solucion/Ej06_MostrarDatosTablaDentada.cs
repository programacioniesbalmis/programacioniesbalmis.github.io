﻿/* Crea un programa para mostrar los elementos de la siguiente tabla dentada:
 *      int[][][] tabla = new int[][][]
 *      {
 *          new int [][]
 *          {
 *              new int [] {1,2,3,4},
 *              new int [] {5,6,7},
 *              new int [] {9,10,11,12}
 *          },
 *          new int [][]
 *          {
 *              new int [] {13,14,15,16},
 *              new int [] {17,18,19,20},
 *              new int [] {21,22}
 *          },
 *      };
 * Cada tabla se debe mostrar de la siguiente manera. Utiliza las funciones necesarias para
 * que el código quede claro.
 *      1,2,3,4          13,14,15,16
 *      5,6,7            17,18,19,20
 *      9,10,11,12       21,22*/
 
namespace Ej06_MostrarDatosTablaDentada
{
    class Ej06_MostrarDatosTablaDentada
    {
        static int NumeroColumnasMaximo(int[][] v)
        {
            int maximo = int.MinValue;
            for (int i = 0; i < v.Length; i++)
                if (v[i].Length > maximo) maximo = v[i].Length;
            return maximo;
        }

        static void Muestra(int[][][] tabla)
        {
            int offset = 0;

            for (int i = 0; i < tabla.Length; i++)
            {
                offset += i > 0 ? NumeroColumnasMaximo(tabla[i - 1]) * 3 + 3 : 0;

                for (int j = 0; j < tabla[i].Length; j++)
                {
                    for (int k = 0; k < tabla[i][j].Length; k++)
                    {
                        Console.SetCursorPosition(k * 3 + offset, j);
                        Console.Write($"{tabla[i][j][k],-3}");
                    }
                }
            }
            Console.Write($"\n");
        }

        static void Main()
        {
            int[][][] tabla = new int[][][]
            {
                new int [][]
                {
                    new int [] {1,2,3,4},
                    new int [] {5,6,7},
                    new int [] {9,10,11,12}
                },
                new int [][]
                {
                    new int [] {13,14,15,16},
                    new int [] {17,18,19,20},
                    new int [] {21,22}
                }
            };

            Muestra(tabla);
        }
    }
}