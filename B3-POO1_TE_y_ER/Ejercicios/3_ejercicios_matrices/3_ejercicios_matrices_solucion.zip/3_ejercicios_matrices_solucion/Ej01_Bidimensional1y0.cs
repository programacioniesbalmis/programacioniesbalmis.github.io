﻿using System;

#region Ej01_Bidimensional1y0
namespace Ej01_Bidimensional1y0
{
    class Ej01_Bidimensional1y0
    {
        /* 01. Crea un programa que cree un matriz bidimensional de 10 x 10. Inicializa la
         * matriz de forma que las filas pares se rellenen con unos y las impares a ceros. 
         * Una vez inicializada la matriz, muestra su contenido en pantalla.*/

        static void InicializaMatriz(int[,] matriz)
        {
            for (int i = 0; i < matriz.GetLength(0); i++)
            {
                for (int j = 0; j < matriz.GetLength(1); j++)
                    matriz[i, j] = (i % 2 == 0) ? 0 : 1;
            }
        }

        static void VisualizaMatriz(int[,] matriz)
        {
            for (int i = 0; i < matriz.GetLength(0); i++)
            {
                for (int j = 0; j < matriz.GetLength(1); j++)
                {
                    Console.Write($"{matriz[i, j],2}");
                }
                Console.WriteLine();
            }
        }

        static void Main(string[] args)
        {
            int[,] matriz = new int[10, 10];
            InicializaMatriz(matriz);
            VisualizaMatriz(matriz);
        }
    }
}
#endregion

