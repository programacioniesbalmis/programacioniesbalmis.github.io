﻿using System;

#region Ej03_MatrizPermutada
namespace Ej03_MatrizPermutada
{
    class Ej03_MatrizPermutada
    {
        /* Dada una matriz de 3x5, diseña un programa que lea dicha matriz y 
         * posteriormente cree una nueva matriz a partir de la primera permutando 
         * filas por columnas.*/

        static void RellenaMatrizAleatoriamente(int[,] matriz, Random gerenardorAleatorio)
        {
            for (int i = 0; i < matriz.GetLength(0); i++)
            {
                for (int j = 0; j < matriz.GetLength(1); j++)
                    matriz[i, j] = gerenardorAleatorio.Next(99);
            }
        }

        static int[,] PermutarMatriz(int[,] matriz)
        {
            int[,] matrizPermutada = new int[matriz.GetLength(1), matriz.GetLength(0)];

            for (int i = 0; i < matriz.GetLength(0); i++)
            {
                for (int j = 0; j < matriz.GetLength(1); j++)
                    matrizPermutada[j, i] = matriz[i, j];
            }
            return matrizPermutada;
        }

        static void VisualizaMatriz(int[,] matriz)
        {
            for (int i = 0; i < matriz.GetLength(0); i++)
            {
                for (int j = 0; j < matriz.GetLength(1); j++)
                    Console.Write($"{matriz[i, j],3}");
                Console.WriteLine("\n\n");
            }
            Console.WriteLine("\n\n");
        }

        static void Main()
        {
            int[,] matriz = new int[3, 5];

            RellenaMatrizAleatoriamente(matriz, new Random());
            VisualizaMatriz(matriz);
            VisualizaMatriz(PermutarMatriz(matriz));
        }
    }
}
#endregion

