﻿using System;

#region Ej02_BidimensionalDiagonal1
namespace Ej02_BidimensionalDiagonal1
{
    class Ej02_BidimensionalDiagonal1
    {
        /* 02.Crea un programa que cree un array bidimensional de 5 x 5. Inicializa 
         * la matriz de forma que los componentes pertenecientes a la diagonal de 
         * la matriz tomen valor uno y el resto valor cero. Una vez inicializada la
         * matriz, muestra su contenido en pantalla.
         */

        static void InicializaMatriz(int[,] matriz)
        {
            for (int i = 0; i < matriz.GetLength(0); i++)
            {
                for (int j = 0; j < matriz.GetLength(1); j++)
                    matriz[i, j] = (j == i) ? 1 : 0;
            }
        }

        static void VisualizaMatriz(int[,] matriz)
        {
            for (int i = 0; i < matriz.GetLength(0); i++)
            {
                for (int j = 0; j < matriz.GetLength(1); j++)
                {
                    Console.Write($"{matriz[i, j],2}");
                }
                Console.WriteLine();
            }
        }

        static void Main()
        {
            int[,] matriz = new int[5, 5];
            InicializaMatriz(matriz);
            VisualizaMatriz(matriz);
        }
    }
}
#endregion