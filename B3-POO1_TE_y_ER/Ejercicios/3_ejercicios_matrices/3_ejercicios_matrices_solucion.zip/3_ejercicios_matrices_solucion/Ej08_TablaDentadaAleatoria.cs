﻿using System;

#region Ej08_TablaDentadaAleatoria
namespace Ej08_TablaDentadaAleatoria
{
    class Ej08_TablaDentadaAleatoria
    {
        /* Realiza un programa que cree una tabla dentada de enteros de profundidad 2, El programa pedirá cuantas
         * filas tiene y el número de elementos de cada fila, le reservará memoria y rellenará la fila con los 
         * elementos generados de forma aleatoria. Posteriormente se mostrará la matriz en forma de tabla.*/

        static int[][] RellenaTabla()
        {
            Random rand = new Random();
            Console.Write("Filas: ");
            int filas = int.Parse(Console.ReadLine());

            int[][] tabla = new int[filas][];
            for (int i = 0; i < filas; i++)
            {
                Console.Write("Columnas: ");
                int columnas = int.Parse(Console.ReadLine());
                tabla[i] = new int[columnas];

                for (int j = 0; j < columnas; j++)
                    tabla[i][j] = rand.Next(1, 100);
            }

            return tabla;
        }

        static void MuestraTabla(int[][][] m)
        {
            foreach (int[][] tabla in m)
            {
                foreach (int[] fila in tabla)
                {
                    foreach (int valor in fila)
                    {
                        Console.Write(valor + " ");
                    }
                    Console.Write("\n");
                }
                Console.Write("\n\n");
            }
        }

        static void Main()
        {
            int[][][] m = new int[2][][];

            m[0] = RellenaTabla();
            m[1] = RellenaTabla();

            MuestraTabla(m);
        }
    }
}
#endregion



