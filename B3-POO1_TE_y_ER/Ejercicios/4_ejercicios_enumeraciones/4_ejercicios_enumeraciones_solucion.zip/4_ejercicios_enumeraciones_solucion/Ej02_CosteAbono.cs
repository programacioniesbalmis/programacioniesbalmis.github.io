using System;
using System.Text;

namespace Ej02_CosteAbono
{
    /*Crea un programa que permita controlar el coste del abono de transporte urbano
     * de una determinada ciudad. Existirán diferentes tipos de abonos: QuinceDias, TreintaDias,
     * FamiliasNumerosas, TerceraEdad, Discapacidad, Juvenil, Infantil, Turistico.
     * El coste del viaje de cada una de estas tarífas será, respectivamente, 
     * el siguiente: 0.70, 0.60, 0.50, 0.30, 0.20, 0.65, 0.35, 0.90. 
     * Frente al precio de 1.20 del viaje sin tarifa.
     * Los abonos se podrán comprar para un mínimo de 7 días 
     * (descartando los dos primeros que son para 15 y 30 días respectivamente),
     *  y un máximo de 60 días.
     * El programa deberá:
     * pedir al usuario el tipo de abono que quiere comprar, y para cuantos días 
     * (teniendo en cuenta que los dos primeros no necesitan este datos).
     * Calcular el coste del Abono, mostrando total a pagar por pantalla.
     * Controlar que la entrada de datos es correcta, mostrando mensajes de aviso en caso contrario.
     * Se deberán crear los métodos necesarios para que el código siga las normas de modularidad 
     * que ya vimos en temas anteriores.
     * Nota: Para una mejor codificación deberás asociar los precios del viaje a la enumeración. 
     * Como a las enumeraciones solo se pueden asociar a valores enteros, podrás dividir entre
     * 100 el valor asociado para que sea real.
    */
     class Ej02_CosteAbono
    {
        enum TipoAbono : int
        {
           QuinceDias=70, TreintaDias=60, FamiliasNumerosas=50, 
           TerceraEdad=30, Discapacidad=20, Juvenil=65, Infantil=35, Turistico=90
        }

        static TipoAbono LeeTipoAbono()
        {
           do
           {
              Console.Clear();
               Console.WriteLine("Introduce el tipo de Abono: ");
               string abono=Console.ReadLine();
               if(Enum.IsDefined(typeof(TipoAbono), abono)) return (TipoAbono)Enum.Parse(typeof(TipoAbono),abono);
               else
               {
                  Console.WriteLine("Los posibles valores son:");
                  foreach(var x in Enum.GetNames(typeof(TipoAbono))) Console.WriteLine(x);
                  Console.ReadLine();
               }
           }while(true);
        }
        static int LeeCuantosDias(TipoAbono tipoAbono)
        {
           if(tipoAbono==TipoAbono.QuinceDias) return 15;
           if(tipoAbono==TipoAbono.TreintaDias) return 30;
           do{
               Console.Clear();
               Console.WriteLine("Introduce para cuantos días quieres el abono: ");
               int numeroDias=int.Parse(Console.ReadLine());
               if(numeroDias>=7 && numeroDias<=60) return numeroDias;
               Console.WriteLine("Valor no válido, los abonos deben ser de 7 a 60 días");
               Console.ReadLine();
           }while(true);
        }

       static string CalculoCoste(TipoAbono abono, int numeroDias)
       {
          string salida="El total del precio del abono es ";
          salida+= abono switch 
          {
             TipoAbono.QuinceDias=>(70f/100f*numeroDias).ToString(), 
             TipoAbono.TreintaDias=>(60f/100f*numeroDias).ToString(), 
             TipoAbono.FamiliasNumerosas=>(50f/100f*numeroDias).ToString(),
             TipoAbono.TerceraEdad=>(30f/100f*numeroDias).ToString(),
             TipoAbono.Discapacidad=>(20f/100f*numeroDias).ToString(),
             TipoAbono.Juvenil=>(65f/100f*numeroDias).ToString(),
             TipoAbono.Infantil=>(35f/100f*numeroDias).ToString(),
             TipoAbono.Turistico=>(90f/100f*numeroDias).ToString(),
             _=>(120f/100f*numeroDias).ToString()
          };
          return salida;
       }


        static void Main()
        {
           TipoAbono abono=LeeTipoAbono();
           Console.WriteLine(CalculoCoste(abono,LeeCuantosDias(abono)));
        }
    }
}