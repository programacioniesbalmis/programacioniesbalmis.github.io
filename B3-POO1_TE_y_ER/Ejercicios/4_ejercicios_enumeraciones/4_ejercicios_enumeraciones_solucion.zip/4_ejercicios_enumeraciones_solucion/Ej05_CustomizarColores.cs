using System;


namespace Ej05_CustomizarColores
{
    /* Crea una aplicación para gestionar la customización de autos en un determinado taller. 
     * Tendrás que utilizar Enumeraciones NO excluyentes, debes definir la enumeración con un 
     * mínimo de 7 colores (incluido el None). La aplicación permitirá añadir un color o más a la elección,
     * eliminar un color de los que ya se habían elegido y mostrar los colores elegidos. El programa comenzará 
     * mostrando un menú, con las tres opciónes y la que nos permita salir.
     * Nota: Deberás usar el método LeeEnum, para introducir los datos que se piden al usuario. 
     * Tendrás que crear, como mínimo, un método para cada una de las posibles opciones del menú.
     */

     class Ej05_CustomizarColores
    {  
       [Flags]
       enum Colores
       {
         None = 0b_0000_0000, // 0
         Rojo = 0b_0000_0001, // 1
         Dorado = 0b_0000_0010, // 2
         Negro = 0b_0000_0100, // 4
         Plata = 0b_0000_1000, // 8
         Azul = 0b_001_0000, // 16
         Blanco = 0b_0010_0000, // 32


       }
      
        public static Object LeerEnum(Type tipo, string texto, string textoError)
        {
            do
            {
                Console.Write(texto + ": ");
                string entradaUsuario=Console.ReadLine();
                if ( Enum.IsDefined(tipo,  entradaUsuario)) return Enum.Parse(tipo, entradaUsuario);
                Console.Clear();
                Console.Write(textoError);
                string[] valoresCorrectos = Enum.GetNames(tipo);
                Console.WriteLine("solo se aceptan las respuestas: \n");

                    foreach (string valor in valoresCorrectos)
                        Console.Write(valor + " ");
                    Console.WriteLine("");     
            } while (true);   
        }

      static bool AñadeColor( ref Colores coloresElegidos)
      {
         Colores colorElegido=(Colores)LeerEnum(typeof(Colores),"Introduce un Color", "Color Erroneo\n");
         if((coloresElegidos & colorElegido)!=colorElegido)
         {
            coloresElegidos=coloresElegidos | colorElegido;
            return true;
         }
         else 
         {
            Console.WriteLine("Ese color ya había sido añadido\n");
            return false;
         }   
      }
      static bool QuitaColor( ref Colores coloresElegidos)
      {
         Colores colorElegido=(Colores)LeerEnum(typeof(Colores),"Introduce un Color", "Color Erroneo\n");
         if((coloresElegidos & colorElegido)==colorElegido)
         {
            coloresElegidos&=~colorElegido;
            return true;
         }
         else 
         {
            Console.WriteLine("Ese color no existe en la elección\n");
            return false;
         }   
      }
      static void MuestraColor(Colores coloresElegidos)
      {
          Colores[] colores=(Colores[])Enum.GetValues(typeof(Colores));
            foreach (Colores valor in colores)
            {

                 if((coloresElegidos & valor)==valor) Console.Write(valor + " ");
            }
                        
          Console.WriteLine("");     
      }
       static void MuestraMenu()
        {
             Console.Clear();
             Console.WriteLine( "1. Añadir Color\n"+
                                "2. Eliminar Color\n"+
                                "3. Mostrar Colores Seleccionados\n"+
                                "4. Salir\n");  
        }
        
        static ConsoleKeyInfo LeeOpcion()
        {
            Console.WriteLine("Elige opción: ");
            return Console.ReadKey();
        }
      static void Main(string[] args)
      {
            ConsoleKeyInfo tecla;
            Colores coloresElegidos=default;
            do{
                MuestraMenu();
                tecla=LeeOpcion();
                Console.WriteLine();
                if(tecla.Key!=ConsoleKey.Escape)
                {
                switch(tecla.KeyChar)
                {
                    case '1':
                        AñadeColor(ref coloresElegidos);
                    break;
                    case '2':
                         QuitaColor(ref coloresElegidos);
                    break;
                      case '3':
                         MuestraColor(coloresElegidos);
                    break;
                       case '4':
                         Console.WriteLine("Hasta la próxima!!");
                    break;
                    default:
                    Console.WriteLine("opción Incorrecta");
                    break;
                }
                Console.ReadLine();
                }

            
            }while(tecla.KeyChar!='4');
           
      }
    }
}