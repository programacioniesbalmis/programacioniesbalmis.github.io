using System;

// Crea una enumeraci�n para gestionar una respuesta, que puede ser Si, No, Nose. Para
// eso se necesitaran tres m�todos LeerPregunta, VisualizarRespuesta y LeeEnum. 
// Al m�todo LeerPregunta se le pasar� una cadena que ser� la que se muestre para pedir la
// respuesta y asignar a la constante la respuesta siempre que sea v�lida (para ello
// utilizaremos el m�todo LeeEnum del ejercicio anterior). A VisualizarRespuesta se le
// pasar� la cadena que se mostrar� para visualizar la respuesta y mostrar� el valor de la
// constante enum en ese momento.

namespace Ej04_RespuestSINO
{
    class  Ej04_RespuestSINO
    {
        public enum Respuesta { Si, No, Nose }

        public static void VisualizaRespuesta(string texto, Respuesta respuesta)
        {
            Console.Write(texto + " " + respuesta);
        }

        public static Respuesta LeerPregunta(string pregunta)
        {
            return (Respuesta)LeerEnum(typeof(Respuesta), pregunta, "ERROR: ");
        }

        public static Object LeerEnum(Type tipo, string texto, string textoError)
        {
            Object valorEnumLeido;
            bool entradaCorrecta;
            do
            {
                string entradaUsuario;

                Console.Write(texto + ", ");
                entradaUsuario = Console.ReadLine();
                entradaCorrecta = Enum.IsDefined(tipo, entradaUsuario);

                if (entradaCorrecta)
                    valorEnumLeido = Enum.Parse(tipo, entradaUsuario);
                else
                {
                    valorEnumLeido = null;

                    Console.Clear();
                    Console.Write(textoError);

                    string[] valoresCorrectos = Enum.GetNames(typeof(Respuesta));
                    Console.WriteLine("solo se aceptan las respuestas:");

                    foreach (string valor in valoresCorrectos)
                        Console.Write(valor + " ");
                    Console.WriteLine("");

                }
            }
            while (entradaCorrecta == false);

            return valorEnumLeido;
        }

        static void Main()
        {
            string pregunta = "Si espinete dorm�a con pijama. �Por qu� sal�a desnudo por el barrio?";

            Respuesta respuesta = LeerPregunta(pregunta);

            Console.WriteLine($"Has repondido {respuesta} a la pregunta");
        }
    }
}



