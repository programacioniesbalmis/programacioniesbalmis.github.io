using System;
using System.Text;

namespace Ej03_LeeEnum
{
    /* Crea un m�todo gen�rico llamado LeeEnum, el cual nos servir� para comprobar si una 
     * string introducida por un usuario, pertenece a una enumeraci�n X.
     * Este m�todo tendr� la siguiente signatura:
     * public static Object LeerEnum(Type tipo, string texto, string textoError);
     * Donde:
     * tipo ? El tipo de la enumeraci�n obtenido con la funci�n typeof(IdentificadorEnumeracion).
     * texto ? El texto que se muestra para pedir al usuario que introduzca el valor de la enumeraci�n.
     * textoError ? El texto que se mostrar� si el valor que se introduce no pertenece a la enumeraci�n.
     * Modifica el Ejercicio 2 para usar el m�todo LeeEnum a la hora de recoger el tipo de Abono a comprar.
     * Nota: Este m�todo utilizar� Enum.IsDefined para comprobar si el valor pertenece a la enumeraci�n,
     * Enum.Parse para convertir el string a tipo Enum y Enum.GetNames para crear el array que se mostrar� 
     * en caso de que el dato sea erroneo.*/

     class Ej03_LeeEnum
    {
        enum TipoAbono : int
        {
           QuinceDias=70, TreintaDias=60, FamiliasNumerosas=50, 
           TerceraEdad=30, Discapacidad=20, Juvenil=65, Infantil=35, Turistico=90
        }

          public static Object LeerEnum(Type tipo, string texto, string textoError)
        {
            Object valorEnumLeido = null;
            bool entradaCorrecta;
            do
            {
                string entradaUsuario;

                Console.Write(texto + ": ");
                entradaUsuario = Console.ReadLine();
                entradaCorrecta = Enum.IsDefined(tipo, entradaUsuario);

                if (entradaCorrecta)
                    valorEnumLeido = Enum.Parse(tipo, entradaUsuario);
                else
                {
                    Console.Clear();
                    Console.WriteLine(textoError);

                    string[] valoresCorrectos = Enum.GetNames(tipo);
                    Console.WriteLine("Los valores aceptados son:");
                    foreach (string valor in valoresCorrectos)
                        Console.Write($" {valor}");
                    Console.WriteLine("");
                }
            }
            while (entradaCorrecta == false);

            return valorEnumLeido;
        }
        static int LeeCuantosDias(TipoAbono tipoAbono)
        {
           if(tipoAbono==TipoAbono.QuinceDias) return 15;
           if(tipoAbono==TipoAbono.TreintaDias) return 30;
           do{
               Console.Clear();
               Console.WriteLine("Introduce para cuantos d�as quieres el abono: ");
               int numeroDias=int.Parse(Console.ReadLine());
               if(numeroDias>=7 && numeroDias<=60) return numeroDias;
               Console.WriteLine("Valor no v�lido, los abonos deben ser de 7 a 60 d�as");
               Console.ReadLine();
           }while(true);
        }

       static string CalculoCoste(TipoAbono abono, int numeroDias)
       {
          string salida="El total del precio del abono es ";
          salida+= abono switch 
          {
             TipoAbono.QuinceDias=>(70f/100f*numeroDias).ToString(), 
             TipoAbono.TreintaDias=>(60f/100f*numeroDias).ToString(), 
             TipoAbono.FamiliasNumerosas=>(50f/100f*numeroDias).ToString(),
             TipoAbono.TerceraEdad=>(30f/100f*numeroDias).ToString(),
             TipoAbono.Discapacidad=>(20f/100f*numeroDias).ToString(),
             TipoAbono.Juvenil=>(65f/100f*numeroDias).ToString(),
             TipoAbono.Infantil=>(35f/100f*numeroDias).ToString(),
             TipoAbono.Turistico=>(90f/100f*numeroDias).ToString(),
             _=>(120f/100f*numeroDias).ToString()
          };
          return salida;
       }


        static void Main()
        {
           TipoAbono abono=(TipoAbono)LeerEnum(typeof(TipoAbono), "Introduce el tipo de abono que quieres compra:", "Ese abono no existe");
           Console.WriteLine(CalculoCoste(abono,LeeCuantosDias(abono)));
        }
    }
}