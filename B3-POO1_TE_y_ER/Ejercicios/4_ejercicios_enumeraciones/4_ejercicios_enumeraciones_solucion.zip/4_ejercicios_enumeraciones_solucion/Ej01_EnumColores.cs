using System;
using System.Text;

namespace Ej01_EnumColores
{
    /*Crea una enumeración Colores, la cual inicializarás con los siguientes valores en hexadecimal:
         Rojo → 0xFF0000
         Azul → 0x0000FF
         Verde → 0x00FF00
         Amarillo → 0xFFFF00
         Violeta → 0xC71585
         Blanco → 0xFFFFFF
         Negro → 0x000000
         Gris → 0xCDCDCD
         Marron → 0xA52A2A
     * Recorre todos los elementos de la enumeración, mostrando el nombre del color en el enum y su valor correspondiente en hexadecimal.
     * Pide un color al usuario y muestra su valor en hexadecimal, si existe en la enumeración, o un mensaje de error si no existe.
     * El programa deberá recoger una cadena con el nombre y apellidos de un usuario, 
     * separados el primero de los últimos por una coma. Se encargara de modificar la 
     * cádena (StringBuilder) de forma que, si introducimos:
     * Jose Luis, Garcia Pont
     * Se debe obtener:
     * Garcia Pont, J.L.
     * Además deberá de generar el nombre del usuario que será las iniciales del apellidos y
     *  nombre seguidas de tres números aleatorios.
     * La salida sería algo parecido a:
     * Garcia Pont, J.L. ---> GPJL359
     * Nota: Una persona puede tener uno o más de un nombre (se identificará por la separación con ','). 
     * Asumiremos que no existen nombres ni apellidos del tipo “de...”, “de las...”, “de la...
     *  y que los apellidos siempre serán dos no compuestos.
    */
     class Ej01_EnumColores
    {
        enum Color : int
        {
            Rojo = 0xFF0000,
            Azul = 0x0000FF,
            Verde = 0x00FF00,
            Amarillo = 0xFFFF00,
            Violeta = 0xC71585,
            Blanco = 0xFFFFFF,
            Negro = 0x000000,
            Gris = 0xCDCDCD,
            Marron = 0xA52A2A
        }

        static string ACadena(Color color)
        {
            string textoColor = $"{color:X}";
            textoColor = textoColor.Substring(2, textoColor.Length - 2);
            return "0x" + textoColor;
        }

        static void MuestraColores()
        {
            string[] textosColores = Enum.GetNames(typeof(Color));

            Console.WriteLine("Colores:");
            for (int i = 0; i < textosColores.Length; i++)
                Console.WriteLine($"{textosColores[i],-8} = {ACadena((Color)Enum.Parse(typeof(Color), textosColores[i]))}");
            Console.Write("\n");
        }


        static void Main()
        {
            MuestraColores();

            Console.Write("Introduce un color: ");
            string textoColor = Console.ReadLine();

            if (Enum.IsDefined(typeof(Color), textoColor) == true)
                Console.WriteLine($"{textoColor} = {ACadena((Color)Enum.Parse(typeof(Color), textoColor))}");
            else
                Console.WriteLine($"El color {textoColor}, no es un color válido de la lista de colores.");
        }
    }
}