using System;
using System.Text.RegularExpressions;       //Necesario para las expresiones regulares.

namespace Ej02_ComprobarFromatoCIF
{
   /* Se nos pide hacer un programa en C# que compruebe el formato de entrada
    * de un número de cuenta por teclado, utilizando expresiones regulares (del ejercicio 1 parte 6).
    * Además debe indicar, tras la entrada, que dígitos corresponden a la entidad, 
    * cuales a la sucursal, los dígitos de control y el número de cuenta, para esto utilizaremos la captura con grupos.
    * Opcional: Puedes comprobar si el número de cuenta es válido calculando los dígitos de control 
    * que debería tener, y comprobando si coinciden con los de la introducida.
    * Puedes buscar por Internet como se calcula el dígito de control de una cuenta bancaria.
   */

    class Ej02_ComprobarFromatoCIF
    {
        static bool ValidaExpresion(string cadenaValidar, string cadenaPatron)
        {
            Regex patron = new Regex(cadenaPatron);

            if (patron.IsMatch(cadenaValidar)) return true;
            else return false;
        }


        static string ValidaCIF(string cif, string textoError)
        {
            string patronFecha = @"^[A-HK-NPQSa-hk-npqs][\s-]?\d{2}\d{5}[\s-]?([A-Ja-j]|\d)$";

            if (ValidaExpresion(cif, patronFecha)) return cif;
            else return textoError + "\n " + patronFecha;
        }


        static void Main(string[] args)
        {
            Console.Write("\n INTRODUCE CIF: ");
            Console.WriteLine("\n " + ValidaCIF(Console.ReadLine(), @"Error: formato incorrecto."));
        }
    }
}

  