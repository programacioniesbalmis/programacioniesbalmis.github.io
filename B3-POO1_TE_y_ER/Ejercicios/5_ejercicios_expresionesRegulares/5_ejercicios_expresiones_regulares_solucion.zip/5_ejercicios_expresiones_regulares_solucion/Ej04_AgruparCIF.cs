using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Ej04_AgruparCIF
{
	 /* Se nos pide hacer un programa en C# que compruebe el formato de entrada y etiquete cada grupo del C.I.F., 
      * de una cadena introducida por teclado.
      */
    class Ej04_AgruparCIF
    {
        static void ValidarCIF(string cif, string textoError)
        {
            string patronFecha = @"^(?<ORG>[A-HK-NPQSa-hk-npqs])[\s-]?(?<CP>\d{2})(?<NP>\d{5})[\s-]?(?<DC>([A-Ja-j]|\d))$";

            Regex patron = new Regex(patronFecha);
            Match coincidencia = patron.Match(cif);

            if (coincidencia.Success)
            {
                Console.WriteLine("\n");
                Console.WriteLine(" Letra de tipo de Organización: {0}", coincidencia.Groups["ORG"].Value.ToUpper());
                Console.WriteLine(" Código Provincial numérico: {0}", coincidencia.Groups["CP"].Value);
                Console.WriteLine(" Numeración secuencial dentro de la provincia: {0}", coincidencia.Groups["NP"].Value);
                Console.WriteLine(" Dígito de control: {0}", coincidencia.Groups["DC"].Value.ToUpper());
            }
            else
            {
                Console.WriteLine(textoError + "\n " + patronFecha);
            }
        }

        static void Main(string[] args)
        {
            Console.Write("\n INTRODUCE UN CIF: (T-PPNNNNN-C)\n ");
            ValidarCIF(Console.ReadLine(), @"Error: formato incorrecto.");

            Console.WriteLine("\n");
            Console.ReadKey(true);
        }
    }
}
