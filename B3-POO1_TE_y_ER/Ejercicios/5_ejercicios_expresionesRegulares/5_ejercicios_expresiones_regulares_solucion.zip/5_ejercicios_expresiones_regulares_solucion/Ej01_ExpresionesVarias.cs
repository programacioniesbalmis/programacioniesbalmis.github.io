using System;
using System.Text.RegularExpressions;       //Necesario para las expresiones regulares.

namespace Ej01_ExpresionesVarias
{
    class Ej01_ExpresionesVarias
    {
    
        static void Valida(string patron, string textoEntrada)
        {            
            Console.WriteLine(textoEntrada);
            string cadena=Console.ReadLine();
            Regex regex = new Regex(patron);
            if (regex.IsMatch(cadena)) Console.WriteLine("Formato correcto");
            else Console.WriteLine("Formato incorrecto");
        }
        static void Main(string[] args)
        {
            Valida(@"^[+-]?\d+$","\n INTRODUCE UN NÚMERO ENTERO: ");
            Valida( @"^[+-]?(\d+)|(\d*[.,]\d+)$","\n INTRODUCE UN NUMERO DECIMAL: ");
            Valida(@"[+-]?((\d+)|(\d*[.,]\d+))([eE][+-]?\d+)?" ,"\n INTRODUCE UN NUMERO REAL: ");
            
            string patronMatriculaAnti = @"([a-zA-Z]{2}[\s-]\d{4}[\s-][a-zA-Z])";
            string patronMatriculaEU = @"(\d{4}[\s-][a-zA-Z]{3})";
            string patronMatricula = "^" + patronMatriculaAnti + "|" + patronMatriculaEU + "$";
            Valida(patronMatricula,"\n INTRODUCE UNA MATRÍCULA: ");
            Valida(@"^\d{4}[\s-]\d{4}[\s-]\d\d[\s-]\d{10}$","\n INTRODUCE NUMERO DE CUENTA (EEEE-SSSS-CC-NNNNNNNNNN): ");
          
           
            Console.ReadKey();
        }
    }
}
