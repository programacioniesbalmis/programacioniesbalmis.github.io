using System;
using System.Text;
using System.Text.RegularExpressions;

namespace Ej06_ValidarEntradas
{
    /* Escribe un programa con los métodos necesarios para no repetir código,
     * y que sirva para validar las siguientes entradas de texto:
     * Una o más letras sueltas separadas por espacios. Por ejemplo, "a c é" es válida, pero "a c de" no o "a c d " tampoco.
     * Una o más palabras (sólo letras inglesas minúsculas, separadas por uno o varios espacios).
     * una única palabra en mayúsculas.
     * Contraseña (al menos seis caracteres, puede contener letras, números y los caracteres * + . - _,
     * pero no espacios u otros caracteres).
     * Nota: Salvo que se indique lo contrario, las letras pueden ser minúsculas o mayúsculas. 
     * Si el enunciado dice letras inglesas, quiere decir que no se aceptan vocales acentuadas, ñ, ç, etc.
     */

     class Ej06_ValidarEntradas
    {  
        static bool ValidarExpresion(string patron, string cadena)
        {
            Regex patronRegex= new Regex(patron);

            if (patronRegex.IsMatch(cadena)) return true;
            else return false;
        }

        static string Validar(string patron, string cadena, string textoError)
        {            
            if (ValidarExpresion( patron, cadena)) return cadena;
            else return textoError + "\n " + patron;
        }

        static void Main(string[] args)
        {
            string patronEjer1 = @"^([a-zñçA-ZÑÇáéíóúüïàèòÀÈÒÁÉÍÓÚÜÏ] )*[a-zñçA-ZÑÇáéíóúüïàèòÀÈÒÁÉÍÓÚÜÏ]$";
            Console.Write("\n Introduce letras separadas por espacios: ");
            //Console.WriteLine("\n " + Validar(patronEjer1, Console.ReadLine(), @"ERROR: formato incorrecto."));
            string patronEjer2 = @"^([a-z]+ +)*[a-z]+$";
            Console.Write("\n Introduce una o màs palabras: ");
           //Console.WriteLine("\n " + Validar(patronEjer2, Console.ReadLine(), @"ERROR: formato incorrecto."));
            string patronEjer3 = @"^[A-Z]+$";
            Console.Write("\n Introduce una palabra en mayúsculas: ");
           // Console.WriteLine("\n " + Validar(patronEjer3, Console.ReadLine(), @"ERROR: formato incorrecto."));
            string patronEjer4 = @"^([a-zñçA-ZÑÇáéíóúüïàèòÀÈÒÁÉÍÓÚÜÏ1-9\*+\.-_,]){6,}$";
            Console.Write("\n Introduce contraseña con más de 6 carácteres: ");
            Console.WriteLine("\n " + Validar(patronEjer4, Console.ReadLine(), @"ERROR: formato incorrecto."));

           
        }
    }
}