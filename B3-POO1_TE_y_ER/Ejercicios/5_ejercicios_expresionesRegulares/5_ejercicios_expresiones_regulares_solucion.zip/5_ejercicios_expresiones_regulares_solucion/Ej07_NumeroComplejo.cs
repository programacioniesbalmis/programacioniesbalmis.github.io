

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Ej07_NumeroComplejo
{
	/* Programa que compruebe con una expresión regular, si un número introducido es un número complejo.
	 * Nota: Un numero complejo en su forma binomial se representará como a + bi o a + bj siendo a y b números reales.
	 * Correctos: -2,3 + 5e-2j → 7i → 2E+5 + 2,3i
	*/
    class Ej07_NumeroComplejo
    {
        static bool ValidaExpresion(string cadenaValidar, string cadenaPatron)
        {
            Regex patron = new Regex(cadenaPatron);

            if (patron.IsMatch(cadenaValidar)) return true;
            else return false;
        }


        static string ValidaNumComplejo(string complejo, string textoError)
        {
 	    string patronReal = @"[+-]?((\d+)|(\d*[.,]\d+))([eE][+-]?\d+)?";
            string patronComplejo = @"^((" + patronReal + @")|(" + patronReal + @"[\s][+-][\s]" + patronReal + @"[ij])|(" + patronReal + "[ij]))$";

            if (ValidaExpresion(complejo, patronComplejo)) return complejo;
            else return textoError + "\n " + patronComplejo;
        }

        static void Main(string[] args)
        {
            Console.Write("\n INTRODUCE UN NUMERO COMPLEJO: ");
            Console.WriteLine(ValidaNumComplejo(Console.ReadLine(), @"ERROR: formato incorrecto."));
        }
    }
}
