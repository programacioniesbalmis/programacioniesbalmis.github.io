using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Ej05_CalgularDC_CIF
{
	/* Para el ejercicio anterior calcula, además, el dígito de control para el C.I.F.
	 * Deberás comprobar si el C.I.F. es correcto teniendo en cuenta dos cosas: 
	 * el formato y la corrección del C.I.F. a partir del dígito de control.
	 * Nota: Buscar por Internet como se calcula el dígito de control de un C.I.F.
	 */
    class Ej05_CalgularDC_CIF
    {
        static bool ValidaDigitoControlCIF(string cif)
        {
            char letra = char.Parse(cif.Substring(0, 1).ToUpper());         //Letra.
            string numeros = cif.Substring(1, 7);                           //Parte numética sin digito de control.
            char digControl = char.Parse(cif.Substring(8, 1).ToUpper());    //Dígito de control

            string soloLetra = "KPQS";
            string soloNumero = "ABEH";
            string digitosControl = "JABCDEFGHI";
            
            int sumaPares = 0;
            int sumaImpares = 0;
            int tempImpares = 0;
            int sumaTotal = 0;

            for (int i = 1; i <= numeros.Length; i++)
            {
                if (i % 2 == 0) sumaPares += int.Parse(numeros.Substring(i - 1, 1));    //Pares
                else if (i % 1 == 0)                                                    //Impares
                {
                    tempImpares = 2 * int.Parse(numeros.Substring(i - 1, 1));
                    tempImpares = (tempImpares % 10) + (tempImpares / 10);
                    sumaImpares += tempImpares;
                }
            }

            sumaTotal = sumaPares + sumaImpares;
            sumaTotal = (10 - (sumaTotal % 10)) % 10;

            /* Comprobar primera letra */
            if (soloLetra.Contains(letra) && (digitosControl[sumaTotal] == digControl))  //Código Control será una letra.
            {
                return true;
            }
            else if (soloNumero.Contains(letra) && ((char)sumaTotal + 48) == digControl)     //Código Cntrol será un número.
            {
                return true;
            }
            else if (!soloLetra.Contains(letra) && !soloNumero.Contains(letra) && (
                    (digitosControl[sumaTotal] == digControl) || ((char)sumaTotal + 48 == digControl)))
            {
                return true;
            }
            else return false;
        }


        static bool ValidaCIF(string cif)
        {   
            string patronFecha = @"^(?<ORG>[A-HK-NPQSa-hk-npqs])[\s-]?(?<CP>\d{2})(?<NP>\d{5})[\s-]?(?<DC>([A-Ja-j]|\d))$";

            Regex patron = new Regex(patronFecha);
            Match coincidencia = patron.Match(cif);

            string estandarCIF = (coincidencia.Groups["ORG"].Value.ToUpper() + coincidencia.Groups["CP"].Value.ToString() +
                                  coincidencia.Groups["NP"].Value.ToString() + coincidencia.Groups["DC"].Value.ToUpper());

            if (coincidencia.Success && ValidaDigitoControlCIF(estandarCIF))
            {
                return true;
            }
            else if (coincidencia.Success == false)
            {
                Console.WriteLine("Error: formato incorrecto.\n " + patronFecha);
                return false;
            }
            else
            {
                Console.WriteLine("Dígito de Control del CIF incorrecto");
                return false;
            }
        }


        static void Main(string[] args)
        {
            Console.Write("\n INTRODUCE UN CIF: ");
            if (ValidaCIF(Console.ReadLine())) Console.WriteLine("\n CIF válido");
        }
    }
}
