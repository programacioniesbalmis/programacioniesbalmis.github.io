using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;


namespace Ej03_NumeroCuenta
{
   /* Se nos pide hacer un programa en C# que compruebe el formato de entrada de un número de cuenta por teclado, utilizando expresiones regulares (del ejercicio 1 parte 6).
Además debe indicar, tras la entrada, que dígitos corresponden a la entidad, cuales a la sucursal, los dígitos de control y el número de cuenta, para esto utilizaremos la captura con grupos.
Opcional: Puedes comprobar si el número de cuenta es válido calculando los dígitos de control que debería tener, y comprobando si coinciden con los de la introducida.
Puedes buscar por Internet como se calcula el dígito de control de una cuenta bancaria.
   */
    class Ej03_NumeroCuenta
    {
        static void ValidaCuenta(string cuenta, string textoError)
        {
            string patronCuenta = @"^(?<Entidad>\d{4})[\s-](?<Sucursal>\d{4})[\s-](?<DC1>\d{1})(?<DC2>\d{1})[\s-](?<Cuenta>\d{10})$";

            Regex patron = new Regex(patronCuenta);

            Match coincidencia = patron.Match(cuenta);

            if (coincidencia.Success)
            {
                Console.WriteLine("\n");
                Console.WriteLine(" Entidad: {0}", int.Parse(coincidencia.Groups["Entidad"].Value));
                Console.WriteLine(" Sucursal: {0}", int.Parse(coincidencia.Groups["Sucursal"].Value));
                Console.WriteLine(" DC1: {0}", int.Parse(coincidencia.Groups["DC1"].Value));
                Console.WriteLine(" DC2: {0}", int.Parse(coincidencia.Groups["DC2"].Value));
                Console.WriteLine(" Nº Cuenta: {0}", int.Parse(coincidencia.Groups["Cuenta"].Value));
            }
            else
            {
                Console.WriteLine(textoError + "\n " + patronCuenta);
            }
        }

        static void Main(string[] args)
        {
            Console.Write("\n INTRODUCE UN Nº DE CUENTA: (EEEE-SSSS-CC-NNNNNNNNNN)\n ");
            ValidaCuenta(Console.ReadLine(), @"Error: formato incorrecto.");
            
            Console.WriteLine("\n");
            Console.ReadKey(true);
        }
    }
}
