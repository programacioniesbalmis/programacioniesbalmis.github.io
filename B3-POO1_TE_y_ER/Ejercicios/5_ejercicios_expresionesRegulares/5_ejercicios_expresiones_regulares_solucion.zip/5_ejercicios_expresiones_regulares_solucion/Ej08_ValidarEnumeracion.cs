using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Ej08_ValidarEnumeracion
{
	/* Expresión regular que encuentre definiciones de tipos enumerados, en una cadena de consumo.
	 * Para simplificar supondremos las siguiente sintaxis para los tipos enumerados, respetando espacios:
     *                 enum Nombre {Valor1,Valor2,Valor3,…,ValorN}
	*/
    class Ej08_ValidarEnumeracion
    {
        static bool ValidaExpresion(string cadenaValidar, string cadenaPatron)
        {
            Regex patron = new Regex(cadenaPatron);

            if (patron.IsMatch(cadenaValidar)) return true;
            else return false;
        }


        static string ValidaDefinicionEnum(string defEnum, string textoError)
        {
            string patronDefEnum = @"^enum [A-Z]\w* {([A-Z][a-z0-9]*[,])*([A-Z][a-z0-9]*)}$";


            if (ValidaExpresion(defEnum, patronDefEnum)) return defEnum;
            else return textoError + "\n " + patronDefEnum;
        }


        static void Main(string[] args)
        {
            Console.Write("\n ESCRIBE LA DEFINICIÓN DE UN ENUM: ");
            Console.WriteLine(ValidaDefinicionEnum(Console.ReadLine(), @"ERROR: formato incorrecto."));
        }
    }
}
