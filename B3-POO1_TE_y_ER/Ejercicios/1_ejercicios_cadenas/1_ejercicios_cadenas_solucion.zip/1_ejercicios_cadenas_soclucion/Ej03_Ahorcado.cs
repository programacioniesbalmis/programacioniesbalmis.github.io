using System;
using System.Text;

class Ejercicio3
{
    static string PidePalabraAAdivinar()
    {
        Console.Write("Introduce la palabra a adivinar: ");
        return Console.ReadLine().ToUpper();
    }

    static int PideMaximoFallos()
    {
        Console.Write("Introduce el número máximo de fallos: ");
        return int.Parse(Console.ReadLine());
    }


    static bool EstaLetraEnLetras(char letra, string letras)
    {
        return letras.IndexOf(letra) >= 0;
    }

    static char PideLetra(
                    string palabraParcialmenteAdivinada,
                    string letrasFalladas)
    {
        bool swEsta;
        char letra;
        do
        {
            Console.Write("Introduce una letra: ");
            letra = Console.ReadLine()[0];
            swEsta = EstaLetraEnLetras(letra, palabraParcialmenteAdivinada) ||
                     EstaLetraEnLetras(letra, letrasFalladas);
            if (swEsta)
                Console.WriteLine($"La letra {letra} ya fue introducida.");
        }
        while (swEsta);

        return char.ToUpper(letra);
    }

    static void MuestraEstadoJuego(
                    string palabraParcialmenteAdivinada,
                    string letrasFalladas)
    {
        Console.Write("\nPalabra: ");
        for (int i = 0; i < palabraParcialmenteAdivinada.Length; i++)
            Console.Write($"{palabraParcialmenteAdivinada[i]} ");
        Console.Write("\n");
        Console.Write("Fallos: ");
        for (int i = 0; i < letrasFalladas.Length; i++)
            Console.Write($"{letrasFalladas[i]} ");
        Console.Write("\n");
    }

    static void AñadeLetraALetrasPalabraAMostrar(
                    string palabraAAdivinar,
                    in char letra,
                    StringBuilder palabraParcialmenteAdivinada)
    {
        int posicion = -1;

        do
        {
            posicion = palabraAAdivinar.IndexOf(letra, ++posicion);
            if (posicion >= 0)
                palabraParcialmenteAdivinada[posicion] = letra;
        }
        while (posicion >= 0);
    }


    static bool FinDeJuego(
                    int numFallos, int maxFallos,
                    string palabraAAdivinar, string palabraParcialmenteAdivinada,
                    out string mensajeSiFin)
    {
        bool swFin;
        if (numFallos >= maxFallos)
        {
            mensajeSiFin = "Lo siento has llegado al máximo de fallos permitido.\n";
            mensajeSiFin += string.Format("La palabraAAdivinar era: {0}.", palabraAAdivinar);
            swFin = true;
        }
        else if (palabraAAdivinar == palabraParcialmenteAdivinada)
        {
            mensajeSiFin = "ENHORABUENA LO HAS CONSEGUIDO";
            swFin = true;
        }
        else
        {
            mensajeSiFin = "";
            swFin = false;
        }
        return swFin;
    }

    static void Jugar(string palabraAAdivinar, int maximoFallos)
    {
        StringBuilder palabraParcialmenteAdivinada = new StringBuilder();
        StringBuilder letrasFalladas = new StringBuilder();
        bool swFin;

        palabraParcialmenteAdivinada.Append('_', palabraAAdivinar.Length);
        MuestraEstadoJuego(palabraParcialmenteAdivinada.ToString(), letrasFalladas.ToString());
        do
        {
            char letra = PideLetra(palabraParcialmenteAdivinada.ToString(), letrasFalladas.ToString());

            if (EstaLetraEnLetras(letra, palabraAAdivinar))
                AñadeLetraALetrasPalabraAMostrar(palabraAAdivinar, letra, palabraParcialmenteAdivinada);
            else
                letrasFalladas.Append(letra);

            MuestraEstadoJuego(palabraParcialmenteAdivinada.ToString(), letrasFalladas.ToString());

            swFin = FinDeJuego(
                        letrasFalladas.Length, maximoFallos, palabraAAdivinar, palabraParcialmenteAdivinada.ToString(),
                        out string mensajeSiFin);
            if (swFin)
                Console.WriteLine(mensajeSiFin);
        }
        while (!swFin);
    }

    static void Main()
    {
        Console.ForegroundColor = ConsoleColor.Black;
        Console.BackgroundColor = ConsoleColor.White;
        Console.Clear();
        string palabraAAdivinar = PidePalabraAAdivinar();
        int maxFallos = PideMaximoFallos();
        Console.Clear();
        Jugar(palabraAAdivinar, maxFallos);
        Console.ReadKey();
    }
}