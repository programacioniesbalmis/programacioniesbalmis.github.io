string PidePalabraAAdivinar()

int PideMaximoFallos()

bool EstaLetraEnLetras(char letra, string letras)

char PideLetra(
         string palabraParcialmenteAdivinada,
         string letrasFalladas)

void MuestraEstadoJuego(
         string palabraParcialmenteAdivinada,
         string letrasFalladas)

bool SeAñadeLetraALetrasPalabraAMostrar(
         string palabraAAdivinar,
         char letra,
         StringBuilder palabraParcialmenteAdivinada)

bool FinDeJuego(
         int numFallos, int maxFallos,
         string palabraAAdivinar, string palabraParcialmenteAdivinada,
         out string mensajeSiFin)

void Jugar(string palabraAAdivinar, int maximoFallos)


