using System;

namespace Ej01_FuncionalidadString
{
	 /* Realiza un programa que se repita hasta pulsar ESC. En el aparecerá un menú
      * con  8 opciones que corresponderán a los siguientes ejercicios. Utiliza un switch 
      * para seleccionar cada opción y los métodos necesarios para que el programa quede
      * claro y no se repita código:
      * 1. Lee una cadena y a continuación muestra en pantalla su longitud.
      * 2. Introduce una cadena y una subcadena y muestra en que posición comienza la última
           aparición de la subcadena.
      * 3. Lee un nombre y luego muestre ese mismo nombre pero con todas las letras en mayúsculas.
      * 4. Introduciremos una cadena por teclado y encadenaremos la cadena “LA CADENA FIN HA SIDO AÑADIDA A NUESTRA CADENA” 
          (utiliza un método de la clase String para resolverlo). Visualizaremos el resultado por pantalla.
      * 5. Introduce una cadena y elimina los N caracteres a partir de la posición P indicada.
           Mostrando posteriormente el resultado.
      * 6. Introduce una cadena y elimina todos los carácteres de espaciado, saltos de línea o puntos 
           que se puedan encontrar al final de ella (utiliza triming para resolverlo).
      * 7. Introduce una cadena y un número. Añade al final de la cadena tantos carácteres ! como el número
           introducido (utiliza Padding para resolverlo).
      * 8. Introduce un texto y posteriormente dos cadenas. Sustituye las apariciones de la primera
           cadena en el texto por la segunda cadena. Mostrando posteriormente el resultado.
      ***Nota:** Para no repetir código a la hora de recoger la cádena para los distintos puntos, 
      * puedes crear un método encargado de esa función.    class Ej01_FuncionalidadString*/
    
      
        static void MuestraMenu()
        {
             Console.Clear();
             Console.WriteLine( "1. Longitud cadena\n"+
                                "2. Posición subcadena\n"+
                                "3. Pasa a mayúsculas\n"+
                                "4. Encadenar al final\n"+
                                "5. Eliminar carácteres\n"+
                                "6. Eliminar carácteres final\n"+
                                "7. Añadir ! al final\n"+
                                "8. Sustituir Subcadena\n");  
        }
        
        static ConsoleKeyInfo LeeOpcion()
        {
            Console.WriteLine("Elige opción: ");
            return Console.ReadKey();
        }
        static string LeeCadena(string cadena)
        {
            Console.WriteLine(cadena);
            return Console.ReadLine();
        }
        
        static void PosicionSubcadena()
        {
            string cadena=LeeCadena("Introduce una cadena: ");
            string subcadena=LeeCadena("Introduce una subcadena: ");
            Console.WriteLine(cadena.Contains(subcadena)?cadena.LastIndexOf(subcadena).ToString():"La cadena no contiene a la subcadena");
        }

        static void ElimnaCaracteres()
        {
            string cadena=LeeCadena("Introduce una cadena: ");
            Console.WriteLine("Introduce una posición desde donde comenzar a eliminar");
            int posicion=int.Parse(Console.ReadLine());
            Console.WriteLine("Introduce el número de carácteres a eliminar");
            int numero=int.Parse(Console.ReadLine());
            Console.WriteLine(cadena.Length>posicion-1+numero?cadena.Remove(posicion-1,numero):"La cadena no tiene tantos carácteres");
        }
         static void AñadeFinal()
        {
            string cadena=LeeCadena("Introduce una cadena: ");
            Console.WriteLine("Introduce el número de carácteres a añadir");
            int numero=int.Parse(Console.ReadLine());
            Console.WriteLine(cadena.PadRight(cadena.Length+numero,'!'));
        }
        static void SustituyeCadenas()
        {
            string cadena=LeeCadena("Introduce una cadena: ");
            string cadenaSustituir=LeeCadena("Introduce una subcadena a sustituir: ");
            string cadenaSustitututa=LeeCadena("Introduce una subcadena sustituta: ");
            Console.WriteLine(cadena.Replace(cadenaSustituir,cadenaSustitututa));
        }
        static void Main()
        {
            ConsoleKeyInfo tecla;
            do{
                MuestraMenu();
                tecla=LeeOpcion();
                Console.WriteLine();
                if(tecla.Key!=ConsoleKey.Escape)
                {
                switch(tecla.KeyChar)
                {
                    case '1':
                        Console.WriteLine("La longitud es: "
                                          + LeeCadena("Introduce una cadena para mostrar su longitud:").Length);
                    break;
                    case '2':
                         PosicionSubcadena();
                    break;
                    case '3':
                        Console.WriteLine("El nombre en mayúsculas es: "
                                           + LeeCadena("Introduce una cadena para mostrarla en mayúsculas: ").ToUpper());
                    break;
                    case '4':
                        string cadena= LeeCadena("Introduce una cadena para añadirle un final: ");
                        Console.WriteLine(cadena.Length==0?"La cadena no puede ser vacia":cadena.Insert(cadena.Length," LA CADENA FIN HA SIDO AÑADIDA A NUESTRA CADENA"));
                    break;
                    case '5':
                        ElimnaCaracteres();
                    break;
                    case '6':
                        const string caracteres="\t \n.";
                        Console.WriteLine("Cadena sin carácteres al final: "
                                          + LeeCadena("Introduce una cadena para eliminar carácteres: ").TrimEnd(caracteres.ToCharArray()));
                    break;
                    case '7':
                        AñadeFinal();
                    break;
                    case '8':
                        SustituyeCadenas();
                    break;
                    default:
                    Console.WriteLine("opción Incorrecta");
                    break;
                }
                Console.ReadLine();
                }

            
            }while(tecla.Key!=ConsoleKey.Escape);

           
        }
    }
}