using System;
using System.Text;

namespace Ej02_StringBuilder
{
    /* Programa para practicar con StringBuilder (obligatorio su uso). El programa deberá recoger
     * una cadena con un texto que pasaremos a codificar u ofuscar. Para ello crearemos tres tipos
     * de codificación, cada una la realizaremos en un método diferente y se usará StringBuilder
     * para desarrollarla. Consisten en lo siguiente:
     * 1. Codificación especular, es la famosa manera que tenía Leonardo Da Vinci de escribir
     * volviendo las palabras del revés, de forma que es más sencillo su lectura mediante un
     * espejo.
     * 2. Codificación ofuscación cambiando carácteres de puntuación, esta manera de
     * ofuscar la frase será mediante el cambio de los carácteres de puntuación (, : . ; ? ¿ ! ¡),
     * por algunos carácteres especiales generados aleatoriamente.
     * 3. Codificación ofuscación quitando espacios en blanco, en este caso solamente se
     * eliminarán los espacios en blanco que hayan en la frase.
     * Un ejemplo de ejecución sería el siguiente:
     * Introduce la frase a ofuscar:
     * La verdadera felicidad cuesta poco; si es cara, no es de buena clase.
     * aL aredadrev dadicilef atseuc ;ocop is se ,arac on se ed aneub esalc
     * aL aredadrev dadicilef atseuc ëocop is se íarac on se ed aneub esalc
     * aLaredadrevdadicilefatseucâocopisseçaraconseedaneubesalc
    */
    class Ej02_StringBuilder
    {
        static Random generador = new Random();
        static String LeeTexto()
        {
            Console.WriteLine("Introduce el nombre completo de usuario");
            return Console.ReadLine();
        }
        static string OfuscacionCaracteresPuntuacion(string texto)
        {
            const string caracteres = ",.:!?¿;¿";
            StringBuilder textoATransformar = new StringBuilder(texto);
            for (int i = 0; i < texto.Length; i++)
            {
                if (caracteres.Contains(textoATransformar[i]))
                    textoATransformar[i] = (char)generador.Next(224, 238);
            }
            return textoATransformar.ToString();
        }
        static string OfuscacionEspaciado(string texto)
        {
            StringBuilder textoATransformar = new StringBuilder(texto);
            for (int i = 0; i < textoATransformar.Length; i++)
            {
                if (textoATransformar[i] == ' ') textoATransformar.Remove(i--, 1);
            }
            return textoATransformar.ToString();
        }

        static string AEspecular(String texto)
        {
            int seguir;
            StringBuilder textoATransformar = new StringBuilder(texto);
            for (int i = 0, inicioPalabra = 0; i < texto.Length; i++)
            {
                if (textoATransformar[i] == ' ' || textoATransformar[i] == '.' || i == texto.Length - 1)
                {
                    seguir = i;
                    for (int j = inicioPalabra, numeroVeces = 0; numeroVeces < (seguir - inicioPalabra) / 2; i--, j++, numeroVeces++)
                    {
                        char aux = textoATransformar[i - 1];
                        textoATransformar[i - 1] = textoATransformar[j];
                        textoATransformar[j] = aux;
                    }
                    i = seguir;
                    inicioPalabra = seguir + 1;
                }

            }
            return textoATransformar.ToString();
        }


        static void Main()
        {
            string texto = LeeTexto();
            Console.WriteLine(AEspecular(texto));
            Console.WriteLine(OfuscacionCaracteresPuntuacion(AEspecular(texto)));
            Console.WriteLine(OfuscacionEspaciado(OfuscacionCaracteresPuntuacion(AEspecular(texto))));
        }
    }
}
