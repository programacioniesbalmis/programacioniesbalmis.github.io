﻿using System;

#region Ej06_MayorNumeroSerie
namespace Ej06_MayorNumeroSerie
{
    class Ej06_MayorNumeroSerie
    {
        /* Crea un array de 10 elementos, calcula e imprime el elemento mayor de la
         * serie y el lugar que ocupa. Si hay varios iguales, sólo el primero.
         */

        static int[] LeeArray(ulong tamaño)
        {
            int[] array = new int[tamaño];

            for (ulong i = 0; i < (ulong)array.Length; i++)
            {
                Console.Write($"Introduzca valor [{i}]: ");
                array[i] = int.Parse(Console.ReadLine());
            }

            return array;
        }

        static int MayorElementoVector(int[] array, out ulong indice)
        {
            int mayor = array[0];
            indice = 0;

            for (ulong i = 0; i < (ulong)array.Length; i++)
            {
                if (array[i] > mayor)
                {
                    mayor = array[i];
                    indice = i;
                }
            }

            return mayor;
        }

        static void Main()
        {
            int[] array = LeeArray(10);

            ulong indiceMayor;
            int mayor = MayorElementoVector(array, out indiceMayor);

            Console.WriteLine($"Mayor valor del array: {mayor} en posición {indiceMayor}\n");
        }
    }
}
#endregion

