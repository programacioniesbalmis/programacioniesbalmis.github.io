﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

#region Ej01_ImprimirArrayForeach
namespace Ej01_ImprimirArrayForeach
{
    class Ej01_ImprimirArrayForeach
    {
        /* Realiza un programa que asigne datos a un array de n elementos, y a 
         * continuación escribe el contenido de dicho array utilizando la 
         * instrucción foreach.
         */

        static int[] LeeArray(int tamaño)
        {
            int[] array = new int[tamaño];

            for (int i = 0; i < array.Length; i++)
            {
                Console.Write($"Introduzca valor [{i}]: ");
                array[i] = int.Parse(Console.ReadLine());
            }

            return array;
        }

        static void VisualizaArray(int[] array)
        {
            Console.Write("\nLos valores del array introducido son: ");
            foreach (var valor in array)
                Console.Write(valor + " ");
            Console.Write("\n");
        }

        static void Main()
        {
            Console.Write("Introduzca cantidad de elementos para el array: ");
            int tamaño = int.Parse(Console.ReadLine());

            int[] array = LeeArray(tamaño);
            VisualizaArray(array);
        }
    }
}
#endregion

