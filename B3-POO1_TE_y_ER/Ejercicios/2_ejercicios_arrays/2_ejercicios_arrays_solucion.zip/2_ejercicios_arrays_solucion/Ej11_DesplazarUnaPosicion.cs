using System;
using System.Text;

namespace Ej11_DesplazarUnaPosicion
{
    /* Introduce un array de 10 elementos y desplaza todos sus componentes una posición hacia la
     * derecha, colocando el último en la primera posición. Visualiza el array antes y después del
     * desplazamiento.
     */

     class Ej11_DesplazarUnaPosicion
    {
         static int[] RecogeNumeros()
         {
            int[] numeros=new int[5];
            
            for(int i=0;i<numeros.Length  ;i++)
            {
              Console.WriteLine("Introduce un número: ");
              numeros[i]=int.Parse(Console.ReadLine());
            }
            return numeros;
         }
         static void DesplazaUnaPosicion(int[] numeros)
         {
            int ultimo=numeros[numeros.Length-1];
            int aux=0;
           
            for(int i =numeros.Length-1; i>=0 ;i--) 
            {
               if(i<numeros.Length-1) numeros[i+1]=aux;
               if(i>0)
               {
                 aux= numeros[i-1];
                 numeros[i-1]=numeros[i];
               }
            } 
            numeros[0]=ultimo;     
         }

          static void MuestraNumeros(int[] array)
         {
            Console.WriteLine("\nLos números son:");
            foreach(int x in array)  Console.Write($"{x} - ");
         }
        static void Main()
        {
          
           int[] numeros=RecogeNumeros();
           MuestraNumeros(numeros);
           DesplazaUnaPosicion(numeros);
           MuestraNumeros(numeros);
           
        }
    }
}