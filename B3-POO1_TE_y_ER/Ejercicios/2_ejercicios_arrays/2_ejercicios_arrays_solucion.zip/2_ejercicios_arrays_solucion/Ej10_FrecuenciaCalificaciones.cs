using System;
using System.Text;

namespace Ej10_FrecuenciaCalificaciones
{
    /* Introduce por teclado una secuencia de calificaciones de los alumnos de un instituto
     * (números enteros entre cero y diez). La secuencia termina con la introducción de un número
     * menor que cero o mayor que diez. Se supone que como máximo podemos tener 25 alumnos.
     * Se trata de obtener la frecuencia de las notas (número de veces que cada nota aparece).
     * Nota: Puedes usar un array para guardar las frecuencias.
     */

     class Ej10_FrecuenciaCalificaciones
    {
         static int[] RecogeNotas(out short notasIntroducidas)
         {
            int[] notas=new int[25];
            notasIntroducidas=0;
            Console.WriteLine("Introduce una nota: ");
            short nota=short.Parse(Console.ReadLine());
            for(int i=0;i<notas.Length && nota>=0 && nota<=10 ;i++)
            {
              notas[i]=nota;
              Console.WriteLine("Introduce una nota: ");
              nota=short.Parse(Console.ReadLine());
              notasIntroducidas++;
            }
            return notas;
         }
         static int[] CalculaFrecuencia(int[] notas, short notasIntroducidas)
         {
            int[] frecuencia=new int[11];
            for(int i =0; i<notasIntroducidas ;i++)  
              frecuencia[notas[i]]++;       
            return frecuencia;
         }

         static void MuestraNotas(int[] array, short notasIntroducidas)
         {
            Console.WriteLine("La nostas introducidas son:");
            for(int  i=0; i<notasIntroducidas; i++)  Console.Write(array[i]+",");
         }
          static void MuestraFrecuencia(int[] array)
         {
            int i=0;
            Console.WriteLine("La frecuencia es:");
            foreach(int x in array)  Console.Write($"{i++} = {x}\n");
         }
        static void Main()
        {
           short notasIntroducidas;
           int[] notas= RecogeNotas(out  notasIntroducidas);
           int[] frecuencia=CalculaFrecuencia(notas,notasIntroducidas);
           MuestraNotas(notas,notasIntroducidas);
           MuestraFrecuencia(frecuencia);
           
        }
    }
}