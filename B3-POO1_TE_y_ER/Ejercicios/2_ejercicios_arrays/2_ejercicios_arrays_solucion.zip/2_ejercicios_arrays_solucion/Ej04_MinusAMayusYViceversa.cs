﻿using System;
using System.Text;

#region Ej04_MinusAMayusYViceversa
namespace Ej04_MinusAMayusYViceversa
{
    /*
     * Rellena un array de 10 caracteres de forma aleatoria y 
     * luego sobre el mismo array modifíca, de forma que los elementos 
     * que estén en mayúsculas pasen a ser minúscula y los minúscula a mayúscula. 
     * Visualíza el array con la instrucción foreach.
     */

    class Ej04_MinusAMayusYViceversa
    {
        static char[] GeneraArrayCaracteres(ulong tamaño)
        {
            char[] array = new char[tamaño];
            Random random=new Random();

            for (ulong i = 0; i < (ulong)array.Length; i++)
            {
               int n=random.Next(65,123);
               if(n<91 || n>96) array[i] = (char)n;
               else i--;
            }

            return array;
        }

        static void CambiaArray(char[] caracteres)
        {
           
            for (uint i = 0; i < caracteres.Length; i++)
            {
                if (char.IsLower(caracteres[i])) caracteres[i]=char.ToUpper(caracteres[i]);
                else caracteres[i]=char.ToLower(caracteres[i]);
            }
        }

        static void VisualizaArray(char[] array)
        {
            Console.Write("\nLos valores del array en modificados son: ");
            foreach (var caracter in array)
                Console.Write(caracter + " ");
            Console.Write("\n");
        }

        static void Main(string[] args)
        {
            Console.Write("Introduzca cantidad de elementos para el array de caracteres: ");
            ulong tamaño = ulong.Parse(Console.ReadLine());

            char[] caracteres = GeneraArrayCaracteres(tamaño);
            VisualizaArray(caracteres);
            CambiaArray(caracteres);
            VisualizaArray(caracteres);
        }
    }
}
#endregion