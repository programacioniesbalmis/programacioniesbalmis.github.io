﻿using System;

#region Ej05_MostrarElementosPar
namespace Ej05_MostrarElementosPar
{
    class Ej05_MostrarElementosPar
    {
        /* Carga un array numérico de diez elementos, visualízalo
         * con la instrucción foreach y luego visualiza
         * los elementos cuyo contenido sea par, indicando su posición.
         */

        static int[] LeeArray(ulong tamaño)
        {
            int[] array = new int[tamaño];

            for (ulong i = 0; i < (ulong)array.Length; i++)
            {
                Console.Write($"Introduzca valor [{i}]: ");
                array[i] = int.Parse(Console.ReadLine());
            }

            return array;
        }

        static void VisualizaArray(int[] array)
        {
            Console.Write("\nLos valores del array son: ");
            foreach (var caracter in array)
                Console.Write(caracter + " ");
            Console.Write("\n");
        }

        static void VisualizaPares(int[] vector)
        {
            Console.WriteLine("\nLos valores pares del array son: ");

            for (ulong i = 0; i < (ulong)vector.Length; ++i)
            {
                if (vector[i] % 2 == 0)
                    Console.WriteLine($"Valor: {vector[i]}, Posicion: {i}");
            }
        }

        static void Main(string[] args)
        {
            int[] array = LeeArray(10);
            VisualizaArray(array);
            VisualizaPares(array);
        }
    }
}
#endregion

