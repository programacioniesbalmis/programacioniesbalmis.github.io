using System;


namespace Ej12_SumaPolinomios
{
   /*Dado el array de enteros int[] pol1 = new int[]{5, -7, -3, 0, 9}, que representa al 
    *polinomio 9x4-3x2-7x+5 donde el índice representa al exponente del monomio y el valor su 
    * coeficiente y el array int[] pol2 = new int[]{-1, 0, 4} que representa al polinomio 4x2-1.
    *Fíjate que cuando el coeficiente es 0 el monomio correspondiente no se representa.
    *Implementa un algoritmo que sume los polinomios, meta el resultado en otro array y muestre el resultado de la suma.
    *9x4 - 3x2 - 7x + 5 = 9x4 + 0x3 - 3x2 - 7x1 + 5x0*/
	class Ej12_SumaPolinomios
	{
	static int[] SumaPolinomios(int[] p1, int[] p2)
    {
        int[] suma = new int[Math.Max(p1.Length, p2.Length)];

        for (int i = 0; i < suma.Length; i++)
        {
            int c1 = (i < p1.Length) ? p1[i] : 0;
            int c2 = (i < p2.Length) ? p2[i] : 0;
            suma[i] = c1 + c2;
        }
        return suma;
    }

    static string PolinomioACadena(int[] pol)
    {
        string texto = "";
        
        for (int i = 0; i < pol.Length; i++)
        {
            string monomio = "";
            if (pol[i] != 0)
            {
                if (Math.Abs(pol[i]) == 1)
                    monomio += (pol[i] > 0) ? "+":"-";
                if (Math.Abs(pol[i]) > 1)
                    monomio += (pol[i] > 0) ? $"+{pol[i]}" : $"{pol[i]}";
                if (i > 0)
                    monomio += "X";
                if (i > 1)
                    monomio += $"{i}";
            }
            else
                monomio = "";
            texto = monomio + texto;
        }
        return texto;
    }

    static void Main()
    {
        int[] pol1 = new int[] { 5, -7, -3, 0, 9 };
        int[] pol2 = new int[] { -1, 0, 4 };

        int[] pol3 = SumaPolinomios(pol1, pol2);
          Console.Write(PolinomioACadena(pol1) + " + " +PolinomioACadena(pol2)+" = ");
        Console.WriteLine(PolinomioACadena(pol3));
    }
}
	}
