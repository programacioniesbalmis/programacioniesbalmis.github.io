﻿using System;

#region Ej08_arrayCapicua
namespace Ej08_arrayCapicua
{
    class Ej08_arrayCapicua
    {
        /* Implementa un programa en C# que dada un número entero sin signo
         * introducido por teclado me diga si es capicúa. Ej: 1234321 -> capicúa. 
         * Puedes usar el siguiente código para leer un número en forma de array 
         * de dígitos. char[] numero = Console.ReadLine().ToCharArray();
         */

        static bool EsCapicua(char[] array)
        {
            bool capicua = true;
            int indiceAlCentro = array.Length / 2;

            for (int i = 0; i < indiceAlCentro; i++)
            {
                if (array[i] != array[array.Length - 1 - i])
                {
                    capicua = false;
                    break;
                }
            }

            return capicua;
        }

        static void Main()
        {
            Console.Write("Introduzca número: ");
            char[] numero = Console.ReadLine().ToCharArray();

            string mensaje = "El número";
            mensaje += (EsCapicua(numero) == false) ? " no" : "";
            mensaje += " es capicua.";
            Console.WriteLine(mensaje);
        }
    }
}
#endregion

