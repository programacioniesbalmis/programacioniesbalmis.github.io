﻿using System;
using System.Diagnostics;

#region Ej09_Menucontraseña
namespace Ej09_Menucontraseña
{
    class Ej09_Menucontraseña
    {
        /* Crea un menú con tres opciones. Introducir contraseña, Pedir contraseña, 
         * Salir del programa. Si seleccionamos la primera opción aparecerá una ventana que 
         * te pida una contraseña que tendrás que repetir para comprobar que es la correcta,
         * mientras que estás escribiendo la contraseña solamente se verán los caracteres *****.
         * La contraseña se guardará en un array. En la opción de Pedir contraseña, introducirás
         * una cadena por teclado y se comprobará si la cadena seHaIntroducidoContraseña es igual a la contraseña
         * guardada en el array.
         *   ---------------------------------------------------
 	     *   Entrada:
	     *   Contraseña: ****
		 *   Comprobar Contraseña: *****
	     *   ---------------------------------------------------
         *
	     *   ---------------------------------------------------
 	     *   Salida:		
	     *   Introduce Contraseña: **
	     *   La contraseña es correcta (o en su caso incorrecta)
	     *  --------------------------------------------------- 
         */

        static char[] RecogeContraseña()
        {
            ConsoleKeyInfo caracter;
            int i=0;
            char[] contraseña = new char[20];

            do
            {
                caracter = Console.ReadKey(true);
                if (caracter.Key != ConsoleKey.Enter && i< contraseña.Length )
                {
                    contraseña[i]= caracter.KeyChar;
                    Console.Write("*");
                    i++;
                }
            } while (caracter.Key != ConsoleKey.Enter);

            return contraseña;
        }

        static bool SonIguales(char[] array1, char[] array2)
        {
            bool iguales;

            if (array1.Length == array2.Length)
            {
                uint i;
                for (i = 0; i < array1.Length; i++)
                {
                    if (array1[i] != array2[i])
                        break;
                }
                iguales = (array1.Length == i);
            }
            else
                iguales = false;

            return iguales;
        }

        static char[] EstableceContraseña()
        {
            char[] contraseñaIntento1, contraseñaIntento2;
            bool contraseñasIguales;

            do
            {

                Console.Write("\nContraseña: ");
                contraseñaIntento1 = RecogeContraseña();

                Console.Write("\nComprobar contraseña: ");
                contraseñaIntento2 = RecogeContraseña();

                contraseñasIguales = SonIguales(contraseñaIntento1, contraseñaIntento2);

                string mensaje = (contraseñasIguales) ? "Contraseña guardada correctamente." : "Las contraseñas no coinciden. Vuelve a introducirlas.";
                Console.WriteLine(mensaje);

            } while (contraseñasIguales == false);

            return contraseñaIntento1;
        }

        static void Main()
        {
            int opcion;
            char[] contraseña = null;
            bool seHaIntroducidoContraseña = false;

            do
            {
                Console.WriteLine("\n1. Registrarse en el sistema\n2. Entrar al sistema\n3. Salir\n\n");
                Console.Write("Seleccione una opción: ");
                opcion = int.Parse(Console.ReadLine());

                if (opcion != 3)
                {
                    switch (opcion)
                    {
                        case 1:
                            contraseña = EstableceContraseña();
                            seHaIntroducidoContraseña = true;
                            break;
                        case 2:
                            if (seHaIntroducidoContraseña)
                            {
                                Console.Write("\nIntroduce Contraseña: ");
                                char[] contraseñaParaAcceder =RecogeContraseña();

                                string mensaje = (SonIguales(contraseñaParaAcceder, contraseña)) ? "Contraseña correcta. Puede entrar al sistema" : "Lo siento contraseña incorrecta.";
                                Console.WriteLine(mensaje);
                                Console.ReadLine();
                            }
                            else
                                Console.WriteLine("ERROR: ¡No se ha introducido ninguna contraseña!\n");
                            break;
                        default:
                            Console.WriteLine("Opción no valida.\n");
                            break;
                    }
                }
            } while (opcion != 3);
        }
    }
}
#endregion

