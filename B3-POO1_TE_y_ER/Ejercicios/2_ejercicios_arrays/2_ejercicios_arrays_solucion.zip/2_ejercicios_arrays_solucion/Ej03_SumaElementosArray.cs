﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

#region Ej03_SumaElementosArray
namespace Ej03_SumaElementosArray
{
    /* Programa que suma los componentes de un array de 10 elementos. */

    class Ej03_SumaElementosArray
    {
        static int[] LeeArray(int tamaño)
        {
            int[] array = new int[tamaño];

            for (int i = 0; i < array.Length; i++)
            {
                Console.Write($"Introduzca valor [{i}]: ");
                array[i] = int.Parse(Console.ReadLine());
            }

            return array;
        }

        static int SumaElementos(int[] array)
        {
            int suma = 0;
            for (int i = 0; i < array.Length; i++)
                suma += array[i];
            return suma;
        }

        static void Main()
        {
            Console.Write("Introduzca cantidad de elementos para el array: ");
            int tamaño = int.Parse(Console.ReadLine());

            int[] array = LeeArray(tamaño);

            Console.WriteLine("\nSuma de todos los elementos: " + SumaElementos(array));
        }
    }
}
#endregion


