﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

#region Ej02_ImprimirDe4en4
namespace Ej02_ImprimirDe4en4
{
    class Ej02_ImprimirDe4en4
    {
       /* Rellena un array de 10 números de tipo double, de forma aleatoria, 
	    * y visualíza los que estén en una posición que sea múltiplo de cuatro.
		* Para generar un número real entre 0 y 100 puedes hacer:
	    */
        static int[] LeeArray(int tamaño)
        {
            int[] array = new int[tamaño];

            for (int i = 0; i < array.Length; i++)
            {
                Console.Write($"Introduzca valor [{i}]: ");
                array[i] = int.Parse(Console.ReadLine());
            }

            return array;
        }


        static void VisualizaArray(int[] array)
        {
            Console.WriteLine("\nLos valores introducidos de 4 en 4 son: ");

            for (int i = 0; i < array.Length; i++)
            {
                Console.Write(array[i] + " ");
                if ((i + 1) % 4 == 0)
                {
                    Console.WriteLine("\nPulsa una tecla para los siguientes 4 valores...");
                    Console.ReadKey();
                }
            }

            Console.Write("\n");
        }

        static void Main(string[] args)
        {
            Console.Write("Introduzca cantidad de elementos para el array: ");
            int tamaño = int.Parse(Console.ReadLine());

            int[] array = LeeArray(tamaño);
            VisualizaArray(array);
        }
    }
}
#endregion

