﻿using System;
using System.Diagnostics;


#region Ej07_ParesImparesOrdenar
namespace Ej07_ParesImparesOrdenar
{
    class Ej07_ParesImparesOrdenar
    {
        /* Crea un array numérico V de 10 elementos. Con los elementos pares 
         * crea un array P y ordena en sentido creciente y lo imprimes. Con los 
         * impares crea el array I y ordena en sentido decreciente y lo imprimes.
         */

        static int[] LeeArray(ulong tamaño)
        {
            int[] array = new int[tamaño];

            for (ulong i = 0; i < (ulong)array.Length; i++)
            {
                Console.Write($"Introduzca valor [{i}]: ");
                array[i] = int.Parse(Console.ReadLine());
            }
            Console.Write("\n");

            return array;
        }

        static bool CumpleFiltro(int valor, string filtro)
        {
            bool cumpleFiltro;

            switch (filtro)
            {
                case "pares":
                    cumpleFiltro = (valor % 2 == 0);
                    break;
                case "impares":
                    cumpleFiltro = (valor % 2 != 0);
                    break;
                default:
                    cumpleFiltro = false;
                    Debug.Assert(false, "Filtro array no válido.");
                    break;
            }

            return cumpleFiltro;
        }

        static int[] Filtra(int[] array, string filtro)
        {
            int elementosQueCumplenFiltro = 0;
            foreach (var valor in array)
            {
                if (CumpleFiltro(valor, filtro))
                    elementosQueCumplenFiltro++;
            }
            int[] arrayFiltrado = new int[elementosQueCumplenFiltro];

            int i = 0;
            foreach (var valor in array)
            {
                if (CumpleFiltro(valor, filtro))
                {
                    arrayFiltrado[i] = valor;
                    i++;
                }
            }

            return arrayFiltrado;
        }

        static bool CumpleOrden(int valor1, int valor2, string filtro)
        {
            bool cumpleOrden;

            switch (filtro)
            {
                case "ascendente":
                    cumpleOrden = (valor1 > valor2);
                    break;
                case "descendente":
                    cumpleOrden = (valor1 < valor2);
                    break;
                default:
                    cumpleOrden = false;
                    Debug.Assert(false, "Orden array no válido.");
                    break;
            }

            return cumpleOrden;
        }

        static void Ordena(int[] array, string orden)
        {
            for (ulong i = 0; i < (ulong)array.Length; i++)
            {
                for (ulong j = 0; j < (ulong)array.Length; j++)
                {
                    if (CumpleOrden(array[j], array[i], orden))
                    {
                        int auxiliar = array[i];
                        array[i] = array[j];
                        array[j] = auxiliar;
                    }
                }
            }
        }

        static void VisualizaArray(int[] array, string descripcion)
        {
            Console.Write(descripcion + ": ");
            foreach (var valor in array)
                Console.Write(valor + " ");
            Console.Write("\n\n");
        }

        static void Main()
        {
            int[] array = LeeArray(10);

            int[] arrayPares = Filtra(array, "pares");
            int[] arrayImpares = Filtra(array, "impares");

            Ordena(arrayPares, "ascendente");
            Ordena(arrayImpares, "descendente");

            VisualizaArray(array, "Array introducido");
            VisualizaArray(arrayPares, "Array pares ordenado");
            VisualizaArray(arrayImpares, "Array impares ordenado");
        }
    }
}
#endregion


