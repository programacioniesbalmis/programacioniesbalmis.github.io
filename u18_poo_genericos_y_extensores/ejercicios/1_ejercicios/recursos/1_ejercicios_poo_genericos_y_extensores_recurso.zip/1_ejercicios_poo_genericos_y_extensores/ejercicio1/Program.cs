﻿using System;
using System.Collections.Generic;

//TODO: Incluye el código necesario para implementar las entidades que se piden en el ejercicio

public class Program
{
	public static void GestionContenedor()
	{
		//TODO: Implementa el código para instaciar los objetos y conseguir la salida
	}
	private static void Main(string[] args)
	{
		Console.WriteLine("Ejercicio 1: Contenedor genérico de lecturas\n");

		GestionContenedor();

		Console.WriteLine("Pulsa una tecla para continuar...");
		Console.ReadKey();
	}
}


