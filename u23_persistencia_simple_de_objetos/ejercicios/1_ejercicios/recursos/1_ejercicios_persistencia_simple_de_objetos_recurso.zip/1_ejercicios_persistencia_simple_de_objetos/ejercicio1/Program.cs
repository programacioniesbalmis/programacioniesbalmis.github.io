﻿using System.Text.Json;

namespace ejercicio1
{
    public class Program
    {
        public static string nombreFichero = "usuario.json";

        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 1. Serialización Básica de un Objeto\n");
            bool salir = false;
            while (!salir)
            {
                Console.WriteLine("\n--- MENÚ USUARIOS ---");
                Console.WriteLine("1. Añadir usuario");
                Console.WriteLine("2. Leer todos los usuarios");
                Console.WriteLine("3. Salir");
                Console.Write("Elige una opción: ");
                
                string? opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                       
                        break;
                    case "2":
                        
                        break;
                    case "3":
                        salir = true;
                        break;
                    default:
                        Console.WriteLine("Opción no válida.");
                        break;
                }
            }

            Console.WriteLine("\nPulse una tecla para seguir...");
            Console.ReadKey();
        }

        static void AnadeUsuario()
        {

           
        }

        public static void EscribeEnFichero(Usuario usuario)
        {
            
        }

        public static void LeeFichero()
        {
            
        }
    }
}
