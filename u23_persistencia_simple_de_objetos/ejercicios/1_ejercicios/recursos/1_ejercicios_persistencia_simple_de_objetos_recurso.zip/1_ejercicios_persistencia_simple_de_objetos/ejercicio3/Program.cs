using System.Text.Json;
using System.Text.Json.Serialization;

namespace ejercicio3
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 3. Opciones de Serialización\n");
            
            Console.WriteLine("\nPulse una tecla para seguir...");
         //   Console.ReadKey();
        }
    }
}
