namespace ejercicio2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 2. Persistencia de Listas y Composición\n");
            string nombreFichero = "grupo.json";
            if (File.Exists(nombreFichero)) File.Delete(nombreFichero);

            Grupo grupoAdmin = new Grupo
            {
                NombreGrupo = "Administradores",
                Miembros = new List<Usuario>
                {
                    new Usuario { Nombre = "Alice", Edad = 25, Activo = true },
                    new Usuario { Nombre = "Bob", Edad = 30, Activo = true }
                }
            };

            Grupo grupoUsuarios = new Grupo
            {
                NombreGrupo = "Usuarios",
                Miembros = new List<Usuario>
                {
                    new Usuario { Nombre = "Charlie", Edad = 35, Activo = false },
                    new Usuario { Nombre = "Dave", Edad = 40, Activo = true }
                }
            };

            GestorDeGrupos.GuardaGrupo(grupoAdmin, nombreFichero);
            GestorDeGrupos.GuardaGrupo(grupoUsuarios, nombreFichero);

            Console.WriteLine("\nCargando grupos desde fichero...");
            List<Grupo> gruposRecuperados = GestorDeGrupos.CargaGrupos(nombreFichero);

            Console.WriteLine($"\nSe han recuperado {gruposRecuperados.Count} grupos.");

            foreach (var grupoRecuperado in gruposRecuperados)
            {
                Console.WriteLine("\nInformación del Grupo Recuperado:");
                Console.WriteLine($"Nombre del Grupo: {grupoRecuperado.NombreGrupo}");
                Console.WriteLine($"Cantidad de Miembros: {grupoRecuperado.Miembros.Count}");
                
                Console.WriteLine("Lista de Miembros:");
                foreach (var m in grupoRecuperado.Miembros)
                {
                     Console.WriteLine($"- {m.Nombre} ({m.Edad} años) [Activo: {m.Activo}]");
                }
            }

            Console.WriteLine("\nPulse una tecla para seguir...");
            Console.ReadKey();
        }
    }
}
