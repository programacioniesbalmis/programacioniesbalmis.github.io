using System.Text.Json.Serialization;

public record class Staff(
    [property: JsonPropertyName("productora")]
    string Productora,
    [property: JsonPropertyName("director")]
    Director Director,
    [property: JsonPropertyName("reparto")]
    List<string> Reparto
);
