﻿
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using System.Text.Unicode;

class Program
{
    public static List<Pelicula> CragaCartelera(string ruta)
    {
        string json = File.ReadAllText(ruta);
        var options = new JsonSerializerOptions
        {
            Converters = { new DateOnlyJsonConverter() }
        };
        var peliculas = JsonSerializer.Deserialize<List<Pelicula>>(json, options);
        return peliculas ?? [];
    }

    public static string RutaEjecucion() => Regex.Match(
        input: Directory.GetCurrentDirectory(),
        pattern: @"^(?<ruta>.*?)(?=\\bin)",
        options: RegexOptions.IgnoreCase
    ).Groups["ruta"].Value;


    static void Main()
    {
        List<Pelicula> cartelera = CragaCartelera(Path.Combine(RutaEjecucion(), "datos", "cartelera.json"));

        List<DirectorDto> peliculasPorDirector = cartelera
        .GroupBy(
            p => p.Staff.Director.Id,
            (idDirector, peliculas) => new DirectorDto(
                Nombre: peliculas.First().Staff.Director.Nombre,
                Nacionalidad: peliculas.First().Staff.Director.Nacionalidad,
                Peliculas: peliculas.Select(p => new PeliculaDto(
                                                        Titulo: p.Titulo,
                                                        Año: p.Año,
                                                        Pais: p.Pais,
                                                        Productora: p.Staff.Productora
                                                )).ToList()                                                
                )
        ).ToList();


        Console.WriteLine(JsonSerializer.Serialize(
            value: peliculasPorDirector,
            options: new JsonSerializerOptions { 
                WriteIndented = true,
                Encoder = JavaScriptEncoder.Create(
                            UnicodeRanges.BasicLatin,
                            UnicodeRanges.Latin1Supplement),
            }
        ));
    }
}

public record class DirectorDto(
    [property: JsonPropertyName("nombre")]
    string Nombre,
    [property: JsonPropertyName("nacionalidad")]
    string Nacionalidad,
    [property: JsonPropertyName("peliculas")]
    List<PeliculaDto> Peliculas
);

public record class PeliculaDto(
    [property: JsonPropertyName("titulo")]
    string Titulo,
    [property: JsonPropertyName("año")]
    int Año,
    [property: JsonPropertyName("pais")]
    string Pais,
    [property: JsonPropertyName("productora")]
    string Productora
);
