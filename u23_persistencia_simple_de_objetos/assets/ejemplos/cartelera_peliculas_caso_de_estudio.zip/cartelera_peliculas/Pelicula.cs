using System.Text.Json.Serialization;

public record class Pelicula(
    [property: JsonPropertyName("id")]
    int Id,
    [property: JsonPropertyName("titulo")]
    string Titulo,
    [property: JsonPropertyName("año")]
    int Año,
    [property: JsonPropertyName("duracion")]
    int Duracion,
    [property: JsonPropertyName("pais")]
    string Pais,
    [property: JsonPropertyName("staff")]
    Staff Staff,
    [property: JsonPropertyName("generos")]
    List<string> Generos,
    [property: JsonPropertyName("valoracion")]
    double Valoracion
);
