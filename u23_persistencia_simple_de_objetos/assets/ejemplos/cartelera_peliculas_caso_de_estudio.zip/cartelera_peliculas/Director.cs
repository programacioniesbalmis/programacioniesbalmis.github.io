using System.Text.Json.Serialization;

public record class Director(
    [property: JsonPropertyName("id")]
    string Id,
    [property: JsonPropertyName("nombre")]
    string Nombre,
    [property: JsonPropertyName("nacionalidad")]
    string Nacionalidad,
    [property: JsonPropertyName("fechaNacimiento")]
    DateOnly FechaNacimiento
);
