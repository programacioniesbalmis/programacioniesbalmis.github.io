using System;

public class Program
{


    public static void DeterminaSiEsParOImpar()
    {
        Console.WriteLine("\nEjercicio 1: Número par o impar ");
        // TODO: Implementa la lógica de este método

    }

    public static void ConvierteTemperatura()
    {
        Console.WriteLine("\nEjercicio 2: Conversión de temperatura ");
        // TODO: Implementa la lógica de este método

    }


    public static void CalculaSalarioSemanal()
    {
        Console.WriteLine("\nEjercicio 3: Calculadora de salario ");
        // TODO: Implementa la lógica de este método
    }

    public static void CalculaPromedioYDeterminaAprobacion()
    {
        Console.WriteLine("\nEjercicio 4: Promedio de calificaciones ");
       // TODO: Implementa la lógica de este método

    }

    public static void RealizaCalculadoraBasica()
    {
        Console.WriteLine("\nEjercicio 5: Calculadora básica ");
       // TODO: Implementa la lógica de este método
    }

    public static void ComparaNumeros()
    {
        Console.WriteLine("\nEjercicio 6: Comparación de números ");
        // TODO: Implementa la lógica de este método
    }

    public static void AdivinaElNumero()
    {
        Console.WriteLine("\nEjercicio 7: Adivina el número");
       // TODO: Implementa la lógica de este método

    }

    public static void VerificaContrasena()
    {
        Console.WriteLine("\nEjercicio 8: Verificación de contraseña ");
        // TODO: Implementa la lógica de este método
    }

    public static void CalculaCosteVacaciones()
    {
        Console.WriteLine("\nEjercicio 9: Coste de vacaciones ");
        // TODO: Implementa la lógica de este método
    }

    public static void MuestraInstruccionSemaforo()
    {
        Console.WriteLine("\nEjercicio 10: Semáforo textual ");
        // TODO: Implementa la lógica de este método
    }

    public static void ClasificaPorEdad()
    {
        Console.WriteLine("\nEjercicio 11: Clasificador de edad ");
        // TODO: Implementa la lógica de este método
    }

    public static void CalculaNotaFinal()
    {
        Console.WriteLine("\nEjercicio 12: Calculo de notas ");
        // TODO: Implementa la lógica de este método
    }

    public static void ClasificaTriangulo()
    {
        Console.WriteLine("\nEjercicio 13: Clasificación de triángulos ");
       // TODO: Implementa la lógica de este método
    }

    public static void Main(string[] args)
    {
        DeterminaSiEsParOImpar();
        ConvierteTemperatura();
        CalculaSalarioSemanal();
        CalculaPromedioYDeterminaAprobacion();
        RealizaCalculadoraBasica();
        ComparaNumeros();
        AdivinaElNumero();
        VerificaContrasena();
        CalculaCosteVacaciones();
        MuestraInstruccionSemaforo();
        ClasificaPorEdad();
        CalculaNotaFinal();
        ClasificaTriangulo();

        Console.WriteLine("\nPresiona cualquier tecla para salir...");
        Console.ReadLine();

    }
}


