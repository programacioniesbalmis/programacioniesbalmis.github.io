﻿using System;
using System.Text;

namespace ejercicio3
{
    public class Program
    {
        //TODO: Implementar los métodos necesarios
        static void Main(string[] args)
        {
            //TODO: Implementar la lógica necesaria. Fíjate en la salida por pantalla.
        }

    }
}