﻿using System;
using System.Text.RegularExpressions;

public class Program
{
   
    static void Main()
    {
      
    }
}