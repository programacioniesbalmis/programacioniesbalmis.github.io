class Program
{
    // µ
    static void Main()
    {
        Pluviometro98 p1 = new Pluviometro98("AF98X1");
        MedidorNo2 m1 = new MedidorNo2("1234A");
        MedidorNo2 m2 = new MedidorNo2("1235A");

        var centralAlicante = new CentralMedicion("AlicanteCentro")
                              .AñadeMedidor(m1)
                              .AñadeMedidor(m2)
                              .AñadeMedidor(p1);

        for (int i = 0; i < 4; i++) 
        {
            centralAlicante.Mide();
        }
        
        Console.WriteLine(centralAlicante);
    }
}