using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace Ej5_ConsultasProductos
{
    public record MedicionesCiudad
    {
        public string Ciudad { get; init; }
        public DateTime Fecha { get; init; }
        public List<double> Mediciones { get; init; }
    }


    public static class Datos
    {
        public static IEnumerable<MedicionesCiudad> MedicionesCiudad
        {
            get
            {
                yield return new()
                {
                    Ciudad = "Alicante",
                    Fecha = DateTime.Parse("12/02/2023"),
                    Mediciones = new double[] { 19.24, 22.2, 24.23, 18.9, 10.2, 7.98 }.ToList()

                };
                yield return new()
                {
                    Ciudad = "Valencia",
                    Fecha = DateTime.Parse("12/02/2023"),
                    Mediciones = new double[] { 29.24, 39.2, 34.3, 21.98, 19.2, 7.98 }.ToList()
                };
                yield return new()
                {
                    Ciudad = "Castellón",
                    Fecha = DateTime.Parse("11/02/2023"),
                    Mediciones = new double[] { 12.5, 28.7, 20.3, 16.1, 9.8, 6.4 }.ToList()
                };

                yield return new()
                {
                    Ciudad = "Castellón",
                    Fecha = DateTime.Parse("22/03/2023"),
                    Mediciones = new double[] { 14.2, 19.7, 26.1, 13.8, 10.4, 32.9 }.ToList()
                };
                yield return new()
                {
                    Ciudad = "Alicante",
                    Fecha = DateTime.Parse("3/04/2023"),
                    Mediciones = new double[] { 11.9, 18.6, 23.2, 16.5, 9.2, 25.1 }.ToList()
                };
                yield return new()
                {
                    Ciudad = "Alicante",
                    Fecha = DateTime.Parse("11/05/2023"),
                    Mediciones = new double[] { 16.8, 22.3, 28.7, 17.4, 12.9, 29.5 }.ToList()
                };
            }
        }

        class Principal
        {
            static void Main()
            {
                string SeparadorConsulta = "\n" + new string('-', 80) + "\n";

                Console.WriteLine(SeparadorConsulta);
                Console.WriteLine("Consulta 1: Muestra las ciudades que hayan " +
                                  "tenido una medición con fecha 12/03/2023");
                var consulta1 = "";
                Console.WriteLine(string.Join("\n", consulta1));

                Console.WriteLine(SeparadorConsulta);
                Console.WriteLine("Consulta 2: Mostrar el nombre de las ciudades" +
                                  "que hayan superado una medición mayor a 30μg/m3\n" +
                                  "Puedes usar Exists para concadenar el filtrado de where");
                var consulta2 = "";
                Console.WriteLine(string.Join("\n", consulta2));

                Console.WriteLine(SeparadorConsulta);
                Console.WriteLine("Consulta 3: Muestra todas las temperaturas de cada ciudad " +
                                  "agrupadas por esta, ordenadas y sin repeticiones \n");
                var consulta3 = "";
                Console.WriteLine(string.Join("\n", consulta3));

                Console.ReadLine();
            }
        }
    }
}