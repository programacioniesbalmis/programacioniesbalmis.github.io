public record Pintura(
    string Titulo,
    string Artista,
    int Creado,
    string Periodo,
    Dimensiones Dimensiones,
    List<string> Generos);
