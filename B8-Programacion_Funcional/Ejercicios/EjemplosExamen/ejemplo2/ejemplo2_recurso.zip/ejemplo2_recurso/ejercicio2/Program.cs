﻿using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.Unicode;

public static class ProgramEj2
{

    public static string Consulta1()
    {
        StringBuilder sb = new();
        sb.AppendLine(
            "Consulta 1: Mostrar titulo, artista y periodo"
            + "\nde las pinturas del Barroco"
            + "\nordenados ascendentemente por titulo");
        var pinturasBarroco = Museo.Pinturas;

        sb.Append(string.Join("\n", pinturasBarroco) + "\n");
        return sb.ToString();
    }

    public static string Consulta2()
    {
        StringBuilder sb = new();
        sb.AppendLine(
            "Consulta 2: Mostrar titulo, dimensiones y área"
            + "\nde las pinturas que tenga de alto más de 3m"
            + "\nordenados descendentemente por altura");
        var pinturasAltoMasDe3m = Museo.Pinturas;

        sb.Append(string.Join("\n", pinturasAltoMasDe3m) + "\n");
        return sb.ToString();
    }

    public record Consulta3Dto(
        [property: JsonPropertyName("titulo")]
        string Titulo, 
        [property: JsonPropertyName("año")]
        string Artista, 
        [property: JsonPropertyName("generos")]
        string Generos);    

    static void ToJSON(this IEnumerable<Consulta3Dto> consulta3Dto, string path)
    {
        
    }

    static IEnumerable<Consulta3Dto> DatosConsulta3() => [];
    public static string Consulta3()
    {
        StringBuilder sb = new();
        sb.AppendLine(
            "Consulta 3: Mostrar titulo, artista y generos"
            + "\nde las pinturas que tengan como"
            + "\nuno de sus géneros la mitología o historia");
        var pinturasPorGenero = DatosConsulta3();
        sb.Append(string.Join("\n", pinturasPorGenero) + "\n");
        return sb.ToString();
    }

    public static string Consulta4()
    {
        StringBuilder sb = new();
        sb.AppendLine(
            "Consulta 4: Mostrar el número de pinturas de cada periodo"
            + "\nordenado por el periodo. (No se puede usar Select)");
        var pinturasPorPeriodo = Museo.Pinturas;

        sb.Append(string.Join("\n", pinturasPorPeriodo) + "\n");
        return sb.ToString();
    }

    public static string Consulta5()
    {
        StringBuilder sb = new();
        sb.AppendLine(
            "Consulta 5: Mostrar los géneros sin repeticiones. (Debes usar SelectMany)");
        var generos = Museo.Pinturas;

        sb.Append(string.Join(", ", generos) + "\n");
        return sb.ToString();
    }

    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.WriteLine(Consulta1());
        Console.WriteLine(Consulta2());
        Console.WriteLine(Consulta3());
        Console.WriteLine(Consulta4());
        Console.WriteLine(Consulta5());

        // Consulta 3 a JSON
        string path = Path.Combine(Environment.CurrentDirectory, "consulta3.json");
        DatosConsulta3().ToJSON(path);
        Console.WriteLine($"Consulta 3 guardada en {path}");
    }
}