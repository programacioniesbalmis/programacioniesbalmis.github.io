public record Dimensiones(
    double Alto, 
    double Ancho);
