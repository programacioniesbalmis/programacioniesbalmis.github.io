﻿static class Museo
{
    public static IEnumerable<Pintura> Pinturas
    {
        get
        {
            yield return new Pintura(
                Titulo: "Las meninas",
                Artista: "Diego Velázquez",
                Creado: 1656,
                Periodo: "Barroco",
                Dimensiones: new Dimensiones(
                    Alto: 3.18,
                    Ancho: 2.76
                    ),
                Generos: ["retrato", "historia"]
            );
            yield return new Pintura(
                Titulo: "El jardín de las delicias",
                Artista: "El Bosco",
                Creado: 1515,
                Periodo: "Renacimiento",
                Dimensiones: new Dimensiones(
                    Alto: 2.2,
                    Ancho: 3.89),
                Generos: ["cristiandad"]
            );
            yield return new Pintura(
                Titulo: "Saturno devorando a su hijo",
                Artista: "Francisco de Goya",
                Creado: 1823,
                Periodo: "Romanticismo",
                Dimensiones: new Dimensiones(
                    Alto: 1.46,
                    Ancho: 0.83),
                Generos: ["mitología"]
            );
            yield return new Pintura(
                Titulo: "El 3 de mayo en Madrid",
                Artista: "Francisco de Goya",
                Creado: 1814,
                Periodo: "Romanticismo",
                Dimensiones: new Dimensiones(
                    Alto: 2.68,
                    Ancho: 3.47),
                Generos: ["historia", "guerra"]
            );
            yield return new Pintura(
                Titulo: "La rendición de Breda",
                Artista: "Diego Velázquez",
                Creado: 1634,
                Periodo: "Barroco",
                Dimensiones: new Dimensiones(
                    Alto: 3.07,
                    Ancho: 3.67),
                Generos: ["guerra", "historia"]
            );
            yield return new Pintura(
                Titulo: "Las tres Gracias",
                Artista: "Pedro Pablo Rubens",
                Creado: 1639,
                Periodo: "Barroco",
                Dimensiones: new Dimensiones(
                    Alto: 2.21,
                    Ancho: 1.81),
                Generos: ["desnudo", "mitología"]
            );
        }
    }
}