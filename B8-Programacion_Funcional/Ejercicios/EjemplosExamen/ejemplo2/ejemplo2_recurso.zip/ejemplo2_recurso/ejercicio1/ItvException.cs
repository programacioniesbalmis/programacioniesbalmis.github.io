﻿public class ItvExcepction : Exception
{
    public ItvExcepction(string message) : base(message)
    {
        ;
    }
}
