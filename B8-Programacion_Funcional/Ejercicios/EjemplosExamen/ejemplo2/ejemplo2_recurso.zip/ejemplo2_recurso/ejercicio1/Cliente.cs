﻿public class Cliente
{
    public string Dni { get; }
    public string Nombre { get; }
    public Vehiculo Vehiculo { get; }

    public Cliente(string dni, string nombre, Vehiculo v)
    {
        Dni = dni;
        Nombre = nombre;
        Vehiculo = v;
    }

    public override string ToString() => $"{Nombre} {Dni}";
}
