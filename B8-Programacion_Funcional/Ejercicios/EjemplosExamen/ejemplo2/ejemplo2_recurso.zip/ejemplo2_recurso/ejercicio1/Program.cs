﻿class Program
{
    public static void Main()
    {
        // List<Cliente> clientes = new()
        // {
        //     new ("11111111 A", "Simon", new VehiculoConEmisiones("1234 CBR", "Seat")),
        //     new ("22222222 B", "Emy", new Vehiculo("2235 JRF", "Renault")),
        //     new ("33333333 C", "Sonia", new VehiculoConEmisiones("3236 LMS", "Fiat")),
        //     new ("44444444 D", "Javi", new Vehiculo("4237 KNS", "Ford")),
        //     new ("55555555 E", "Marta", new VehiculoConEmisiones("5238 KNS", "Lexus")),
        //     new ("66666666 F", "Vicente", new VehiculoConEmisiones("6239 KNS", "Audi")),
        //     new ("77777777 G", "Rosa", new Vehiculo("7230 KNS", "Mercedes")),
        //     new ("88888888 H", "Paco", new VehiculoConEmisiones("8231 KNS", "Opel")),
        //     new ("99999999 I", "Rosa", new VehiculoConEmisiones("9232 KNS", "Citroen"))
        // };

        // Itv itv = new Itv(new string[] { "Juanjo", "Xusa", "Carmen", "Raquel" });

        // foreach (var c in clientes)
        // {
        //     try
        //     {
        //         itv.Llegada(c);
        //     }
        //     catch (ItvExcepction e)
        //     {
        //         Console.WriteLine(e.Message);
        //         itv.AtenderInformesEnLineas();
        //     }
        // }
        // itv.AtenderInformesEnLineas();        
    }
}
