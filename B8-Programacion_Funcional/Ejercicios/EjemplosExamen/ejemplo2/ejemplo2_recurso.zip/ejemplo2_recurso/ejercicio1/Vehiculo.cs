﻿public class Vehiculo
{
    public string Matricula { get; init; }
    public string Marca { get; init; }
    public Vehiculo(string matrícula, string marca)
    {
        Matricula = matrícula;
        Marca = marca;
    }
    public int PorcentajeFrenada => new Random().Next(40, 101);
    public int PorcentajeIntegridadEstructural => new Random().Next(80, 101);
    public string? ComprobacionLuces 
    {
        get
        {
            string?[] estadosLuces = { 
                null, 
                "Intermitente delantero derecho", 
                "Luz de freno trasera izquierda", 
                "Ángulo faro delantero izquierdo" 
            };

            return estadosLuces[new Random().Next(0, estadosLuces.Length)];
        }
    }

    public override string ToString() => $"{Matricula} {Marca}";
}
