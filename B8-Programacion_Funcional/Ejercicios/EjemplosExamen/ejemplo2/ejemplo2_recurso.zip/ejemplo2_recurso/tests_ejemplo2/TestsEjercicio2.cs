namespace tests_ejemplo2;

public class TestsEjercicio2
{
    [Fact]
    public void Program_Consulta1_Output_Test()
    {
        // Arrange
        var expectedOutput = 
            "Consulta 1: Mostrar titulo, artista y periodo\n" +
            "de las pinturas del Barroco\n" +
            "ordenados ascendentemente por titulo\r\n" +
            "{ Titulo = La rendición de Breda, Artista = Diego Velázquez, Periodo = Barroco }\n" +
            "{ Titulo = Las meninas, Artista = Diego Velázquez, Periodo = Barroco }\n" +
            "{ Titulo = Las tres Gracias, Artista = Pedro Pablo Rubens, Periodo = Barroco }\n";

        // Act
        var output = ProgramEj2.Consulta1();

        // Assert
        Assert.Equal(expectedOutput, output);
    }

    [Fact]
    public void Program_Consulta2_Output_Test()
    {
        // Arrange
        var expectedOutput = 
            "Consulta 2: Mostrar titulo, dimensiones y área\n" +
            "de las pinturas que tenga de alto más de 3m\n" +
            "ordenados descendentemente por altura\r\n" +
            "{ Titulo = Las meninas, Dimensiones = Dimensiones { Alto = 3,18, Ancho = 2,76 }, Area = 8,7768 }\n" +
            "{ Titulo = La rendición de Breda, Dimensiones = Dimensiones { Alto = 3,07, Ancho = 3,67 }, Area = 11,2669 }\n";
        // Act
        var output = ProgramEj2.Consulta2();

        // Assert
        Assert.Equal(expectedOutput, output);
    }

    [Fact]
    public void Program_Consulta3_Output_Test()
    {
        // Arrange
        var expectedOutput = 
            "Consulta 3: Mostrar titulo, artista y generos\n" +
            "de las pinturas que tengan como\n" +
            "uno de sus géneros la mitología o historia\r\n" +
            "Consulta3Dto { Titulo = Las meninas, Artista = Diego Velázquez, Generos = [retrato, historia] }\n" +
            "Consulta3Dto { Titulo = Saturno devorando a su hijo, Artista = Francisco de Goya, Generos = [mitología] }\n" +
            "Consulta3Dto { Titulo = El 3 de mayo en Madrid, Artista = Francisco de Goya, Generos = [historia, guerra] }\n" +
            "Consulta3Dto { Titulo = La rendición de Breda, Artista = Diego Velázquez, Generos = [guerra, historia] }\n" +
            "Consulta3Dto { Titulo = Las tres Gracias, Artista = Pedro Pablo Rubens, Generos = [desnudo, mitología] }\n";

        // Act
        var output = ProgramEj2.Consulta3();

        // Assert
        Assert.Equal(expectedOutput, output);
    }

    [Fact]
    public void Program_Consulta4_Output_Test()
    {
        // Arrange
        var expectedOutput = 
            "Consulta 4: Mostrar el número de pinturas de cada periodo\n" +
            "ordenado por el periodo. (No se puede usar Select)\r\n" +
            "{ Periodo = Barroco, NumeroPinturas = 3 }\n" +
            "{ Periodo = Renacimiento, NumeroPinturas = 1 }\n" +
            "{ Periodo = Romanticismo, NumeroPinturas = 2 }\n";

        // Act
        var output = ProgramEj2.Consulta4();

        // Assert
        Assert.Equal(expectedOutput, output);
    }

    [Fact]
    public void Program_Consulta5_Output_Test()
    {
        // Arrange
        var expectedOutput = 
            "Consulta 5: Mostrar los géneros sin repeticiones. (Debes usar SelectMany)\r\n" +
            "retrato, historia, cristiandad, mitología, guerra, desnudo\n";

        // Act
        var output = ProgramEj2.Consulta5();

        // Assert
        Assert.Equal(expectedOutput, output);
    }
}