namespace tests_ejemplo2;

public class TestsEjercicio1
{
    [Fact]
    public void Cliente_ToString_ReturnsCorrectFormat()
    {
        // Arrange
        var vehiculo = new Vehiculo("1234 ABC", "Toyota");
        var cliente = new Cliente("12345678A", "Juan", vehiculo);

        // Act
        var result = cliente.ToString();

        // Assert
        Assert.Equal("Juan 12345678A", result);
    }

    [Fact]
    public void Vehiculo_ToString_ReturnsCorrectFormat()
    {
        // Arrange
        var vehiculo = new Vehiculo("1234 ABC", "Toyota");

        // Act
        var result = vehiculo.ToString();

        // Assert
        Assert.Equal("1234 ABC Toyota", result);
    }

    [Fact]
    public void VehiculoConEmisiones_PorcentajeEmisiones_IsWithinRange()
    {
        // Arrange
        var vehiculo = new VehiculoConEmisiones("1234 ABC", "Toyota");

        // Act
        var emisiones = vehiculo.PorcentajeEmisiones;

        // Assert
        Assert.InRange(emisiones, 0, 30);
    }

    [Fact]
    public void InformeItv_Apto_ReturnsTrueWhenAllComprobacionesAreApto()
    {
        // Arrange
        var cliente = new Cliente("12345678A", "Juan", new Vehiculo("1234 ABC", "Toyota"));
        var informe = new InformeItv(cliente, "Inspector1");
        informe.AñadirComprobacion(new Comprobacion("Frenos", true, "Correcto"));
        informe.AñadirComprobacion(new Comprobacion("Luces", true, "Correcto"));
        informe.Cerrar();

        // Act
        var apto = informe.Apto;

        // Assert
        Assert.True(apto);
    }

    [Fact]
    public void InformeItv_Apto_ReturnsFalseWhenAnyComprobacionIsNotApto()
    {
        // Arrange
        var cliente = new Cliente("12345678A", "Juan", new Vehiculo("1234 ABC", "Toyota"));
        var informe = new InformeItv(cliente, "Inspector1");
        informe.AñadirComprobacion(new Comprobacion("Frenos", true, "Correcto"));
        informe.AñadirComprobacion(new Comprobacion("Luces", false, "Defectuoso"));
        informe.Cerrar();

        // Act
        var apto = informe.Apto;

        // Assert
        Assert.False(apto);
    }

    [Fact]
    public void InformeItv_ToString_ReturnsCorrectFormat()
    {
        // Arrange
        var cliente = new Cliente("12345678A", "Juan", new Vehiculo("1234 ABC", "Toyota"));
        var informe = new InformeItv(cliente, "Inspector1");
        informe.AñadirComprobacion(new Comprobacion("Frenos", true, "Correcto"));
        informe.AñadirComprobacion(new Comprobacion("Luces", false, "Defectuoso"));
        informe.Cerrar();

        var expectedOutput =
            "Informe ITV de 1234 ABC Toyota\n" +
            "Cliente: Juan 12345678A\r\n" +
            "Inspector: Inspector1\r\n" +
            " [V] Frenos: Correcto\r\n" +
            " [X] Luces: Defectuoso\r\n" +
            "Resultado: NO APTO\r\n";

        // Act
        var result = informe.ToString();

        // Assert
        Assert.Equal(expectedOutput, result);
    }

    [Fact]
    public void Itv_Llegada_ThrowsExceptionWhenNoInspectorsAvailable()
    {
        // Arrange
        var itv = new Itv(Array.Empty<string>());
        var cliente = new Cliente("12345678A", "Juan", new Vehiculo("1234 ABC", "Toyota"));

        // Act & Assert
        Assert.Throws<ItvExcepction>(() => itv.Llegada(cliente));
    }

    [Fact]
    public void DireccionGeneralDeTrafico_Recibe_PrintsInforme()
    {
        // Arrange
        var cliente = new Cliente("12345678A", "Juan", new Vehiculo("1234 ABC", "Toyota"));
        var informe = new InformeItv(cliente, "Inspector1");
        informe.AñadirComprobacion(new Comprobacion("Frenos", true, "Correcto"));
        informe.AñadirComprobacion(new Comprobacion("Luces", true, "Correcto"));
        informe.Cerrar();
        var dgt = new DireccionGeneralDeTrafico();
        var expectedOutput = 
            "DGT recibiendo informe de ITV  ...\r\n" +
            "Informe ITV de 1234 ABC Toyota\n" +
            "Cliente: Juan 12345678A\r\n" +
            "Inspector: Inspector1\r\n" +
            " [V] Frenos: Correcto\r\n" +
            " [V] Luces: Correcto\r\n" +
            "Resultado: APTO\r\n\r\n";

        // Act
        using var consoleOutput = new StringWriter();
        Console.SetOut(consoleOutput);
        dgt.Recibe(informe);

        // Assert
        var output = consoleOutput.ToString();
        Assert.Equal(expectedOutput, output);
    }
}