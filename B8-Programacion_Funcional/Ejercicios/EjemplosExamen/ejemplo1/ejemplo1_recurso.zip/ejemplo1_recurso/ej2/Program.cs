﻿
using System.Text;

public static class ProgramEj2
{
    public record Consulta3Dto(
        string Titulo,
        int Año,
        string Generos
    );

    public static void ToJSON(this IEnumerable<Consulta3Dto> consulta3Dto, string path)
    {
    }

    public static string Consulta1()
    {
        StringBuilder c1 = new("Consulta 1: Mostrar titulo, año, país y valoración"
            + "\nde las películas españolas del año 2014"
            + "\nordenados descendentemente por valoración\n");

        var peliculasEspañolas2014 = Cartelera.Peliculas;

        c1.Append(string.Join("\n", peliculasEspañolas2014) + "\n");
        return c1.ToString();
    }

    public static string Consulta2()
    {
        StringBuilder c2 = new("Consulta 2: Mostrar titulo, año, país y duración"
            + "\nde las películas con duración entre 100 y 120 minutos, es decir,"
            + "\ncon duración mayor o igual de 100 y menor o igual de 120.\n");

        var peliculasDuracion = Cartelera.Peliculas;

        c2.Append(string.Join("\n", peliculasDuracion) + "\n");
        return c2.ToString();
    }


    static IEnumerable<Consulta3Dto> DatosConsulta3() => [];

    public static string Consulta3()
    {
        StringBuilder c3 = new("Consulta 3: Mostrar titulo, año y géneros"
            + "\nde las películas que el genero sea de \"drama\", \"romance\" o \"fantástico\"\n");

        var peliculasDramaRomanceFantastico = DatosConsulta3();

        c3.Append(string.Join("\n", peliculasDramaRomanceFantastico) + "\n");
        return c3.ToString();
    }

    public static string Consulta4()
    {
        StringBuilder c4 = new("Consulta 4: Mostrar titulo, país y reparto"
            + "\nde las películas en las que conste un reparto con 2 actores\n");

        var peliculasReparto = Cartelera.Peliculas;

        c4.Append(string.Join("\n", peliculasReparto) + "\n");
        return c4.ToString();
    }

    public static string Consulta5()
    {
        StringBuilder c5 = new("Consulta 5: Calcular la duración media de las películas de cada país.\n"
            + "Mostrar -> \"Pais: DuracionMedia\"\n");

        var duracionMedia = Cartelera.Peliculas;

        c5.Append(string.Join("\n", duracionMedia) + "\n");
        return c5.ToString();
    }

    public static string Consulta6()
    {
        StringBuilder c6 = new("Consulta 6: Muestra sin repeticiones todos géneros de las peliculas en cartelera usando SelectMany.\n");

        var generos = Cartelera.Peliculas;

        c6.Append($"[{string.Join(", ", generos)}]\n");
        return c6.ToString();
    }

    public static void Main()
    {
        Console.WriteLine(Consulta1());
        Console.WriteLine(Consulta2());
        Console.WriteLine(Consulta3());
        Console.WriteLine(Consulta4());
        Console.WriteLine(Consulta5());
        Console.WriteLine(Consulta6());

        // Consulta 3 a JSON
        string path = Path.Combine(Environment.CurrentDirectory, "consulta3.json");
        DatosConsulta3().ToJSON(path);
        Console.WriteLine($"Consulta 3 guardada en {path}");
    }
}