public record class Staff(
    string Productora,
    string Director,
    string[] Reparto
);
