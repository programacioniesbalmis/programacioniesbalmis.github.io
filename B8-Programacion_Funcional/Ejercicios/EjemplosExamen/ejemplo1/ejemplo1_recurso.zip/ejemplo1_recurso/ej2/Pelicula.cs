public record class Pelicula(
    string Titulo,
    int Año,
    int Duracion,
    string Pais,
    Staff Staff,
    string[] Generos,
    double Valoracion
);
