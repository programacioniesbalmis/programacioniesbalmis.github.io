namespace tests_ejemplo1;

public class UnitTestEj1
{

    [Fact]
    public void Farmacia_Alta_ShouldAddMedicamento()
    {
        var farmacia = new Farmacia("Test Farmacia");
        var medicamento = new Medicamento("Paracetamol", 5.99, "Proveedor A");

        farmacia.Alta(medicamento);

        Assert.Contains(medicamento, farmacia.MedicamentosAgotados());
    }

    [Fact]
    public void Farmacia_Baja_ShouldRemoveMedicamento()
    {
        var farmacia = new Farmacia("Test Farmacia");
        var medicamento = new Medicamento("Paracetamol", 5.99, "Proveedor A");

        farmacia.Alta(medicamento);
        farmacia.Baja(medicamento);

        Assert.DoesNotContain(medicamento, farmacia.MedicamentosAgotados());
    }

    [Fact]
    public void Farmacia_Reponer_ShouldIncreaseStock()
    {
        var farmacia = new Farmacia("Test Farmacia");
        var medicamento = new Medicamento("Paracetamol", 5.99, "Proveedor A");

        farmacia.Alta(medicamento);
        farmacia.Reponer(medicamento, 10);

        Assert.Equal(10, farmacia.Retirar(medicamento, 10));
    }

    [Fact]
    public void Farmacia_Retirar_ShouldDecreaseStock()
    {
        var farmacia = new Farmacia("Test Farmacia");
        var medicamento = new Medicamento("Paracetamol", 5.99, "Proveedor A");

        farmacia.Alta(medicamento);
        farmacia.Reponer(medicamento, 10);
        var retiradas = farmacia.Retirar(medicamento, 5);

        Assert.Equal(5, retiradas);
    }

    [Fact]
    public void Farmacia_MedicamentosAgotados_ShouldReturnEmptyList()
    {
        var farmacia = new Farmacia("Test Farmacia");
        var medicamento = new Medicamento("Paracetamol", 5.99, "Proveedor A");

        farmacia.Alta(medicamento);
        farmacia.Reponer(medicamento, 10);

        Assert.Empty(farmacia.MedicamentosAgotados());
    }

    [Fact]
    public void Almacen_Alta_ShouldAddProduct()
    {
        var almacen = new Almacen<Medicamento>(10);
        var medicamento = new Medicamento("Paracetamol", 5.99, "Proveedor A");

        almacen.Alta(medicamento);

        Assert.True(almacen.EstaEnAlmacen(medicamento));
    }

    [Fact]
    public void Almacen_Baja_ShouldRemoveProduct()
    {
        var almacen = new Almacen<Medicamento>(10);
        var medicamento = new Medicamento("Paracetamol", 5.99, "Proveedor A");

        almacen.Alta(medicamento);
        almacen.Baja(medicamento);

        Assert.False(almacen.EstaEnAlmacen(medicamento));
    }

    [Fact]
    public void Almacen_AgregaStock_ShouldIncreaseStock()
    {
        var almacen = new Almacen<Medicamento>(10);
        var medicamento = new Medicamento("Paracetamol", 5.99, "Proveedor A");

        almacen.Alta(medicamento);
        almacen.AgregaStock(medicamento, 10);

        Assert.Equal(10, almacen.RetiraStock(medicamento, 10));
    }

    [Fact]
    public void Almacen_RetiraStock_ShouldDecreaseStock()
    {
        var almacen = new Almacen<Medicamento>(10);
        var medicamento = new Medicamento("Paracetamol", 5.99, "Proveedor A");

        almacen.Alta(medicamento);
        almacen.AgregaStock(medicamento, 10);
        var retiradas = almacen.RetiraStock(medicamento, 5);

        Assert.Equal(5, retiradas);
    }

    [Fact]
    public void DatosAlmacenaje_ShouldInitializeCorrectly()
    {
        var datos = new DatosAlmacenaje(1);

        Assert.Equal(0, datos.Unidades);
        Assert.Equal(1, datos.Ubicacion);
    }

    [Fact]
    public void Medicamento_ShouldBeImmutable()
    {
        var medicamento = new Medicamento("Paracetamol", 5.99, "Proveedor A");

        Assert.Equal("Paracetamol", medicamento.Nombre);
        Assert.Equal(5.99, medicamento.Precio);
        Assert.Equal("Proveedor A", medicamento.Proveedor);
    }

    [Fact]
    public void TestMostrarInventarioFormato()
    {
        // Arrange
        Farmacia farmacia = new Farmacia("Mi Farmacia");
        farmacia.Alta(new Medicamento("Paracetamol", 5.99, "Proveedor A"));
        farmacia.Alta(new Medicamento("Ibuprofeno", 7.49, "Proveedor B"));
        farmacia.Alta(new Medicamento("Amoxicilina", 9.99, "Proveedor C"));  
        farmacia.Reponer(new Medicamento("Paracetamol", 5.99, "Proveedor A"), 20);
        farmacia.Reponer(new Medicamento("Amoxicilina", 9.99, "Proveedor C"), 10);

        // Act
        string inventario = farmacia.MostrarInventario();

        string inventarioEsperado  = "Farmacia: Mi Farmacia\n" +
                                      "Nombre               Ubicación  Unidades    Precio\r\n" +
                                      "-------------------  --------- --------- ---------\r\n" +
                                      "Paracetamol                  0        20      5,99\r\n" +
                                      "Ibuprofeno                   1         0      7,49\r\n" +
                                      "Amoxicilina                  2        10      9,99\r\n" +
                                      "--------------------------------------------------\r\n" +
                                      "Valor total: 219,70\r\n";

        // Assert
        Assert.Equal(inventarioEsperado, inventario);
    }
}