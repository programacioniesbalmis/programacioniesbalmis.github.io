namespace tests_ejemplo2;

using System.Text.Json;

public class UnitTestEj2
{
    [Fact]
    public void Program_Consulta1_Output_Test()
    {
        // Arrange
        var expectedOutput = "Consulta 1: Mostrar titulo, año, país y valoración" +
            "\nde las películas españolas del año 2014" +
            "\nordenados descendentemente por valoración" +
            "\n{ Titulo = Ocho apellidos vascos, Año = 2014, Pais = España, Valoracion = 6,95 }" +
            "\n{ Titulo = El Niño, Año = 2014, Pais = España, Valoracion = 6 }\n";

        // Act
        var output = ProgramEj2.Consulta1();
        // Assert
        Assert.Equal(expectedOutput, output);
    }

    [Fact]
    public void Program_Consulta2_Output_Test()
    {
        // Arrange
        var expectedOutput = "Consulta 2: Mostrar titulo, año, país y duración" +
            "\nde las películas con duración entre 100 y 120 minutos, es decir," +
            "\ncon duración mayor o igual de 100 y menor o igual de 120." +
            "\n{ Titulo = El pasajero, Año = 2018, Pais = Estados Unidos, Duracion = 105 }" +
            "\n{ Titulo = Venganza bajo cero, Año = 2019, Pais = Reino Unido, Duracion = 118 }" +
            "\n{ Titulo = El rey león, Año = 2019, Pais = Estados Unidos, Duracion = 118 }" +
            "\n{ Titulo = Toy Story 4, Año = 2019, Pais = Estados Unidos, Duracion = 100 }\n";

        // Act
        var output = ProgramEj2.Consulta2();
        // Assert
        Assert.Equal(expectedOutput, output);
    }

    [Fact]
    public void Program_Consulta3_Data_Test()
    {
        // Arrange
        var expectedOutput = "Consulta 3: Mostrar titulo, año y géneros\n" +
            "de las películas que el genero sea de \"drama\", \"romance\" o \"fantástico\"\n" +
            "Consulta3Dto { Titulo = El Niño, Año = 2014, Generos = [intriga, accion, drama, policiaca] }\n" +
            "Consulta3Dto { Titulo = Ocho apellidos vascos, Año = 2014, Generos = [comedia, romance, crimen] }\n" +
            "Consulta3Dto { Titulo = Aquaman, Año = 2018, Generos = [accion, fantastico] }\n" +
            "Consulta3Dto { Titulo = El rey león, Año = 2019, Generos = [animacion, aventuras, drama] }\n";

        // Act
        var output = ProgramEj2.Consulta3();

        // Assert
        Assert.Equal(expectedOutput, output);
    }

    [Fact]
    public void Program_Consulta4_Output_Test()
    {
        // Arrange
        var expectedOutput = "Consulta 4: Mostrar titulo, país y reparto\n" +
            "de las películas en las que conste un reparto con 2 actores" +
            "\n{ Titulo = Todos los caminos, Pais = España, Reparto = [Dani Rovira, Clara Lago] }" +
            "\n{ Titulo = El pasajero, Pais = Estados Unidos, Reparto = [Liam Neeson, Patrick Wilson] }\n";

        // Act
        var output = ProgramEj2.Consulta4();
        // Assert
        Assert.Equal(expectedOutput, output);
    }

    [Fact]
    public void Program_Consulta5_Output_Test()
    {
        // Arrange
        var expectedOutput = "Consulta 5: Calcular la duración media de las películas de cada país.\n" +
            "Mostrar -> \"Pais: DuracionMedia\"\n" +
            "España: 107,5\n" +
            "Estados Unidos: 111,2\n" +
            "Reino Unido: 118\n";

        // Act
        var output = ProgramEj2.Consulta5();
        // Assert
        Assert.Equal(expectedOutput, output);
    }

    [Fact]
    public void Program_Consulta6_Output_Test()
    {
        // Arrange
        var expectedOutput = "Consulta 6: Muestra sin repeticiones todos géneros de las peliculas en cartelera usando SelectMany.\n" +
            "[intriga, crimen, accion, drama, policiaca, comedia, romance, documental, fantastico, animacion, aventuras]\n";

        // Act
        var output = ProgramEj2.Consulta6();
        // Assert
        Assert.Equal(expectedOutput, output);
    }

    [Fact]
    public void Program_Consulta3_Output_Test()
    {
        // Arrange
        var jsonFilePath = "consulta3.json";
        if (File.Exists(jsonFilePath))
            File.Delete(jsonFilePath);


        // Act
        ProgramEj2.Main();

        // Assert
        Assert.True(File.Exists(jsonFilePath));
        var jsonContent = File.ReadAllText(jsonFilePath);
        var deserialized = JsonSerializer.Deserialize<List<ProgramEj2.Consulta3Dto>>(jsonContent);
        Assert.NotNull(deserialized);
        Assert.Equal(4, deserialized.Count);
        Assert.Contains(deserialized, p => p.Titulo == "El Niño" && p.Año == 2014 && p.Generos == "[intriga, accion, drama, policiaca]");
        Assert.Contains(deserialized, p => p.Titulo == "Ocho apellidos vascos" && p.Año == 2014 && p.Generos == "[comedia, romance, crimen]");
        Assert.Contains(deserialized, p => p.Titulo == "Aquaman" && p.Año == 2018 && p.Generos == "[accion, fantastico]");
        Assert.Contains(deserialized, p => p.Titulo == "El rey león" && p.Año == 2019 && p.Generos == "[animacion, aventuras, drama]");
    }

}