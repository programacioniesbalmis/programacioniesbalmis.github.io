﻿using System;

public class Program
{
    public static void NumerosAmigos()
    {
        Console.WriteLine("Ejercicio 1: Números amigos");
        //TODO: implementar la lógica del método
    }

    public static void Calculadora()
    {
        Console.WriteLine("\nEjercicio 2: Calculadora");
        //TODO: implementar la lógica del método
    }

    public static void MultiplosDe7()
    {
        Console.WriteLine("\nEjercicio 3: Múltiplos de 7");
        //TODO: implementar la lógica del método
    }

    public static void SecuenciaDeNumeros()
    {
        Console.WriteLine("\nEjercicio 4: Secuencia de números");
        //TODO: implementar la lógica del método
    }

    public static void TrianguloDeAsteriscos()
    {
        Console.WriteLine("\nEjercicio 5: Triángulo de asteriscos");
        //TODO: implementar la lógica del método
    }
    public static void PiramideDeNumeros()
    {
        Console.WriteLine("\nEjercicio 6: Pirámide de números");
        //TODO: implementar la lógica del método
    }

    public static void SumaDeDigitos()
    {
        Console.WriteLine("\nEjercicio 7: Suma de dígitos");
        //TODO: implementar la lógica del método
    }

    public static void PiramideDeNumerosDos()
    {
        Console.WriteLine("\nEjercicio 8: Pirámide de números dos");
        //TODO: implementar la lógica del método
    }

    public static void PiramideDeNumerosCompleta()
    {
        Console.WriteLine("\nEjercicio 9: Pirámide de números completa");
        //TODO: implementar la lógica del método
    }

    public static void BuscarUbicacionDeNumero()
    {
        Console.WriteLine("\nEjercicio 10: Buscar la ubicación de un número");
        //TODO: implementar la lógica del método
    }

    public static void Main(string[] args)
    {
        
        Console.WriteLine("\nPresiona cualquier tecla para salir...");
        Console.ReadKey();
    }
}