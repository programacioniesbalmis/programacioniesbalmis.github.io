﻿using System;

public class Program
{
    public static void ContadorDeNumeros()
    {
        Console.WriteLine("Ejercicio 1: Contador de números");
       // TODO: Implementa la lógica de este método
    }

    public static void SumaYProducto()
    {
        Console.WriteLine("\nEjercicio 2: Suma y producto");
       // TODO: Implementa la lógica de este método
    }

    public static void ContadorNumerosPares()
    {
        Console.WriteLine("\nEjercicio 3: Contador de números pares");
        // TODO: Implementa la lógica de este método
    }

    public static void SumaDeNumeros()
    {
        Console.WriteLine("\nEjercicio 4: Suma de números");
        // TODO: Implementa la lógica de este método
    }

    public static void ProductoMedianteSumas()
    {
        Console.WriteLine("\nEjercicio 5: Producto mediante sumas sucesivas");
        // TODO: Implementa la lógica de este método
    }

    public static void ValidacionDeEntrada()
    {
        Console.WriteLine("\nEjercicio 6: Validación de entrada");
       // TODO: Implementa la lógica de este método
    }

    public static void DivisionMedianteRestas()
    {
        Console.WriteLine("\nEjercicio 7: División mediante restas sucesivas");
        // TODO: Implementa la lógica de este método
    }

    public static void AdivinaNumero(int? semilla = null)
    {
        Console.WriteLine("\nEjercicio 8: Adivinar número");
        // Usamos una semilla opcional para hacer el número a adivinar predecible en tests
        // Si semilla es null, se usa un Random normal
        Random aleatorio = semilla.HasValue ? new Random(semilla.Value) : new Random();
       // TODO: Implementa la lógica de este método
    }

    public static void MaximoYMinimo()
    {
        Console.WriteLine("\nEjercicio 9: Máximo y mínimo");
        // TODO: Implementa la lógica de este método
    }

    public static void SecuenciaFibonacci()
    {
        Console.WriteLine("\nEjercicio 10: Secuencia Fibonacci");
      // TODO: Implementa la lógica de este método
    }

    public static void Main(string[] args)
    {
        ContadorDeNumeros();
        SumaYProducto();
        ContadorNumerosPares();
        SumaDeNumeros();
        ProductoMedianteSumas();
        ValidacionDeEntrada();
        DivisionMedianteRestas();
        AdivinaNumero();
        MaximoYMinimo();
        SecuenciaFibonacci();

        Console.WriteLine("\nPresiona cualquier tecla para salir...");
        Console.ReadLine();
    }
}