﻿using System;

public class Program
{
   

    public static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio 1: Calculadora de Salario");

        //TODO: Implementa el código necesaro
        
        Console.WriteLine("\nPresiona cualquier tecla para salir...");
        Console.ReadKey();
    }
}