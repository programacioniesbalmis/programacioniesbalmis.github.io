using System;

public class Program
{
   
    public static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio 5. Funciones con cuerpo de expresión");
        
        //TODO: Implementa el código necesario

        Console.WriteLine("\nPresiona cualquier tecla para salir...");
        Console.ReadKey();
    }
}