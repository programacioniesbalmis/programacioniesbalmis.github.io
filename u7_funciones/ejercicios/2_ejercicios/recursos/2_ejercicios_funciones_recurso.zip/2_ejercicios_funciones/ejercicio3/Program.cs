using System;

public class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio 3: Proyecto juego");
        //TODO: Implementa el código necesario

        Console.WriteLine("\nPresiona cualquier tecla para salir...");
        Console.ReadKey();
    }
}