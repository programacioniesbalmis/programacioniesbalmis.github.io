﻿using System;

public class Program
{
 
    public static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio 2: Juego de Adivinanza");
        //TODO: Implementa el código necesaro
        Console.WriteLine("¡Gracias por jugar!");
        Console.WriteLine("Presiona cualquier tecla para salir...");
        Console.ReadKey();
    }
}