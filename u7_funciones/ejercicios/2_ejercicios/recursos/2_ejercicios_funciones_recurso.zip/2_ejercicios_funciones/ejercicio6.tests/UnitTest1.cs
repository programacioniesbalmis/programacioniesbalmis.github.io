﻿namespace ejercicio6.tests;

using Ejercicio01;

public class UnitTest1
{
    [Fact]
        public void CosteCarrera_CarreraNormal_CalculaCorrectamente()
        {
            double resultado = Taxi.CosteCarrera(20, 5);
            Assert.Equal(21.38, Math.Round(resultado, 2));
        }

        [Fact]
        public void CosteCarrera_CarreraNocturna_CalculaCorrectamente()
        {
            double resultado = Taxi.CosteCarrera(20, 5, true);
            Assert.Equal(22.10, Math.Round(resultado, 2)); // El resultado esperado depende de la lógica nocturna
        }

        [Fact]
        public void CosteCarrera_CarreraConOcupacionExtra_CalculaCorrectamente()
        {
            double resultado = Taxi.CosteCarrera(20, 5, 1u);
            Assert.Equal(22.38, Math.Round(resultado, 2));
        }

        [Fact]
        public void CosteCarrera_CarreraFestivo_CalculaCorrectamente()
        {
            double resultado = Taxi.CosteCarrera(20, 5, 40);
            Assert.Equal(29.94, Math.Round(resultado, 2));
        }

        [Fact]
        public void CosteCarrera_CarreraNocturnaFestivo_CalculaCorrectamente()
        {
            double resultado = Taxi.CosteCarrera(20, 5, true, 20);
            Assert.Equal(25.66, Math.Round(resultado, 2));
        }

        [Fact]
        public void CosteCarrera_CarreraNocturnaFestivoOcupacionExtra_CalculaCorrectamente()
        {
            double resultado = Taxi.CosteCarrera(20, 5, true, 40, 2u);
            Assert.Equal(31.94, Math.Round(resultado, 2));
        }
}
