﻿using System;

public class Program
{

  
    public static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio 4. Proyecto conversores");

        //TODO: Implementa el código necesario

        Console.WriteLine("Presiona cualquier tecla para salir...");
        Console.ReadKey();
    }
}