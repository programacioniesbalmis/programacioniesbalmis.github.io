﻿using System;
using System.Diagnostics;

public class Program
{
    public static void Ejercicio1()
    {
        Console.WriteLine("Ejercicio 1. Función sin parámetros de entrada y sin retorno");

    }



    public static void Ejercicio2()
    {
        Console.WriteLine("\nEjercicio 2. Función sin parámetros de entrada y sin retorno");
        
    }


    public static void Ejercicio3()
    {
        Console.WriteLine("\nEjercicio 3: Función con múltiples parámetros y sin retorno");
    }


    public static void Ejercicio4()
    {
        Console.WriteLine("\nEjercicio 4. Función que retorna la fecha actual formateada");
    }

    public static void Ejercicio5()
    {
        Console.WriteLine("\nEjercicio 5: Función de validación");
    }

    public static void Ejercicio6()
    {
        Console.WriteLine("\nEjercicio 6. Función generadora de contraseñas");
    }


    public static void Ejercicio7()
    {
        Console.WriteLine("\nEjercicio 7. Calculadora de préstamos");
    }

    public static void Ejercicio8()
    {
        Console.WriteLine("\nEjercicio 8. Función con parámetros de entrada complejos");
    }

    public static void Ejercicio9()
    {
        Console.WriteLine("\nEjercicio 9. Sobrecarga para cálculos de tiempo");
    }

    public static void Ejercicio10()
    {
        Console.WriteLine("\nEjercicio 10. Función con validación de entrada");
    }


    public static void Main(string[] args)
    {
        Ejercicio1();
        Ejercicio2();
        Ejercicio3();
        Ejercicio4();
        Ejercicio5();
        Ejercicio6();
        Ejercicio7();
        Ejercicio8();
        Ejercicio9();
        Ejercicio10();

        Console.WriteLine("\nPresiona cualquier tecla para salir...");
        Console.ReadLine();
    }
}