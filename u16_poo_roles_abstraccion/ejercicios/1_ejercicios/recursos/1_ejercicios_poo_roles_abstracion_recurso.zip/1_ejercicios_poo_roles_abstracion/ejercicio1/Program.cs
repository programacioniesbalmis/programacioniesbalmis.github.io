﻿using System;
using System.Collections.Generic;
using System.Text;

//TODO: Añade el código necesario para implementar los requisitos del ejercicio

public class Program
{
    public static void Main(string[] args)
    {
        GestionaPersonal();
        Console.ReadKey();
    }

    public static void GestionaPersonal()
    {
        Console.WriteLine("Ejercicio 1: Gestión de personal de cuidados\n\nCreando personal...\n");
        //TODO: Añade el código necesario para implementar los requisitos del método
        Console.WriteLine("Presiona cualquier tecla para salir...");
    }
}
