﻿using System;
using System.Collections.Generic;

//TODO: Añade el código necesario para implementar los requisitos del ejercicio

public class Program
{
    public static void Main(string[] args)
    {
        GestionaFormularios();
        Console.ReadKey();
	}

	public static void GestionaFormularios()
	{
		Console.WriteLine("Ejercicio 3: Validación de formularios\n\nPara las entradas de datos...");
		//TODO: Añade el código necesario para implementar los requisitos del método
		Console.WriteLine("Presiona cualquier tecla para salir...");
	}
}
