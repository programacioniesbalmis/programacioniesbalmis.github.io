﻿
using System;
using System.Collections.Generic;
using System.Globalization;

//TODO: Añade el código necesario para implementar los requisitos del ejercicio
public class Program
{
    public static void Main(string[] args)
    {
        GestionaEventos();
        Console.ReadKey();
    }

    public static void GestionaEventos()
    {
        Console.WriteLine("Ejercicio 2: Gestión de agenda de horarios\n\nCreando eventos...\n");

        //TODO: Añade el código necesario para implementar los requisitos del método
        Console.WriteLine("Presiona cualquier tecla para salir...");
    }
}