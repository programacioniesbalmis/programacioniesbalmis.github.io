﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Program
{

    //TODO: Completa el código necesario para cumplir los requisitos del ejercicio

    public static void Main()
    {
        string[] harinas = new string[] { "Trigo", "Centeno", "Espelta", "Maíz" };
        Console.WriteLine("Ejercicio 5. Panadería: pedidos semanales por tipo de harina\n");

        var semana = CreaPedidosSemana(harinas);
        MuestraPedidosSemana(semana);
        MuestraTotalesPedidos(semana, harinas);

        Console.WriteLine("\nPresiona cualquier tecla para salir...");
        Console.ReadKey();
    }
}


