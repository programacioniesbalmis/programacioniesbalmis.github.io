﻿public class Program
{
    // Cartelera del multicine
    static string[][] cartelera = new string[][]
    {
        new string[] {"Avengers", "Matrix", "Inception"},           // Sala A
        new string[] {"Titanic", "Avatar"},                         // Sala B  
        new string[] {"Interstellar", "Dune", "Blade Runner", "Star Wars"} // Sala C
    };

    // Aforos máximos por sala
    static int[] aforosMaximosPorSala = new int[] { 200, 150, 125 };

    // Array para controlar entradas vendidas por película [sala][pelicula]
    static int[][] entradasPorPelicula = new int[][]
    {
        new int[3], // Sala A: 3 películas
        new int[2], // Sala B: 2 películas
        new int[4]  // Sala C: 4 películas
    };


    //TDDO: Implmenta la logica del resto de métodos

    static void Main()
    {

        Console.WriteLine("Ejercicio 5. Sistema completo de gestión de multicine\n");
        //TodO: Implementa la lógica necesaria
        Console.WriteLine("\nPresiona cualquier tecla para salir...");
        Console.ReadKey();

    }
}

