﻿using System.Text;

public class Program
{
    //TODO: Implementa la lógica del resto de métodos
    public static void Main()
    {

        Console.WriteLine("Ejercicio 4: Jardín de flores con inventario colorido\n");

        //TODO: Implementa la lógica necesaria
        Console.WriteLine("\nPresiona cualquier tecla para salir...");
        Console.ReadKey();
    }

}
