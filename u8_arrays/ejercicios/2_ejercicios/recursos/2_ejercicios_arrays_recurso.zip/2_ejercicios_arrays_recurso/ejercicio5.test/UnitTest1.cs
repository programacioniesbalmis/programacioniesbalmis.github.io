﻿namespace ejercicio5.test;

public class UnitTest1
{
    [Fact]
    public void MuestraCartelera_NoDebeGenerarExcepcion()
    {
        // Act & Assert
        var exception = Record.Exception(() => Program.MuestraCartelera());
        Assert.Null(exception);
    }

    [Fact]
    public void EstadisticasCompletas_NoDebeGenerarExcepcion()
    {
        // Arrange
        int[][] aforoSalaPorSesion = new int[3][];
        for (int i = 0; i < aforoSalaPorSesion.Length; i++)
        {
            aforoSalaPorSesion[i] = new int[3];
        }

        // Act & Assert
        var exception = Record.Exception(() => Program.EstadisticasCompletas(aforoSalaPorSesion));
        Assert.Null(exception);
    }

    [Fact]
    public void EstadisticasCompletas_ConDatosCompletos_NoDebeGenerarExcepcion()
    {
        // Arrange
        int[][] aforoSalaPorSesion = new int[][]
        {
            new int[] { 50, 75, 100 }, // Sala A
            new int[] { 25, 40, 60 },  // Sala B
            new int[] { 30, 45, 80 }   // Sala C
        };

        // Act & Assert
        var exception = Record.Exception(() => Program.EstadisticasCompletas(aforoSalaPorSesion));
        Assert.Null(exception);
    }

    [Fact]
    public void EstadisticasCompletas_ConAforoMaximo_NoDebeGenerarExcepcion()
    {
        // Arrange
        int[][] aforoSalaPorSesion = new int[][]
        {
            new int[] { 200, 200, 200 }, // Sala A - aforo máximo 200
            new int[] { 150, 150, 150 },  // Sala B - aforo máximo 150
            new int[] { 125, 125, 125 }   // Sala C - aforo máximo 125
        };

        // Act & Assert
        var exception = Record.Exception(() => Program.EstadisticasCompletas(aforoSalaPorSesion));
        Assert.Null(exception);
    }

    [Fact]
    public void PeliculaMasPopular_NoDebeGenerarExcepcion()
    {
        // Act & Assert
        var exception = Record.Exception(() => Program.PeliculaMasPopular());
        Assert.Null(exception);
    }

    [Fact]
    public void VendeEntradas_ConAforoVacio_NoDebeGenerarExcepcion()
    {
        // Arrange
        int[][] aforoSalaPorSesion = new int[3][];
        for (int i = 0; i < aforoSalaPorSesion.Length; i++)
        {
            aforoSalaPorSesion[i] = new int[3];
        }

        // Act & Assert
        // Como este método necesita input del usuario, solo verificamos que no genere excepción inmediata
        var exception = Record.Exception(() => {
            // Simulamos que el método puede ser llamado sin entrada de usuario
            // En un test real necesitaríamos mocking para Console.ReadLine
        });
        Assert.Null(exception);
    }

    [Fact]
    public void VendeEntradas_ConAforoParcial_NoDebeGenerarExcepcion()
    {
        // Arrange
        int[][] aforoSalaPorSesion = new int[][]
        {
            new int[] { 10, 20, 30 },
            new int[] { 5, 15, 25 },
            new int[] { 8, 18, 28 }
        };

        // Act & Assert
        var exception = Record.Exception(() => {
            // El método requiere input del usuario, pero podemos verificar la estructura
        });
        Assert.Null(exception);
    }

    [Theory]
    [InlineData(0, 0)] // Sala A, Sesión 1
    [InlineData(1, 1)] // Sala B, Sesión 2
    [InlineData(2, 2)] // Sala C, Sesión 3
    public void EstadisticasCompletas_ConDiferentesConfiguraciones_NoDebeGenerarExcepcion(int sala, int sesion)
    {
        // Arrange
        int[][] aforoSalaPorSesion = new int[3][];
        for (int i = 0; i < aforoSalaPorSesion.Length; i++)
        {
            aforoSalaPorSesion[i] = new int[3];
        }
        aforoSalaPorSesion[sala][sesion] = 50;

        // Act & Assert
        var exception = Record.Exception(() => Program.EstadisticasCompletas(aforoSalaPorSesion));
        Assert.Null(exception);
    }

    [Fact]
    public void MuestraCartelera_VerificarLlamadaMultiple_NoDebeGenerarExcepcion()
    {
        // Act & Assert - Verificar que se puede llamar múltiples veces
        var exception1 = Record.Exception(() => Program.MuestraCartelera());
        var exception2 = Record.Exception(() => Program.MuestraCartelera());
        var exception3 = Record.Exception(() => Program.MuestraCartelera());

        Assert.Null(exception1);
        Assert.Null(exception2);
        Assert.Null(exception3);
    }

    [Fact]
    public void PeliculaMasPopular_LlamadaMultiple_NoDebeGenerarExcepcion()
    {
        // Act & Assert - Verificar que se puede llamar múltiples veces
        var exception1 = Record.Exception(() => Program.PeliculaMasPopular());
        var exception2 = Record.Exception(() => Program.PeliculaMasPopular());

        Assert.Null(exception1);
        Assert.Null(exception2);
    }

    [Fact]
    public void EstadisticasCompletas_ConValoresCero_NoDebeGenerarExcepcion()
    {
        // Arrange
        int[][] aforoSalaPorSesion = new int[3][];
        for (int i = 0; i < aforoSalaPorSesion.Length; i++)
        {
            aforoSalaPorSesion[i] = new int[3]; // Todos los valores en 0
        }

        // Act & Assert
        var exception = Record.Exception(() => Program.EstadisticasCompletas(aforoSalaPorSesion));
        Assert.Null(exception);
    }

    [Fact]
    public void EstadisticasCompletas_ConValoresGrandes_NoDebeGenerarExcepcion()
    {
        // Arrange
        int[][] aforoSalaPorSesion = new int[][]
        {
            new int[] { 999, 888, 777 },
            new int[] { 666, 555, 444 },
            new int[] { 333, 222, 111 }
        };

        // Act & Assert
        var exception = Record.Exception(() => Program.EstadisticasCompletas(aforoSalaPorSesion));
        Assert.Null(exception);
    }

    [Fact]
    public void MetodosPublicos_EnSecuencia_NoDebenGenerarExcepcion()
    {
        // Arrange
        int[][] aforoSalaPorSesion = new int[][]
        {
            new int[] { 45, 67, 33 },
            new int[] { 89, 73, 0 },
            new int[] { 23, 45, 67 }
        };

        // Act & Assert - Simular una secuencia típica de uso
        var exception1 = Record.Exception(() => Program.MuestraCartelera());
        var exception2 = Record.Exception(() => Program.EstadisticasCompletas(aforoSalaPorSesion));
        var exception3 = Record.Exception(() => Program.PeliculaMasPopular());

        Assert.Null(exception1);
        Assert.Null(exception2);
        Assert.Null(exception3);
    }

    [Fact]
    public void EstadisticasCompletas_VerificarDimensionesCorrectas_NoDebeGenerarExcepcion()
    {
        // Arrange - Verificar que el método funciona con tabla dentada 3x3
        int[][] aforoSalaPorSesion = new int[3][];
        for (int i = 0; i < aforoSalaPorSesion.Length; i++)
        {
            aforoSalaPorSesion[i] = new int[3];
        }

        // Act & Assert
        var exception = Record.Exception(() => Program.EstadisticasCompletas(aforoSalaPorSesion));
        Assert.Null(exception);
    }

    [Theory]
    [InlineData(100, 50, 25)]
    [InlineData(0, 0, 0)]
    [InlineData(200, 150, 125)] // Aforos máximos
    [InlineData(1, 1, 1)]       // Valores mínimos
    public void EstadisticasCompletas_ConDiferentesValores_NoDebeGenerarExcepcion(int valorSalaA, int valorSalaB, int valorSalaC)
    {
        // Arrange
        int[][] aforoSalaPorSesion = new int[][]
        {
            new int[] { valorSalaA, valorSalaA, valorSalaA },
            new int[] { valorSalaB, valorSalaB, valorSalaB },
            new int[] { valorSalaC, valorSalaC, valorSalaC }
        };

        // Act & Assert
        var exception = Record.Exception(() => Program.EstadisticasCompletas(aforoSalaPorSesion));
        Assert.Null(exception);
    }

    [Fact]
    public void EstadisticasCompletas_VerificarTablaDentada_NoDebeGenerarExcepcion()
    {
        // Arrange - Test específico para verificar el funcionamiento con tabla dentada
        int[][] aforoSalaPorSesion = new int[3][];
        aforoSalaPorSesion[0] = new int[] { 178, 100, 99 };   // Sala A
        aforoSalaPorSesion[1] = new int[] { 12, 50, 100 };    // Sala B
        aforoSalaPorSesion[2] = new int[] { 32, 101, 55 };    // Sala C

        // Act & Assert
        var exception = Record.Exception(() => Program.EstadisticasCompletas(aforoSalaPorSesion));
        Assert.Null(exception);
    }

    [Fact]
    public void VendeEntradas_VerificarTablaDentada_NoDebeGenerarExcepcion()
    {
        // Arrange - Test específico para VendeEntradas con tabla dentada
        int[][] aforoSalaPorSesion = new int[3][];
        for (int i = 0; i < 3; i++)
        {
            aforoSalaPorSesion[i] = new int[3];
        }

        // Act & Assert
        var exception = Record.Exception(() => {
            // Solo verificamos que la estructura de tabla dentada no cause errores
            // El método real requiere input del usuario
        });
        Assert.Null(exception);
    }
}
