﻿public class Program
{
    //TODO: Implementa la lógica del resto de métodos

    private static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio 1: Tabla dentada cuadrada con patrón \n");

        //TODO: Implementa la lógica necesaria

        Console.WriteLine("\nPresiona cualquier tecla para salir...");
        Console.ReadKey();
    }
}