﻿using System;

public class Program
{
    private static readonly string[] meses = {
        "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
        "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
    };

    // TODO: Implementa la lógica del resto de métodos

    public static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio 8: Estadísticas de ventas\n");

        // TODO: Implementa la lógica de este método

        Console.WriteLine("\nPresiona cualquier tecla para salir...");
        Console.ReadKey();
    }
}
