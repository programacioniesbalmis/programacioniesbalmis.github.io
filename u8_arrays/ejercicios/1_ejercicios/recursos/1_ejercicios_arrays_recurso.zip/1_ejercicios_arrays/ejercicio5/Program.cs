﻿using System;

public class Program
{
    // TODO: Implementa la lógica del resto de métodos

    public static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio 5: Desplazamiento circular a la derecha\n");

        // TODO: Implementa la lógica de este método

        Console.WriteLine("\nPresiona cualquier tecla para salir...");
        Console.ReadKey();
    }
}
