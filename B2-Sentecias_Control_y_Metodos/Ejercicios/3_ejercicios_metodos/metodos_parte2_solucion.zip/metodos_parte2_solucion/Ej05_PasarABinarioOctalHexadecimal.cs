﻿using System;
using System.Diagnostics;

namespace Ej05_PasarABinarioOctalHexadecimal
{
    class Ej05_PasarABinarioOctalHexadecimal
    {
        /* Escribe un programa que lea un número en base 10 y que muestre un menú que nos permita convertirlo
         * a base 2, base 8 y base hexadecimal. Crea un método llamado PasarABinario, otro llamado PasarAOctal
         * y otro llamado PasarAHexadecimal.
         */
        static string SimboloValorEnBase(ulong valor)
        {
            string simbolo;

            Debug.Assert(valor >= 0 && valor <= 15, "Valor no válido.");

            switch (valor)
            {
                case 10:
                    simbolo = "A";
                    break;
                case 11:
                    simbolo = "B";
                    break;
                case 12:
                    simbolo = "C";
                    break;
                case 13:
                    simbolo = "D";
                    break;
                case 14:
                    simbolo = "E";
                    break;
                case 15:
                    simbolo = "F";
                    break;
                default:
                    simbolo = $"{valor}";
                    break;
            }

            return simbolo;
        }

        static string RepresentacionEnBaseNumerica(ulong valor, ulong baseNumerica)
        {
            string cadenaRepresentacion = "";

            while (valor >= baseNumerica)
            {
                ulong resto = valor % baseNumerica;

                cadenaRepresentacion = SimboloValorEnBase(resto) + cadenaRepresentacion;
                valor /= baseNumerica;
            }
            cadenaRepresentacion = SimboloValorEnBase(valor) + cadenaRepresentacion;

            return cadenaRepresentacion;
        }

        static void Main()
        {
            Console.Write("Introduzca el valor en base 10 o decimal a covertir: ");
            ulong valor = ulong.Parse(Console.ReadLine());

            string binario = RepresentacionEnBaseNumerica(valor, 2);
            string octal = RepresentacionEnBaseNumerica(valor, 8);
            string hexadecimal = RepresentacionEnBaseNumerica(valor, 16);

            Console.WriteLine("Binario: " + binario);
            Console.WriteLine("Octal: " + octal);
            Console.WriteLine("Hexadecimal: " + hexadecimal);
        }
    }
}
