using System;

namespace Ej06_PrecioVemta
{
    /* En una tienda de piezas de repuesto se realizan una seríe de ventas de las que 
     * tendremos que calcular el precio final a pagar. Escribe un programa teniendo en 
     * cuenta que los descuentos a efectuar están en función de:
     * La clase de comprador (clase A: 2%, clase B: 4% y clase C: 6%)
     * Del tipo de pieza (tipo 1: 8% y tipo 2: 10%).
     * Crea un método LeeDatos que recoja el precio de la
     * pieza, la clase de comprador y el tipo de pieza, y los devuelva mediante tupla.
     * Escribe un método llamada PrecioAPagar, para calcular y devolver el precio final. 
     * A este método se le pasará la tuplaa y devolverá el valor del precio final, se
     * hará a través de un switch C#8.
     * Nota: Se termina la introducción de datos cuando un precio sea cero. El programa
     * visualizara el precio parcial de cada venta y una vez terminadas estas, el importe 
     * total líquido obtenido en las ventas efectuadas (la suma de total de todas las ventas).
     */
    class Ej06_PrecioVemta
    {
        static (float precio, char clase, short tipo) LeeDatos()
        {
            (float precio, char clase, short tipo) datos;
            Console.WriteLine("Introduce el precio de la pieza: ");
            datos.precio=float.Parse(Console.ReadLine());
            Console.WriteLine("Introduce la clase del comprador: ");
            datos.clase=char.Parse(Console.ReadLine());
            Console.WriteLine("Introduce el tipo de pieza: ");
            datos.tipo=short.Parse(Console.ReadLine());
            return datos;
        }
        static float PrecioAPagar((float precio, char clase, short tipo)datos)
        {
          float descuento= (datos.clase, datos.tipo)switch 
          {
             ('A',1)=>datos.precio*0.02f+datos.precio*0.08f,
             ('A',2)=>datos.precio*0.02f+datos.precio*0.1f,
             ('B',1)=>datos.precio*0.04f+datos.precio*0.08f,
             ('B',2)=>datos.precio*0.04f+datos.precio*0.1f,
             ('C',1)=>datos.precio*0.06f+datos.precio*0.08f,
             ('C',2)=>datos.precio*0.06f+datos.precio*0.1f,
             (_,_)=> 0
          };
          return datos.precio-descuento;
        }
       
        static void Main()
        {
            (float precio, char clase, short tipo) datos=LeeDatos();
            Console.WriteLine("El precio a pagar es: "+ PrecioAPagar(datos));
        }
    }
    
}

