using System;

namespace Ej03_CuadradoCubo
{
	/* Escribir en forma de tabla los cuadrados y los cubos de los 10 
	 * primeros números enteros positivos. Definir para ello un método 
	 * Cuadrado y otra Cubo, que te eleven un número al cuadrado y otro al cubo.
	 */
    class Ej03_CuadradoCubo
    {
        static long Cuadrado(int numero)
        {
            return numero*numero;
        }
         static long Cubo(int numero)
        {
            return numero*numero*numero;
        }
         static void Main()
        {
             Console.WriteLine("{0,10} {1,10} {2,10}", "numero", "cuadrado","cubo");
          for(int i=1; i<=10; i++)
             Console.WriteLine($"{i,10} {Cuadrado(i),10} {Cubo(i),10}");
        }
    }
    
}

