using System;


namespace Ej02_NumeroMajico
{
    /* Realiza un programa para calcular el número mágico de una persona.
     * El número mágico de una persona debe considerarse como la suma de las
     * cifras de su día de nacimiento, repitiendo el proceso hasta que la suma 
     * de las cifras devuelva un número menor de 10.
     * De esta forma, alguien nacido el 7 de marzo de 1965 tendría como número mágico el 4.
     */
    class  Ej02_NumeroMajico
    {
        static void LeeFecha(out short dia, out short mes, out short año)
        {
            Console.WriteLine("Introduce el dia de nacimiento: ");
            dia=short.Parse(Console.ReadLine());
            Console.WriteLine("Introduce el mes de nacimiento: ");
            mes=short.Parse(Console.ReadLine());
            Console.WriteLine("Introduce el año de nacimiento: ");
            año=short.Parse(Console.ReadLine());
        }
        static short SumaCifras(short numero)
        {
            short sumaCifras=0;
            while(numero>10)
            {
                sumaCifras+=(short)(numero%10);
                numero=(short)(numero/10);
                
            }
            sumaCifras+=numero;
            return sumaCifras;

        }
        static short NumeroMajico( short dia,  short mes,  short año)
        {
            short numero=(short) (SumaCifras(dia)+SumaCifras(mes)+SumaCifras(año));
            while(numero>10) numero=SumaCifras(numero);
            return numero;
        }
        static void Main()
        {
            short dia, mes, año;
            LeeFecha(out dia, out mes, out año);
            Console.WriteLine("El número mágico es: "+ NumeroMajico(dia,mes,año));
        }
    }
    
}

