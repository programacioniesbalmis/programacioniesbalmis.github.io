﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ej04_ComentarResultadoPrograma_1_
{
    class Program
    {
        static public int a=0, b=3;
        
        static int Func1 (int a)
        {
            b = b + Func2(a) + 1;
            return b;
        }

        static int Func2 (int a)
        {
            return (b + a + 1);
        }

        static void Main()
        {
            int cont;
            for (cont=1; cont<=5; cont++)
            {
                b = Func1(cont + a + b) + 1;
                Console.WriteLine("{0} ",b);
            }
        }
    }
}
