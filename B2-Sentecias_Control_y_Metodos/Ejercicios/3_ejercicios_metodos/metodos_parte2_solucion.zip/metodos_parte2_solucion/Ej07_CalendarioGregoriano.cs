﻿using System;
using System.Diagnostics;

namespace Ej07_CalendarioGregoriano
{
    class Ej07_CalendarioGregoriano
    {
        /* El calendario Gregoriano actual obedece a la reforma del calendario juliano que ordenó el papa Gregorio XIII
         * en 1582. Se decidió, después de algunas modificaciones, que en lo sucesivo fuesen bisiestos todos los años
         * múltiplos de cuatro, pero que de los años seculares (los acabados en dos ceros) sólo fuesen bisiestos aquellos
         * que fuesen múltiplos de cuatrocientos. En base a estos conceptos, construir un programa que dada una fecha
         * (día, mes y año), nos devuelva como resultado el correspondiente día de la semana. La estructura del programa
         * estará formada, además de por el método main, por las funciones: LeerFecha, DatosValidos, AnyoBisiesto, DiaSemana.
         */

        static (int dia, int mes, int año) LeeFecha()
        {
            Console.Write("Introduzca dia: ");
            int dia = int.Parse(Console.ReadLine());

            Console.Write("Introduzca mes: ");
            int mes = int.Parse(Console.ReadLine());

            Console.Write("Introduzca año: ");
            int año = int.Parse(Console.ReadLine());

            return (dia, mes, año);
        }

        static bool FechaValida(int dia, int mes, int año)
        {
            bool valida;

            if (año >= 1582 && dia >= 1)
            {
                switch (mes)
                {
                    case 1:
                    case 3:
                    case 5:
                    case 7:
                    case 8:
                    case 10:
                    case 12:
                        valida = dia <= 31;
                        break;

                    case 4:
                    case 6:
                    case 9:
                    case 11:
                        valida = dia <= 30;
                        break;

                    case 2:
                        valida = dia == 29 && Bisiesto(año) || dia < 29;
                        break;

                    default:
                        valida = false;
                        break;
                }
            }
            else
                valida = false;

            return valida;
        }

        static bool Bisiesto(int año)
        {
            return año % 4 == 0 && año % 100 != 0 || año % 400 == 0;
        }

        static string DiaSemana(int dia, int mes, int año)
        {
            if (mes <= 2)
            {
                mes += 12;
                año -= 1;
            }

            int diaSemana = (dia + 2 * mes + 3 * (mes + 1) / 5 + año + año / 4 - año / 100 + año / 400 + 2) % 7;

            return diaSemana switch
            {
                0 => "Sabado",
                1 => "Domingo",
                2 => "Lunes",
                3 => "Martes",
                4 => "Miercoles",
                5 => "Jueves",
                6 => "Viernes",
                _ => "Desconocido",
            };
        }

        static void Main()
        {
            (int dia, int mes, int año) = LeeFecha();
            string salida = FechaValida(dia, mes, año)
                            ? "La fecha es correcta y cae en " + DiaSemana(dia, mes, año)
                            : "La fecha no es correcta.";
            Console.WriteLine(salida);
        }
    }
}
