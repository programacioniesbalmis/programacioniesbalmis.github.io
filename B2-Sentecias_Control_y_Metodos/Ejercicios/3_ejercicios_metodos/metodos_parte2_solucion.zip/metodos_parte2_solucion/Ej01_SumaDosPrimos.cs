using System;

namespace Ej01_SumaDosPrimos
{
    class Ej01_SumaDosPrimos
    {
		/*
		 * Escribe un método al se le pase un número y diga si es primo o no. 
		 * Suponiendo ya definido el método anterior, escribe un programa que 
		 * lea dos números enteros por teclado y los sume sólo si son primos, 
		 * indicando si el resultado también es primo.
         * En caso contrario, debe decir cuál (o cuáles) de ellos no son primos.
		*/
        static bool EsPrimo(int numero)
        {

            for(int i=2; i<numero;i++) if(numero%i==0) return false;
            return true;
        }
         static void Main()
        {
            int numero1, numero2;
            Console.WriteLine("Introduce el primer número:");
            numero1=int.Parse(Console.ReadLine());
            Console.WriteLine("Introduce el segundo número:");
            numero2=int.Parse(Console.ReadLine());
            Boolean esPrimoNumero1=EsPrimo(numero1);
            Boolean esPrimoNumero2=EsPrimo(numero2);
            if(esPrimoNumero1 && esPrimoNumero2) Console.WriteLine($"La suma de los dos números primos es {numero1+numero2}");
            else if(!esPrimoNumero1) Console.WriteLine($"El número {numero1} no es primo");
                else Console.WriteLine($"El número {numero2} no es primo");
        }
    }
    
}

