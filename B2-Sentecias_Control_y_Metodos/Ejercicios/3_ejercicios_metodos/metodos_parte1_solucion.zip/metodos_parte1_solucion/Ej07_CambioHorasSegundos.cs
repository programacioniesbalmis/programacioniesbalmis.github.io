using System;


namespace Ej07_CambioHorasSegundos
{
    /*Construye un programa que dados tres números enteros correspondientes a la hora, 
	 * minutos y segundos actuales, calcula la hora (en el mismo formato) que será un 
	 * segundo más tarde. Para ello, se deben diseñar dos métodos:
	 * • HoraASegundos que dados tres argumentos de entrada correspondientes a hora, minutos y
     * segundos, devuelva la conversión de dicha hora a segundos desde las 00:00:00.
     * • SegundosAHora, que dado un argumento de entrada correspondiente a una hora en segundos 
	 * desde las 00:00:00, la convierta en horas, minutos y segundos y la devuelva. Devolverás
	 * la información mediante parámetros de salida.
     * Nota: El algoritmo debe leer la hora en formato HH, MM y SS, después transformarla 
	 * a segundos (con HoraASegundos), sumarle uno a dichos segundos y después volver
     * a transformarla en HH, MM y SS (con HoraASegundos).
	*/
    class Ej07_CambioHorasSegundos
    {
        static long HoraASegundos(int hora, int minutos, int segundos)
        {
            return hora * 60 * 60 + minutos * 60 + segundos;
        }
        static (int hora, int minutos, int segundos) SegundosAHora(long segundosTotales)
        {
            int hora = (int)(segundosTotales / (60 * 60));
            int minutos = (int)(segundosTotales % (60 * 60) / 60);
            int segundos = (int)(segundosTotales % (60 * 60) % 60);

            return (hora, minutos, segundos);
        }

        static void Muestra(int hora, int minutos, int segundos)
        {
            Console.WriteLine($"Hora: {hora:D2}:{minutos:D2}:{segundos:D2}");
        }

        static void Main()
        {
            int hora = 12, minutos = 59, segundos = 59;

            Muestra(hora, minutos, segundos);

            long segundosTotales = HoraASegundos(hora, minutos, segundos);
            segundosTotales++;
            (hora, minutos, segundos) = SegundosAHora(segundosTotales);

            Muestra(hora, minutos, segundos);
        }
    }

}

