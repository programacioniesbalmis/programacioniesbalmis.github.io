using System;


namespace Ej07_CambioHorasSegundos
{
	/*Construye un programa que dados tres números enteros correspondientes a la hora, 
	 * minutos y segundos actuales, calcula la hora (en el mismo formato) que será un 
	 * segundo más tarde. Para ello, se deben diseñar dos métodos:
	 * • HoraASegundos que dados tres argumentos de entrada correspondientes a hora, minutos y
     * segundos, devuelva la conversión de dicha hora a segundos desde las 00:00:00.
     * • SegundosAHora, que dado un argumento de entrada correspondiente a una hora en segundos 
	 * desde las 00:00:00, la convierta en horas, minutos y segundos y la devuelva. Devolverás
	 * la información mediante parámetros de salida.
     * Nota: El algoritmo debe leer la hora en formato HH, MM y SS, después transformarla 
	 * a segundos (con HoraASegundos), sumarle uno a dichos segundos y después volver
     * a transformarla en HH, MM y SS (con HoraASegundos).
	*/
	class Ej07_CambioHorasSegundos
    {
        static long  HoraASegundos(int hora, int minutos, int segundos)
        {
            
            return hora*60*60+minutos*60+segundos;
        }
        static void SegundosAHora (long segundosTotales, out int hora, out int minutos, out int segundos )
        {
           
           hora=(int) (segundosTotales/(60*60));
           minutos=(int) ((segundosTotales%(60*60))/60);
           segundos=(int)  ((segundosTotales%(60*60))%60);
          
        }

         static void Main()
        {
            int hora, minutos, segundos;

            long segundosTotales=HoraASegundos(DateTime.Now.Hour, DateTime.Now.Minute,DateTime.Now.Second);
            segundosTotales+=1;
            SegundosAHora(segundosTotales,out hora,out minutos, out segundos);
            Console.WriteLine(hora+":"+minutos+":"+segundos);

        }
    }
    
}

