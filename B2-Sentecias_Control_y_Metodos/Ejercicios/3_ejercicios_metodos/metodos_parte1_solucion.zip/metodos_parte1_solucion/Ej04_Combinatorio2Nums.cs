﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ej04_Combinatorio2Nums
{
	 /* Implementa un programa en C# con un método que admita como argumento dos números enteros (m y n)
         * y devuelva como valor asociado al nombre de la función el número combinatorio. Este método debe
         * llamar a su vez al método factorial (que devolverá el factorial de un número pasado como argumento).*/

    class Ej04_Combinatorio2Nums
    {
       
        static double factorial(double valor)
        {
            double resultado = 1;

            for (double i = 2; i <= valor; i--)
                resultado = resultado * i;

            return resultado;
        }

        static double combinatorio(double m, double n)
        {
            double resultado;

            resultado = factorial(m) / (factorial(n) * factorial(m - n));

            return resultado;
        }

        static void Main()
        {
            Console.Write("Introduzca m: ");
            double m = double.Parse(Console.ReadLine());
            Console.Write("Introduzca n: ");
            double n = double.Parse(Console.ReadLine());

            double resultado = combinatorio(m, n);
            Console.WriteLine("\nCombinatorio de {0} y {1} = {2}", m, n, resultado);
        }
    }
}
