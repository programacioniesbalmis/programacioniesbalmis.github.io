﻿using System;
using System.Diagnostics;

namespace Ej09_AdivinarNumeroValorAleatoriaEntre1y50
{
    
        /* Escribe un programa para jugar a adivinar números. El programa tiene que seguir los siguientes pasos:
		 * Calcular de forma aleatoria el número a adivinar por el jugador. El número debe hallarse entre 0 y 50 (ambos inclusive).
		 * Preguntar un número al jugador y dar una pista indicando si el número introducido es mayor o menor que el número a adivinar.
         * Si el jugador acierta el número, la partida terminará indicando la cantidad de tentativas hechas por este jugador para acertar.
         * Habrá un máximo de tentativas dependiendo del nivel elegido para jugar: fácil =10, medio = 6, difícil = 4.
         * El programa preguntará si se desea seguir jugando. Si se responde que sí el juego seguirá pidiendo un nuevo nivel y generando otro número.
         * Para salir abra que pulsar ESC.
         *Nota: Será necesario realizar los métodos y el paso de parámetros que consideres adecuado para una correcta programación.
         */
    class Ej09_AdivinarNumeroValorAleatoriaEntre1y50
    {
        static int NumeroAleatorioDe0a50()
        {
            return new Random().Next(0, 51);
        }

        private static int LeeNivel()
        {
            int nivel;
            bool nivelCorrecto;
            do
            {
                Console.Write("Nivel (1-fácil, 2-medio 3-difícil): ");
                nivel = int.Parse(Console.ReadLine());
                nivelCorrecto = nivel >= 1 && nivel <= 3;
                if (!nivelCorrecto)
                    Console.WriteLine("Nivel incorrecto!!!.");
            }
            while (!nivelCorrecto);
            return nivel;
        }

        static int? ObtenIntentosAPartirDe(in int nivel)
        {
            int? intentos = nivel switch
            {
                1 => 10,
                2 => 6,
                3 => 4,
                _ => null
            };

            Debug.Assert(intentos != null);

            return intentos;
        }

        static string ATexto(in int nivel)
        {
            return nivel switch
            {
                1 => "Fácil",
                2 => "Medio",
                3 => "Difícil",
                _ => null
            };
        }

        static string MensajeFallo(
            in int nIntroducido,
            in int nAAdivinar,
            in int? intentosRestantes)
        {
            string mensaje = "Has fallado\n";
            mensaje += nIntroducido > nAAdivinar
                        ? "El número es menor... "
                        : "El número es mayor... ";
            mensaje += $"te quedan {intentosRestantes} intentos";
            return mensaje;
        }
        private static void JuegaAAdivinar(in int numero, in int nivel)
        {
            int intentos = 0;
            bool acertado = false;

            int? intentosMaximos = ObtenIntentosAPartirDe(nivel);
            Console.WriteLine($"Vas a en nivel {ATexto(nivel)} con {intentosMaximos} intentos.");
            while (!acertado && intentos <= intentosMaximos)
            {
                Console.Write("Divina el número: ");
                int n = int.Parse(Console.ReadLine());

                acertado = n == numero;

                intentos++;
                if (!acertado)
                    Console.WriteLine(MensajeFallo(n, numero, intentosMaximos - intentos));
            }

            string mensaje = acertado
                        ? "Enhorabuena has acertado."
                        : $"Lo siento el número a adivinar era {numero}";
            Console.WriteLine(mensaje);
        }

        static bool JuegaOtraVez()
        {
            bool entradaValida;
            bool jugarOtraVez;
            do
            {
                Console.WriteLine("Pulsa una tecla para jugar otra partida 'S' y ESC para salir.");

                var tecla = Console.ReadKey(true).Key;
                entradaValida = tecla == ConsoleKey.Escape || tecla == ConsoleKey.S;

                if (!entradaValida)
                    Console.WriteLine("Entrada inválida.");
                jugarOtraVez = Console.ReadKey(true).Key != ConsoleKey.Escape;
            }
            while(!entradaValida);

            return jugarOtraVez;
        }

        static void Main()
        {
            bool jugarOtraVez;
            do
            {   
                int numeroAAdivinar = NumeroAleatorioDe0a50();
                int nivel = LeeNivel();            
                JuegaAAdivinar(numeroAAdivinar, nivel);

                jugarOtraVez = JuegaOtraVez();
            }
            while(jugarOtraVez);
        }
    }
}