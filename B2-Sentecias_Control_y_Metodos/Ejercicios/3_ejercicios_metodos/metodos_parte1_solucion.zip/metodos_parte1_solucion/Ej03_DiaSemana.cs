﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace Ej03_DiaSemana
{
	/* Escribe un algoritmo que, dados por teclado cinco días de la semana, 
		 * escritos en forma de número, muestre el nombre del día asociado a cada uno de ellos.
		 * Para ello, implementa el procedimiento DiaSemana, que dado un número escriba en 
		 * pantalla el día correspondiente (utilizando switch)...
         * Nota: el parámetro del procedimiento será de entrada y por referencia. Además 
		 * deberá comprobar que el número de entrada esté en el rango de 1 a 7 indicando, 
		 * si es necesario, que la entrada no ha sido valida.*/
    class Ej03_DiaSemana
    {
        static string DiaSemana(in int dia)
        {
            string nombreDia;

            switch (dia)
            {
                case 1:
                    nombreDia = "Lunes";
                    break;

                case 2:
                    nombreDia = "Martes";
                    break;

                case 3:
                    nombreDia = "Miercoles";
                    break;

                case 4:
                    nombreDia = "Jueves";
                    break;

                case 5:
                    nombreDia = "Viernes";
                    break;

                case 6:
                    nombreDia = "Sábado";
                    break;

                case 7:
                    nombreDia = "Domingo";
                    break;

                default:
                    nombreDia = "";
                    Debug.Assert(false, "Día de la semána no válido.");
                    break;
            }

            return nombreDia;
        }

        static void Main()
        {
            int dia;

            for (int i = 0; i < 5; i++)
            {
                Console.Write("Introduce dia de la semana: ");
                dia = int.Parse(Console.ReadLine());

                Console.WriteLine(DiaSemana(in dia));
            }
        }
    }
}
