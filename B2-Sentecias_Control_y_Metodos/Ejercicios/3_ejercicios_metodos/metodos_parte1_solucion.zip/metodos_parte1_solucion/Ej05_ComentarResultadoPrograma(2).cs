﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ej05_ComentarResultadoPrograma_2_
{
    class Program
    {
        public const int n = 5; //Variable global: accesible desde cualquier parte del programa
        public static int b = 2, a = 3; //Variable global
        
        static int funcion(int b)
        {
            int c;
            c = b + a; 
            b++;
            return c;
        }

        static void Main()
        {
            int i;
            for (i = 0; i < n; i++)
                b = funcion(i);
            Console.WriteLine(b);
        }
    }
}
