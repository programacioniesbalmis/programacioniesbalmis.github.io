﻿using System;
using System.Diagnostics;

namespace Ej09_AdivinarNumeroValorAleatoriaEntre1y50
{
    
        /* Escribe un programa para jugar a adivinar números. El programa tiene que seguir los siguientes pasos:
		 * Calcular de forma aleatoria el número a adivinar por el jugador. El número debe hallarse entre 0 y 50 (ambos inclusive).
		 * Preguntar un número al jugador y dar una pista indicando si el número introducido es mayor o menor que el número a adivinar.
         * Si el jugador acierta el número, la partida terminará indicando la cantidad de tentativas hechas por este jugador para acertar.
         * Habrá un máximo de tentativas dependiendo del nivel elegido para jugar: fácil =10, medio = 6, difícil = 4.
         * El programa preguntará si se desea seguir jugando. Si se responde que sí el juego seguirá pidiendo un nuevo nivel y generando otro número.
         * Para salir abra que pulsar ESC.
         *Nota: Será necesario realizar los métodos y el paso de parámetros que consideres adecuado para una correcta programación.
         */
    class Ej09_AdivinarNumeroValorAleatoriaEntre1y50
    {
        static int NumeroAAdivinar()
        {
            Random aleat = new Random();
            int numero = aleat.Next(1, 51);

            return numero;
        }

        static bool JugarAAdivinar(int numeroAAdivinar, uint maximoDeIntentos)
        {
            int numeroIntroducido;
            uint intentos = 0;
            bool haAcertadoNumero = false;

            do
            {
                Console.Write("\n¿Qué número crees que és?: ");
                numeroIntroducido = int.Parse(Console.ReadLine());

                if (numeroIntroducido < numeroAAdivinar)
                {
                    Console.WriteLine("\nEl número es MAYOR que el numeroIntroducido");
                    Console.WriteLine("Te quedan " + (maximoDeIntentos - intentos) + " intentos");
                    intentos++;
                }
                else if (numeroIntroducido > numeroAAdivinar)
                {
                    Console.WriteLine("\nEl número es MENOR que el numeroIntroducido");
                    Console.WriteLine("Te quedan " + (maximoDeIntentos - intentos) + " intentos");
                    intentos++;
                }
                else
                {
                    haAcertadoNumero = true;
                    Console.WriteLine("\nHas usado {0} intentos\n", intentos);
                }

            } while (haAcertadoNumero == false && intentos <= maximoDeIntentos);

            if (intentos > maximoDeIntentos)
                haAcertadoNumero = false;

            return haAcertadoNumero;
        }

        static uint MaximoDeIntentosParaNivel(uint nivel)
        {
            uint maximoDeIntentos;

            switch (nivel)
            {
                case 1:
                    maximoDeIntentos = 10;
                    break;
                case 2:
                    maximoDeIntentos = 6;
                    break;
                case 3:
                    maximoDeIntentos = 4;
                    break;
                default:
                    Debug.Assert(false, "Nivel Incorrecto.");
                    maximoDeIntentos = 0;
                    break;
            }

            return maximoDeIntentos;
        }

        static uint PedirNivel()
        {
            uint nivel;

            do
            {
                Console.WriteLine("\nSelecciona nivel de dificultad");
                Console.WriteLine("\n1.FACIL\n2.MEDIO\n3.DIFICIL");
                Console.Write("\nSeleccion: ");
                nivel = uint.Parse(Console.ReadLine());

            } while (nivel < 1 || nivel > 3);

            return nivel;
        }

        public static void Main()
        {
            ConsoleKeyInfo continuar;

            do
            {
                int numeroAAdivinar = NumeroAAdivinar();
                uint maximoDeIntentos = MaximoDeIntentosParaNivel(PedirNivel());

                if (JugarAAdivinar(numeroAAdivinar, maximoDeIntentos) == true)
                    Console.WriteLine("\n\a\a¡ENHORABUENA! Has acertado el número\n");
                else
                {
                    Console.WriteLine("\a\nPIERDES. Has agotado todos tus intentos");
                    Console.WriteLine("El numero era el " + numeroAAdivinar + "\n");
                }

                do
                {
                    Console.Write("¿Deseas jugar de nuevo? (S/Esc): ");
                    continuar = Console.ReadKey();

                    if (continuar.Key != ConsoleKey.S && continuar.Key != ConsoleKey.Escape)
                        Console.WriteLine("\a\nOpción no reconocida\n");

                } while (continuar.Key != ConsoleKey.S && continuar.Key != ConsoleKey.Escape);

            } while (continuar.Key != ConsoleKey.Escape);
        }
    }

}