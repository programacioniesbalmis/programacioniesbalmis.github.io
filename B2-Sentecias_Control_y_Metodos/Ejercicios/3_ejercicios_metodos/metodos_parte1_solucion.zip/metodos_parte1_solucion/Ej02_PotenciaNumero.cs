﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ej02_PotenciaNumero
{
	 /* Diseña un método denominada Eleva, que calcule x elevado a n, dados ambos como parámetro. 
             * Una vez definida, integra dicho método en un programa que calcule e imprima el resultado 
             * de la siguiente expresión: (x4 + ym) / 2
             * siendo x, y y m tres números enteros introducidos por teclado.*/
    class Ej02_PotenciaNumero
    {
        static int Eleva(int numero, int potencia)
        {
            int resultado = 1;

            for (int i = 1; i <= potencia; i++)
                resultado = resultado * numero;

            return resultado;
        }

        static void Main()
        {
           

            Console.WriteLine("Ej01. Potencias. Resolver: ( x(4)+ y(m) ) / 2 \n\n");

            int x, y, m, resultado;

            Console.Write("Introduzca x: ");
            x = int.Parse(Console.ReadLine());

            Console.Write("Introduzca y: ");
            y = int.Parse(Console.ReadLine());

            Console.Write("Introduzca m: ");
            m = int.Parse(Console.ReadLine());

            resultado = (Eleva(x, 4) + Eleva(y, m)) / 2;

            Console.WriteLine("\n( x(4) + y(m) )/2 = " + resultado);
        }


    }
}