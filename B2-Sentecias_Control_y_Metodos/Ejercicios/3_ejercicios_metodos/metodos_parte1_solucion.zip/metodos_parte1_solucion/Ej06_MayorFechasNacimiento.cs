﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ej06_MayorFechasNacimiento
{
	 /* Ej06: Crea un método que cambie de formato una fecha: dados el día, mes y año
         * que devuelva un número entero (ej: 2 de abril de 1997 sería 19970402). 
         * Dada esta función, diseña un programa que solicite dos fechas de nacimiento 
         * y averigüe cual de las dos personas es mayor.*/
    class Ej06_MayorFechasNacimiento
    {
         static ulong FechaNumerica(uint dia, uint mes, uint año)
        {
            string cadenaAuxiliar = $"{año}{mes:D2}{dia:D2}";
            ulong fecha = ulong.Parse(cadenaAuxiliar);

            return fecha;
        }

        static void Main()
        {
            Console.Write("Introduzca nombre de la persona: ");
            string nombre1 = Console.ReadLine();
            Console.Write("uintroduzca dia: ");
            uint dia1 = uint.Parse(Console.ReadLine());
            Console.Write("uintroduzca mes: ");
            uint mes1 = uint.Parse(Console.ReadLine());
            Console.Write("uintroduzca año: ");
            uint año1 = uint.Parse(Console.ReadLine());

            Console.Write("\nuintroduzca nombre de la persona: ");
            string nombre2 = Console.ReadLine();
            Console.Write("uintroduzca dia: ");
            uint dia2 = uint.Parse(Console.ReadLine());
            Console.Write("uintroduzca mes: ");
            uint mes2 = uint.Parse(Console.ReadLine());
            Console.Write("uintroduzca año: ");
            uint año2 = uint.Parse(Console.ReadLine());

            ulong fechaNumerica1 = FechaNumerica(dia1, mes1, año1);
            ulong fechaNumerica2 = FechaNumerica(dia2, mes2, año2);
            string textoComparacion = (fechaNumerica1 > fechaNumerica2) ? "mayor" : "menor";

            Console.WriteLine($"fecha1 = {fechaNumerica1} y fecha2 = {fechaNumerica2}");
            Console.WriteLine($"La fecha de nacimiento de {nombre1} es {textoComparacion} que la de {nombre2}.");
        }
    }
}
