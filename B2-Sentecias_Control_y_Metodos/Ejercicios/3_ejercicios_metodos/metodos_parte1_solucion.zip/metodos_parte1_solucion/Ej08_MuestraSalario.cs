using System;
namespace Ej08_MuestraSalario
{
	/*
	* Escribe un método llamado Lee que que obtenga los siguientes datos de un usuario: 
	* número de departamento, coste por hora y horas trabajadas. Usarás tuplas para resolverlo
    * Escribe un método llamado Salario que para calcular el salario semanal multiplique el coste por hora por el número de horas trabajadas.
    * Escribe un método llamado Muestra que muestre el salario semanal, el número del departamento, 
	* el coste por hora y las horas trabajadas. Podéis fijaros en el siguiente DEM:
	*/
    class Ej08_MuestraSalario
    {
        static (short numeroDepartamento, short horasTrabajadas, float costeHora)  Lee()
        {
            short numeroDepartamento, horasTrabajadas;
            float costeHora;
            Console.WriteLine("Introduce el número del departamento del trabajador: ");
            numeroDepartamento=short.Parse(Console.ReadLine());
            Console.WriteLine("Introduce las horas trabjadas: ");
            horasTrabajadas=short.Parse(Console.ReadLine());
            Console.WriteLine("Introduce el coste hora: ");
            costeHora=float.Parse(Console.ReadLine());
            return (numeroDepartamento,horasTrabajadas,costeHora);
        }

        static float Salario(short horasTrabajadas, float costeHora)
        {
           return horasTrabajadas*costeHora;
        }

        static void Muestra(short numeroDepartamento,
                            short horasTrabajadas,
                            float costeHora,
                            float salario)  
        {
            Console.WriteLine(
                    $"El el empleado de {numeroDepartamento} "+ 
                    $"ha trabajado {horasTrabajadas} horas a un coste"+
                    $"por hora de {costeHora} euros por lo que su salario total es: {salario} euros");
        }

        static void Main()
        {
            (short numeroDepartamento, short horasTrabajadas, float costeHora) = Lee();
            Muestra(numeroDepartamento, 
                    horasTrabajadas, 
                    costeHora,
                    Salario(horasTrabajadas, costeHora));
        }
    }
    
}