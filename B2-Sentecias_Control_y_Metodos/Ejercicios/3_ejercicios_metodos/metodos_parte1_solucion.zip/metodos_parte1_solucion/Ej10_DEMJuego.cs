
using System;

namespace Ej10_JuegoDEM
{
   
		/*
		Programa que implementará un juego con las siguientes características:
		El programa pedirá que introduzcas el número de participantes a jugar.
		Cada participante tirará 3 veces un dado con valores entre 1 y 100 (electrónico se entiende), 
		sumándose el valor de las 3 jugadas. Ganará el participante que
		obtenga mayor puntuación según las siguientes reglas:
		◦ Si el nº obtenido es múltiplo de 3 o de 5 sumara 10 pts.
		◦ Si el nº obtenido es múltiplo de 4 o de 6 sumara 5 pts.
		◦ Si el nº obtenido es mayor de 80 sumara 2 pts.
		◦ Si el nº obtenido es mayor de 50 sumar 1 pts.
		◦ Si el nº obtenido es menor de 50 restará 2 pts.
		◦ Si el nº obtenido es menor de 20 restará 1 pts.
		El DEM para el juego será más o menos el siguiente.
		*/
        #region Ejercicio1
        class  Ej10_JuegoDEM
        { 

            static int TiradaDadoDe1a100(Random seed)
            {
                return seed.Next(1, 101);
            }

            static int CalculaPuntos(int tirada)
            {
                int puntos = 0;

                if (tirada % 3 == 0 || tirada % 5 == 0)
                    puntos += 10;
                if (tirada % 4 == 0 || tirada % 6 == 0)
                    puntos += 5;
                if (tirada > 50)
                    puntos++;
                if (tirada > 80)
                    puntos += 2;
                if (tirada < 50)
                    puntos -= 2;
                if (tirada < 20)
                    puntos--;

                return puntos;
            }

            static int JuegoParticipante(int jugador, Random seed)
            {
                int puntuacion = 0;

                Console.WriteLine($"Soy el jugador {jugador} y mis jugadas son...");
                for (int i = 0; i < 3; i++)
                {
                    int tirada = TiradaDadoDe1a100(seed);
                    puntuacion += CalculaPuntos(tirada);
                    Console.WriteLine($"\tTirada: {tirada} y Puntos: {puntuacion}");
                }

                return puntuacion;
            }

            static int PideNumeroParticipantes()
            {
                Console.Write("Participantes?: ");
                return int.Parse(Console.ReadLine());
            }

            static void PresentaJuego()
            {
                Console.WriteLine("Cada participante tirará 3 veces un dado con valores entre 1 y 100(electrónico se");
                Console.WriteLine("entiende), sumándose el valor de las 3 jugadas.Ganará el participante que");
                Console.WriteLine("obtenga mayor puntuación según las siguientes reglas:");
                Console.WriteLine("◦ Si el nº obtenido es múltiplo de 3 o de 5 sumara 10 pts.");
                Console.WriteLine("◦ Si el nº obtenido es múltiplo de 4 o de 6 sumara 5 pts.");
                Console.WriteLine("◦ Si el nº obtenido es mayor de 80 sumara 2 pts.");
                Console.WriteLine("◦ Si el nº obtenido es mayor de 50 sumar 1 pts.");
                Console.WriteLine("◦ Si el nº obtenido es menor de 50 restará 2 pts.");
                Console.WriteLine("◦ Si el nº obtenido es menor de 20 restará 1 pts.");
            }

            static void MejorPuntuacionHastaHora(
                            int puntuacionJugadorActual,
                            int jugadorActual,
                            ref int mejorPuntuacion,
                            ref int mejorJugador)
            {
                if (puntuacionJugadorActual > mejorPuntuacion)
                {
                    mejorPuntuacion = puntuacionJugadorActual;
                    mejorJugador = jugadorActual;
                }
            }

            static void Main()
            {
                int mejorPuntuacion = int.MinValue;
                int mejorJugador = 1;
                PresentaJuego();
                int jugadores = PideNumeroParticipantes();

                Random seed = new Random();
                for (int jugador = 1; jugador <= jugadores; jugador++)
                {
                    int puntuacion = JuegoParticipante(jugador, seed);

                    MejorPuntuacionHastaHora(
                                    puntuacion,
                                    jugador,
                                    ref mejorPuntuacion,
                                    ref mejorJugador);
                }

                Console.WriteLine($"Ha ganado el jugador {mejorJugador} con {mejorPuntuacion} puntos.");
            }
        }
        #endregion
}
