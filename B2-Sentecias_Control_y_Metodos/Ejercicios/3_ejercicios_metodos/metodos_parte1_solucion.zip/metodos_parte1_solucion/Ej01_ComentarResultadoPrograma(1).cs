﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ej01_ComentarResultadoPrograma_1_
{
    class Program
    {
        static void Eleva(int a)
    {
        a = a * a;
    }
    static void Main()
    {
        for (int a = 0; a < 10; a = a + 2)
        {
            Eleva(a);
            Console.WriteLine(a);
        }
    }
    }
}
