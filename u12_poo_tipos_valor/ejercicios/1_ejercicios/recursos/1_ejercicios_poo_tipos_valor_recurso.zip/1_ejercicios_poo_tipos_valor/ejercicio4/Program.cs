﻿public class Program
{
    //TODO: Implementa el método necesario para resolver la lógica del ejercicio

    private static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio 4: Sistema de identificadores únicos con GUID\n");

        UsoGuid();
        Console.WriteLine("\nPulsa una tecla para acabar...");
        Console.ReadKey();
    }
}