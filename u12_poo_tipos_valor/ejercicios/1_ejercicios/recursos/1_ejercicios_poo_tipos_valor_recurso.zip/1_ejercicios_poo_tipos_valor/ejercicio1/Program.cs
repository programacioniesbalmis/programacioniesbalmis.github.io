﻿using System;
using System.Text;

public class Program
{
    //TODO: Implementa la lógica necesaria para solucionar el ejercicio


    public static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio 1: Comparación entre tipos valor y tipos referencia\n");

        DemuestraTipoValor();
        Console.WriteLine();
        DemuestraTipoReferencia();
        Console.WriteLine();
        Console.WriteLine("\n--- Tipos valor como parámetros ---");
        DateTime fechaTipoValor = new DateTime(2025, 1, 1, 12, 0, 0);
        Console.WriteLine($"DateTime antes de llamar a método: {fechaTipoValor}");
        ModificaTipoValor(fechaTipoValor);
        Console.WriteLine($"DateTime después de llamar a método: {fechaTipoValor}");
        Console.WriteLine("(El método no puede modificar el original)");

        Console.WriteLine("\n--- Tipos referencia como parámetros ---");
        StringBuilder textoTipoReferencia = new StringBuilder("Inicial");
        Console.WriteLine($"StringBuilder antes de llamar a método: \"{textoTipoReferencia}\"");
        ModificaTipoReferencia(textoTipoReferencia);
        Console.WriteLine($"StringBuilder después de llamar a método: \"{textoTipoReferencia}\"");
        Console.WriteLine("(El método SÍ puede modificar el original)");

        Console.WriteLine("\nPulsa una tecla para acabar...");
        Console.ReadKey();
    }
}
