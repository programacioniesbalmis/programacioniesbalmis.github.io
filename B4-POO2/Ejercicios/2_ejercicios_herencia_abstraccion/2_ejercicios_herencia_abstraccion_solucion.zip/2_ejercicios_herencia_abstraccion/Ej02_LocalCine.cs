﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ej02_LocalCine
{
    /* 7. Se nos pide implementar usando POO y herencia las siguientes entidades:
     * 
     * La entidad Local:
     * - Con los atributos ciudad, calle, numero plantas y dimensiones.
     * - Con la operación GetNumeroPlantas para poder acceder al atributo numeroPlantas.
     * - Con la operación Mostrar que visualizará por la consola los datos de un local. 
     *
     * La entidad LocalComercial que heredará de Local:
     * - Con los atributos razon social y numero licencia.
     * - Con la operación Mostrar que visualizará por la consola los datos de un local comercial. 
     * 
     * La entidad Cine que heredará de LocalComercial:
     * - Con el atributo aforo sala.
     * - Con la operación Mostrar que visualizará por la consola los datos de un cine. 
     * 
     * Deberemos crear un programa principal ejemplo que cree un array de 3 cines, lo inicialice y me lo muestre por pantalla con un foreach.
     * */

    class Local
    {
        public struct Dimensiones
        {
            public ushort Alto;
            public ushort Ancho;
            public ushort Profundidad;
        }

        private string Ciudad;
        private string Calle;
        private ushort NumeroPlantas;
        private Dimensiones Especificaciones;

        public Local()
        {
            this.Ciudad = "";
            this.Calle = "";
            this.NumeroPlantas = 0;
            this.Especificaciones.Alto = 0;
            this.Especificaciones.Ancho = 0;
            this.Especificaciones.Profundidad = 0;
        }

        public Local(string ciudad, string calle, ushort numeroPlantas, ushort alto, ushort ancho, ushort profundidad)
        {
            this.Ciudad = ciudad;
            this.Calle = calle;
            this.NumeroPlantas = numeroPlantas;
            this.Especificaciones.Alto = alto;
            this.Especificaciones.Ancho = ancho;
            this.Especificaciones.Profundidad = profundidad;
        }

        public string GetCiudad()
        {
            return this.Ciudad;
        }

        public void SetCiudad(string ciudad)
        {
            this.Ciudad=ciudad;
        }

        public string GetCalle()
        {
            return this.Calle;
        }

        public void SetCalle(string calle)
        {
            this.Calle = calle;
        }

        public ushort GetNumeroPlantas()
        {
            return this.NumeroPlantas;
        }

        public void SetNumeroPlantas(ushort numeroPlantas)
        {
            this.NumeroPlantas = numeroPlantas;
        }

        public ushort GetAlto()
        {
            return this.Especificaciones.Alto;
        }

        public void SetAlto(ushort alto)
        {
            this.Especificaciones.Alto=alto;
        }

        public ushort GetAncho()
        {
            return this.Especificaciones.Ancho;
        }

        public void SetAncho(ushort ancho)
        {
            this.Especificaciones.Ancho = ancho;
        }

        public ushort GetProfundidad()
        {
            return this.Especificaciones.Profundidad;
        }

        public void SetProfundidad(ushort profundidad)
        {
            this.Especificaciones.Profundidad = profundidad;
        }

      public virtual string ACadena()
        {
           string mensaje="\nCiudad: " + this.GetCiudad()+
             "\nCalle: " + this.GetCalle()+
             "\nNumero de plantas:" + this.GetNumeroPlantas()+
             "\nAlto: " + this.GetAlto()+
             "\nAncho: " + this.GetAncho()+
             "\nProfundidad: " + this.GetProfundidad();
             return mensaje;
        }
    }

    class LocalComercial : Local
    {
        private string RazonSocial;
        private string NumeroLicencia;

        public LocalComercial()
        {
            this.RazonSocial = "";
            this.NumeroLicencia = "";
        }

        public LocalComercial(string ciudad, string calle, ushort numeroPlantas, ushort alto, ushort ancho, ushort profundidad, string razonSocial, string numeroLicencia)
            :base(ciudad,calle,numeroPlantas,alto,ancho,profundidad)
        {
            this.RazonSocial = razonSocial;
            this.NumeroLicencia = numeroLicencia;
        }

        

        public string GetRazonSocial()
        {
            return this.RazonSocial;
        }

        public void SetRazonSocial(string razonSocial)
        {
            this.RazonSocial = razonSocial;
        }

        public string GetNumeroLicencia()
        {
            return this.NumeroLicencia;
        }

        public void SetNumeroLicencia(string numeroLicencia)
        {
            this.NumeroLicencia = numeroLicencia;
        }
        public override string ACadena()
        {
           string mensaje=base.ACadena()+
            "\nRazón Social: " + this.RazonSocial+
             "\nNúmero de Licencia: " + this.NumeroLicencia;
             return mensaje;
        }

    }

    class Cine : LocalComercial
    {
        private ushort AforoSala;

        public Cine()
        {
            this.AforoSala=0;
        }

        public Cine(string ciudad, string calle, ushort numeroPlantas, ushort alto, ushort ancho, ushort profundidad, string razonSocial, string numeroLicencia, ushort aforoSala)
            :base(ciudad,calle,numeroPlantas,alto,ancho,profundidad,razonSocial,numeroLicencia)
        {
            this.AforoSala = aforoSala;
        }

        public override string ACadena()
        {
           string mensaje=base.ACadena()+
            "\nAforo: " + this.AforoSala;
             return mensaje;
        }

        public ushort SetAforoSala()
        {
            return this.AforoSala;
        }

        public void SetAforoSala(ushort aforoSala)
        {
            this.AforoSala = aforoSala;
        }
    }

    class Ej09_LocalCine
    {
        static void ImprimirArray(Cine[] cine)
        {
            foreach (var x in cine)
            {
                Console.WriteLine(x.ACadena());
            }
        }

        /*
        static void IniciarArrayCine( Cine[] cines, int posicion, string ciudad, string calle, ushort numeroPlantas, ushort alto, ushort ancho, ushort profundidad, string razonSocial, string numeroLicencia, ushort aforoSala)
        {
            cines[posicion].SetCiudad(ciudad);
            cines[posicion].SetCiudad(calle);
            cines[posicion].SetNumeroPlantas(numeroPlantas);
            cines[posicion].SetAlto(alto);
            cines[posicion].SetAncho(ancho);
            cines[posicion].SetProfundidad(profundidad);
            cines[posicion].SetRazonSocial(razonSocial);
            cines[posicion].SetNumeroLicencia(numeroLicencia);
            cines[posicion].SetAforoSala(aforoSala);
        }
         */

        static void Main(string[] args)
        {
            Cine[] cines = new Cine[3];

            cines[0] = new Cine("Alicante", "Poeta Miguel Hernández, 18", 3, 10, 20, 30, "Maqueabélico", "12345678X", 1000);
            cines[1] = new Cine("Barcelona", "El espanyol lider, 10", 5, 30, 50, 130, "Cines Agarraos", "87654321X", 5000);
            cines[2] = new Cine("Valencia", "La mare que em va parir, 64", 2, 40, 45, 24, "Un dos tres", "55789648L", 1000);

            /*IniciarArrayCine( cines, 0, "Alicante", "Poeta Miguel Hernández, 18", 3, 10, 20, 30, "Maqueabélico", "12345678X", 1000);
            IniciarArrayCine(cines, 1, "Barcelona", "El espanyol lider, 10", 5, 30, 50, 130, "Cines Agarraos", "87654321X", 5000);
            IniciarArrayCine( cines, 2, "Valencia", "La mare que em va parir, 64", 2, 40, 45, 24, "Un dos tres", "55789648L", 1000);*/

            ImprimirArray(cines);
        }
    }
}
