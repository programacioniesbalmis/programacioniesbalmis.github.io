﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ej03_ElCalculador
{
    /* Para dar nuestros primeros pasos con el polimorfismo de datos del principio
     * de sustitución de Liskov, vamos a recordar el cálculo de factorial y de número primo.
     * Vamos a necesitar una clase padre ElNoCalculador con un atributo protected short numero, 
     * que será la base del calculo posterior, también tendrá dos métodos virtuales Factorial y Primo
     * devolverán un double y un booleano respectivamente (en esta clase no se realizarán los cálculos, 
     * los métodos devolverán 0 y false).
     * Además, crearemos una clase hija ElCalculador que sí implementa estos métodos de forma correcta a partir del numero del padre.
     * Para probar el funcionamiento del polimorfismo nos crearemos un objeto de la manera: ElNoCalculador obj=new ElCalculador(num);
     * Y llamaremos a los métodos Primo y Factorial. Reflexiona las siguiente preguntas:
     * ¿A qué métodos se llama, a los de la clase padre o a los de la clase hija? Crea en la clase hija un método MostrarResultado y 
     * llámalo con el obj. ¿Qué ocurre? Y si comentas el método Primo de la hija, ¿que ocurre? */


    class ElNoCalculador
    {
        protected int valor;

        public ElNoCalculador(int num)
        {
            this.valor = num;
        }

        public virtual double Factorial()
        {
            return 0;
        }

        public virtual bool Primo()
        {
            return false;
        }
    }

    class ElCalculador : ElNoCalculador
    {
        public ElCalculador(int num):base(num) { }

        public override double Factorial()
        {
            int factorial = 1;

                for (int i = valor; i > 0; i--)
                {
                    factorial = factorial * i;
                }
            return factorial;
        }

        public override bool Primo()
        {
            int contador = 2;
            bool primo = true;

            while (primo && (contador != valor))
            {
                if (valor % contador == 0)
                    primo = false;
                contador++;
            }

            if (primo) return true;
            else return false;
        }

        public void MostrarResultado()
        {
            Console.WriteLine(Factorial());
            Console.WriteLine(Primo());
        }
    }

    class Ej010_ElCalculador
    {
        static void Main(string[] args)
        {
            Console.Write("Introduzca valor: ");
            int num = int.Parse(Console.ReadLine());
            ElNoCalculador obj = new ElCalculador(num);
            Console.WriteLine(obj.Primo());
            Console.WriteLine(obj.Factorial());
            //obj.MostrarResultado(num);
        }
    }
}
