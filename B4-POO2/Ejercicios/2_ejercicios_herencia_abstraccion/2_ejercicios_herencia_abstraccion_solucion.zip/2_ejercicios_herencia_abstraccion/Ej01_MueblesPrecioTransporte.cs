﻿using System;

namespace Ej01_MueblespTransporte
{
    /* Crea las clases silla, mesa y sofá hijas de la clase mueble del ejercicio 4. 
     * A cada una de ellas le deberás de añadir los campos y métodos necesarios que 
     * identifiquen a dichos elementos según el texto de dicho ejercicio.
     * Crea un método común para todos los muebles que nos permita calcular el precio 
     * del transporte según su peso, dimensiones y fabricante (puedes usar la fórmula que 
     * consideres para hacer este cálculo).
     * Finalmente, haz un programa principal que nos cree instancias de los tres tipos de
     * muebles, que llame a los métodos de las clases para mostrar la información y que 
     * llame al método para calcular el precio del transporte y lo muestre.
     * Nota: Debes pensar en que clase o clases vas a incluir el método de calcular precio, 
     * para seguir las normas que se explican en el tema. */

    class Mueble
{
    
        public enum Color
        {
            Blanco, Azul, Verde, Rojo, Rosa, Marron
        }

        public struct Dimensiones
        {
            public int Ancho;
            public int Alto;
            public int Profundidad;
        }

        private int peso;
        private string fabricante;
        private float precio;
        private Dimensiones dimensiones;
        private Color colores;

        public Mueble()
        {
            this.fabricante = "";
            this.peso = 0;
            this.precio=0;
            this.dimensiones.Alto = 0;
            this.dimensiones.Ancho = 0;
            this.dimensiones.Profundidad = 0;
            this.colores = 0;
        }

        public Mueble(string fabricante, int peso, int precio, int alto, int ancho, int profundidad, Color colores)
        {
            this.fabricante= fabricante;
            this.peso = peso;
            this.precio=precio;
            this.dimensiones.Alto = alto;
            this.dimensiones.Ancho = ancho;
            this.dimensiones.Profundidad = profundidad;
            this.colores = colores;
        }

 public Mueble(Mueble m)
        {
            this.fabricante= m.fabricante;
            this.peso = m.peso;
            this.precio=m.precio;
            this.dimensiones.Alto = m.dimensiones.Alto;
            this.dimensiones.Ancho = m.dimensiones.Ancho;
            this.dimensiones.Profundidad = m.dimensiones.Profundidad;
            this.colores = m.colores;
        }
        public static Object LeeEnum(Type tipo, string texto, string textoError)
        {
            string[] categorias = Enum.GetNames(tipo);

            do
            {
                try
                {
                    Console.Write(texto);
                    return Enum.Parse(tipo, Console.ReadLine());
                }
                catch (Exception)
                {
                    Console.WriteLine(textoError);
                    Console.WriteLine("\nCategorias válidas: ");
                    for (int i = 0; i < categorias.Length; i++)
                    {
                        Console.WriteLine(categorias[i]);
                    }
                    Console.Write("\nIntroduzca categoria valida: ");
                }
            } while (true);
        }

        public void Setf(string fabricante)
        {
            this.fabricante = fabricante;
        }

        public string GetFabricante()
        {
            return this.fabricante;
        }

        public void SetPeso(int peso)
        {
            this.peso = peso;
        }

        public int GetPeso()
        {
            return this.peso;
        }

        public void SetPrecio(int precio)
        {
            this.precio = precio;
        }

        public float GetPrecio()
        {
            return this.precio;
        }

        public void SetAlto(int alto)
        {
            this.dimensiones.Alto = alto;
        }

        public int GetAlto()
        {
            return this.dimensiones.Alto;
        }

        public void SetAncho(int ancho)
        {
            this.dimensiones.Ancho = ancho;
        }

        public int GetAncho()
        {
            return this.dimensiones.Ancho;
        }

        public void SetProfundidad(int profundidad)
        {
            this.dimensiones.Profundidad = profundidad;
        }

        public int GetProfundidad()
        {
            return this.dimensiones.Alto;
        }

        public void SetColor(Color colores)
        {
            this.colores = colores;
        }

        public Color GetColor()
        {
            return this.colores;
        }

        public virtual string ACadena()
        {
           string mensaje= "Fabricante: "+this.fabricante+
            "\nPeso: " + this.peso+
            "\nPrecio: " + this.precio+
            "\nAlto: " + this.dimensiones.Alto+
            "\nAncho: " + this.dimensiones.Ancho+
            "\nProfundidad: " + this.dimensiones.Profundidad+
            "\nColor: " + this.colores;
            return mensaje;
        }
        public float PrecioTransporte()
        {
           float precioTransporteFabricante=GetFabricante()=="IKEA"?2:GetFabricante()=="Mesux"?3:0;
           return (GetPeso()/10+(GetAncho()+GetProfundidad()+GetAlto())/100)+precioTransporteFabricante;
        }
    }

    class Silla : Mueble
    {
        private float longitudRespaldo;
        
        public Silla()
        {
            this.longitudRespaldo=0;
        }


        public Silla(Silla s):base(s)
        {
         this.longitudRespaldo=s.longitudRespaldo;
        }
        public Silla(string f, int peso, int p, int alto, int ancho, int profundidad, Color colores, float longitudRespaldo)
                   :base(f,peso,p,alto,ancho,profundidad,colores)
        {
            this.longitudRespaldo=longitudRespaldo;
        }

        public float GetLongitudRespaldo()
        {
            return this.longitudRespaldo;
        }

        public override string ACadena()
        {
           string mensaje ="\nLongitud Respaldo: " + this.longitudRespaldo;
            return base.ACadena()+ mensaje;
        }
       
    }

    class Mesa : Mueble
    {
        private string material;        

        public Mesa()
        {
            this.material = "";
        }
        public Mesa(Mesa m):base(m)
        {
           this.material=m.material;
        }

        public Mesa(string fabricante, int peso, int precio, int alto, int ancho, int profundidad, Color colores,  string material)
            : base(fabricante, peso, precio, alto, ancho, profundidad, colores)
        {
            this.material = material;
        }

        public override string ACadena()
        {
           string mensaje = "\nMaterial: " + this.material;
            return mensaje+base.ACadena();
        }
    }

    class Sofa : Mueble
    {
        private bool abatible;
        private string tela;

        public Sofa()
        {
            this.tela = "";
            this.abatible = false;
        }

        public Sofa(string f, int peso, int p, int alto, int ancho, int profundidad, Color colores, int puertas, string tela, bool abatible)
            : base(f, peso, p, alto, ancho, profundidad, colores)
        {
            this.tela= tela;
            this.abatible=abatible;
        }

        public override string ACadena()
        {
           string mensaje = "\nTela: " + this.tela+ (abatible?" Abatible":"No Abatible");
           return mensaje+base.ACadena();
        }
    }

  
    class Ej08_MueblespTransporte
    {
        static void Main(string[] args)
        {
            Mueble mueble1 = new Mueble("IKEA", 12, 58, 210, 250, 140, (Mueble.Color)Mueble.LeeEnum(typeof(Mueble.Color), "Introduzca color: ", "\aColor no válido"));
            Console.WriteLine(mueble1.ACadena());
            Console.WriteLine("El precio del transporte es: "+ mueble1.PrecioTransporte());

            Mesa mesa1 = new Mesa("Mesux", 45, 59, 210, 400, 215, (Mueble.Color)Mueble.LeeEnum(typeof(Mueble.Color), "Introduzca color: ", "\aColor no válido"),  "Madera");
            Console.WriteLine(mesa1.ACadena());
            Console.WriteLine("El precio del transporte es: "+ mesa1.PrecioTransporte());

            Console.WriteLine(new Mesa(mesa1).ACadena());
        }
    }
}
