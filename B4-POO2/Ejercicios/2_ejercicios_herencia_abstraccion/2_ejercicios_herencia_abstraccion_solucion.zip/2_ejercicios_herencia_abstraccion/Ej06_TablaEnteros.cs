﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ej06_TablaEnteros
{

    /* Crear una clase llamada TablaEnteros que no permita que se creen objetos a partir de ella.
     * Esta clase almacenará una tabla de enteros de una dimensión, el tamaño debe ser especificado mediante su constructor.
     * La clase debe obligar a que cualquier clase que herede de ella y no quiera ser una clase abstracta, 
     * implemente un método llamado GuardarNumerosenTabla. Además, TablaEnteros dispondrá de dos método:
     * MostrarTabla, método redefinible, que servirá para mostrar la tabla completa por pantalla.
     * SumaPropia que se encargará de comprobar si existen más números positivos o negativos en la tabla y
     * devolverá la suma de aquellos de los que hay mayor cantidad. Crear a partir de esta clase dos nuevas clases llamadas:
     * TablaImpares: que solo guardará números impares.
     * TablaPares: que solo guardará números pares.
     * Ambas, lo harán mediante el método GuardarNumerosEnTabla antes mencionado que seleccionará
     * los números apropiados (pares o impares) a guardar, de una lista introducida por el usuario.
     * En el programa principal, crea instancias de cada una de estas clases, dales valores y muestra 
     * las tablas y la suma propia de ambos objetos por pantalla. */

    abstract class TablaEnteros
    {
        protected int[] Tabla;
      
        public TablaEnteros() { }

        public TablaEnteros(int tamaño)
        {
            Tabla = new int[tamaño];
        }

        public virtual void MostrarTabla()
        {
            for (int i = 0; i < Tabla.Length; i++)
            {
                Console.Write(Tabla[i]+" ");
            }
        }

        public int SumaPropia()
        {
            int positivos = 0;
            int negativos = 0;
            int sumaPositivos = 0;
            int sumaNegativos = 0;

            for (int i = 0; i < Tabla.Length; i++)
            {
                if (Tabla[i] < 0)
                {
                    negativos++;
                    sumaNegativos += Tabla[i];
                }
                else if (Tabla[i] > 0)
                {
                    positivos++;
                    sumaPositivos += Tabla[i];
                }                
            }

            if(positivos > negativos) return  sumaPositivos;
            else return sumaNegativos;
                
        }

        public abstract void GuardarNumerosEnTabla();
    }

    class TablaImpares : TablaEnteros
    {
        public TablaImpares(int tamaño):base(tamaño){ }

        public override void GuardarNumerosEnTabla()
        {
           int numero;
            for (int i = 0; i < Tabla.Length; )
            {
                Console.Write("\nIntroduzca valor: ");
                numero=int.Parse(Console.ReadLine());
                if(numero%2!=0)
                {
                    Tabla[i] = numero;
                    i++;
                }
            }
        }
    }

    class TablaPares : TablaEnteros
    {
        public TablaPares(int tamaño):base(tamaño) { }

        public override void GuardarNumerosEnTabla()
        {
            int numero;
            for (int i = 0; i < Tabla.Length; )
            {
                Console.Write("\nIntroduzca valor: ");
                numero=int.Parse(Console.ReadLine());
                if(numero%2==0)
                {
                    Tabla[i] = numero;
                    i++;
                }
            }
        }
    }

    class Ej13_TablaEnteros
    {
        static void Main(string[] args)
        {
            TablaEnteros impares = new TablaImpares(5);
            impares.GuardarNumerosEnTabla();
            Console.WriteLine("La tabla de Impares es: ");
            impares.MostrarTabla();
            Console.WriteLine("La suma propia de los números es {0}", impares.SumaPropia());

            TablaEnteros pares = new TablaPares(5);
            pares.GuardarNumerosEnTabla();
             Console.WriteLine("La tabla de Pares es: ");
            pares.MostrarTabla();
            Console.WriteLine("La suma propia de los números es {0}", pares.SumaPropia());
               
        }
    }
}
