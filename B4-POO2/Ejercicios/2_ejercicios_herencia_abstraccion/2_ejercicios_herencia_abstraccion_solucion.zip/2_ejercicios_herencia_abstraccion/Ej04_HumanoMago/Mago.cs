﻿using System;


namespace Ejercicio04
{
    class Mago : Humano
    {
        public enum LibroHechizos {Viento, Hielo, Fuego};
        public enum Tunica {Lino, Algodon, Seda};

        private LibroHechizos tipoLibroHechizos;
        private Tunica tipoTunica;

        private void SetLibroHechizos(LibroHechizos LibroHechizos)
        {
            tipoLibroHechizos = LibroHechizos;
        }

        public LibroHechizos GetLibroHechizos()
        {
            return tipoLibroHechizos;
        }

        private void SetTunica(Tunica Tunica)
        {
            tipoTunica = Tunica;
        }

        public Tunica GetTunica()
        {
            return tipoTunica;
        }

        public Mago(LibroHechizos tipoLibroHechizos, Tunica tipoTunica, string nombre, int edad, int peso, string sexo, int inteligencia, int fuerza, int destreza, int energia) : base(nombre, edad, peso, sexo, inteligencia, fuerza, destreza, energia)
        {
            SetLibroHechizos(tipoLibroHechizos);
            SetTunica(tipoTunica);
        }

        public override string ACadena()
        {
            return $"LibroHechizos: {GetLibroHechizos()}\n" + 
                   $"Tunica: {GetTunica()}\n" + 
                   base.ACadena();
        }
    }
}
