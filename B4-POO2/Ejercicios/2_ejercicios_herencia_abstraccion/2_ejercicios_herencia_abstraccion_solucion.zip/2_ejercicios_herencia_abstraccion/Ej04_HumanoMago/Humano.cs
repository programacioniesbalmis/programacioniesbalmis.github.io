﻿using System;

namespace Ejercicio04
{
    public class Humano
    {
        private string nombre;
        private int edad;
        private int peso;
        private string sexo;
        private int inteligencia;
        private int fuerza;
        private int destreza;
        private int energia;

        public string GetNombre()
        {
            return nombre;
        }

        public void SetNombre(string nombre)
        {
            this.nombre = nombre;
        }

        public int GetEdad()
        {
            return edad;
        }

        public void SetEdad(int edad)
        {
            this.edad = edad;
        }

        public int GetPeso()
        {
            return peso;
        }

        public void SetPeso(int peso)
        {
            this.peso = peso;
        }

        public string GetSexo()
        {
            return sexo;
        }

        public void SetSexo(string sexo)
        {
            this.sexo = sexo;
        }

        public int GetInteligencia()
        {
            return inteligencia;
        }

        public void SetInteligencia(int inteligencia)
        {
            this.inteligencia = inteligencia;
        }

        public int GetFuerza()
        {
            return fuerza;
        }

        public void SetFuerza(int fuerza)
        {
            this.fuerza = fuerza;
        }

        public int GetDestreza()
        {
            return destreza;
        }

        public void SetDestreza(int destreza)
        {
            this.destreza = destreza;
        }

        public int GetEnergia()
        {
            return energia;
        }

        public void SetEnergia(int energia)
        {
            this.energia = energia;
        }

        public Humano(string nombre, int edad, int peso, string sexo, int inteligencia, int fuerza, int destreza, int energia)
        {
            SetNombre(nombre);
            SetEdad(edad);
            SetPeso(peso);
            SetSexo(sexo);
            SetInteligencia(inteligencia);
            SetFuerza(fuerza);
            SetDestreza(destreza);
            SetEnergia(energia);
        }

        public virtual string ACadena()
        {
            return $"Nombre: {GetNombre()}\n" +
                              $"Edad: {GetEdad()}\n" +
                              $"Peso: {GetPeso()}\n" +
                              $"Sexo: {GetSexo()}\n" +
                              $"Inteligencia: {GetInteligencia()}\n" +
                              $"Fuerza: {GetFuerza()}\n" +
                              $"Destreza: {GetDestreza()}\n" +
                              $"Energia: {GetEnergia()}";
        }
    }
}
