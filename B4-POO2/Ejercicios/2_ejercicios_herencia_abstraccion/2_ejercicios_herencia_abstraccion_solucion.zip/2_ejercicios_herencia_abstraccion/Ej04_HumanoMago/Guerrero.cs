﻿using System;


namespace Ejercicio04
{
    class Guerrero : Humano
    {
        public enum Arma {Hacha, Mazo, Espada};
        public enum Armadura {Malla, Hierro, Acero};

        private Arma tipoArma;
        private Armadura tipoArmadura;

        private void SetArma(Arma arma)
        {
            tipoArma = arma;
        }

        public Arma GetArma()
        {
            return tipoArma;
        }

        private void SetArmadura(Armadura armadura)
        {
            tipoArmadura = armadura;
        }

        public Armadura GetArmadura()
        {
            return tipoArmadura;
        }

        public Guerrero(Arma tipoArma, Armadura tipoArmadura, string nombre, int edad, int peso, string sexo, int inteligencia, int fuerza, int destreza, int energia) : base(nombre, edad, peso, sexo, inteligencia, fuerza, destreza, energia)
        {
            SetArma(tipoArma);
            SetArmadura(tipoArmadura);
        }

        public override string ACadena()
        {
            return $"Arma: {GetArma()}\n" + 
                   $"Armadura: {GetArmadura()}\n" + 
                   base.ACadena();
        }
    }
}
