﻿using System;

namespace Ej05_Legisladores
{
	/*Declara una clase abstracta Legislador que herede de la clase Persona, 
	 * que usamos en ejercicios anteriores, con un campo povinciaQueRepresenta 
	 * tipo String, y si quieres otros atributos que creas necesarios.
     * Declara un método abstracto GetCamaraEnQueTrabaja.
     * Crea las siguientes clases que heredarán e Legislador e implementarán su método abstracto:
                 * Diputado.
                 * Senador.
     * Crea un array de tres legisladores de distintos tipos usan polimorfismo de datos y muestra
     * por pantalla la cámara en que trabajan y otros datos que creas necesarios.
	*/
    class Persona
    {
        private string nombre;
        private ushort edad;
        private string nif;

        public Persona(string nombre, ushort edad, string nif)
        {
            this.nombre = nombre;
            this.edad = edad;
            this.nif = nif;
        }

        public virtual string GetDatos()
        {
            return
            $"Nombre = {nombre}\n" +
            $"Edad = {edad}\n" +
            $"NIF = {nif}";
        }
    }

    abstract class Legislador : Persona
    {
        private string provinciaQueRepresenta;

        public Legislador(string nombre, ushort edad, string nif, string provinciaQueRepresenta) : base(nombre, edad, nif)
        {
            this.provinciaQueRepresenta = provinciaQueRepresenta;
        }

        public abstract string GetCamaraEnQueTrabaja();

        public override string GetDatos()
        {
            string texto = base.GetDatos();
            texto +=
            $"\nProvincia = {provinciaQueRepresenta}\n" +
            $"Camara = {GetCamaraEnQueTrabaja()}\n";

            return texto;
        }
    }

    class Diputado : Legislador
    {
        public Diputado(string nombre, ushort edad, string nif, string provinciaQueRepresenta) : base(nombre, edad, nif, provinciaQueRepresenta)
        {
            ;
        }

        public override string GetCamaraEnQueTrabaja()
        {
            return "Congreso de los diputados";
        }
    }

    class Senador : Legislador
    {
        public Senador(string nombre, ushort edad, string nif, string provinciaQueRepresenta) : base(nombre, edad, nif, provinciaQueRepresenta)
        {
            ;
        }

        public override string GetCamaraEnQueTrabaja()
        {
            return "Senado";
        }
    }

    class  Ej12_Legisladores
    {
        static void Main()
        {
            Legislador[] legisladores =
            {
                new Diputado("Juanjo", 47, "22567876W", "Alicante"),
                new Senador("Xusa", 44, "22543276M", "Alicante")
            };

            foreach (Legislador legislador in legisladores)
            {
                Console.WriteLine(legislador.GetDatos());
            }
        }
    }
}
