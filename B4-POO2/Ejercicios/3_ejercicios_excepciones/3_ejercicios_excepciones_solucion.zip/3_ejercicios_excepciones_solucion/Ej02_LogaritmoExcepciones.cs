﻿using System;

namespace Ej02_LogaritmoExcepciones
{
    /* 02. Con el ejercicio anterior, ahora vamos a tratar las excepciones del método logaritmo: en la función que calcula el
     * logaritmo se comprueba si el valor introducido es menor o igual que 0, ya que para estos valores la función logaritmo
     * no está definida. Se pide:
     * 
     * a) Buscar entre las excepciones la más adecuada para lanzar en este caso, que indique que a un método se le ha pasado
     * un argumento ilegal. 
     * 
     * b) Una vez elegida la excepción adecuada, añadir código (en el método logaritmo) para que en el caso de haber introducido
     * un parámetro incorrecto se lance dicha excepción. Probar el programa para comprobar el efecto que tiene el lanzamiento
     * de la excepción. Manejar esta excepción para que sea capturada.
     */

    class Ej02_LogaritmoExcepciones
    {
        static double LogaritmoBase10(double n)
        {
            if (n <= 0)
                throw new ArgumentException($"No se puede calcular el lugaritmos de un número menor o iguala cero.", "n");

            return Math.Log10(n);
        }

        static void Main(string[] args)
        {
            try
            {
                if (args.Length == 1)
                {
                    double valor = double.Parse(args[0]);
                    Console.WriteLine("\nEl logaritmo de {0} en base 10 es: {1}", valor, LogaritmoBase10(valor));
                }
                else
                    Console.WriteLine($"\aERROR: El programa solo admite un argumento.");
            }
            catch (FormatException)
            {
                Console.WriteLine($"\aERROR: Parámetro introducido {args[0]} inválido.");
            }
            catch (Exception e)
            {
                Console.WriteLine($"\aERROR: {e.Message}");
            }
        }
    }
}
