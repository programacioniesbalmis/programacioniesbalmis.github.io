﻿using System;

namespace Ej03_ParametroNoValidoException
{
    /* 
        03. Modifica el programa anterior para crear nuestro propio tipo de excepción derivada de Exception.
        • Esta será lanzada en caso de introducir un valor no válido como parámetro. La
        excepción se llamará ParametroNoValidoException.
        • Le definiremos 2 constructures:
            1. Vacío.
            2. Pasándole el mensaje de error que a su vez pasará a la clase base.
        • Deberemos lanzar esta excepción en lugar de la escogida en el punto anterior.
        • Capturala donde capturabas la anterior.
    */

    class ParametroNoValidoException : Exception
    {
        public ParametroNoValidoException()
        {
            ;
        }

        public ParametroNoValidoException(string message) : base(message)
        {
            ;
        }
    }

    class Ej03_ParametroNoValidoException
    {
        static double LogaritmoBase10(double n)
        {
            if (n <= 0)
                throw new ParametroNoValidoException($"No se puede calcular el lugaritmos de un número menor o iguala cero.");

            return Math.Log10(n);
        }

        static void Main(string[] args)
        {
            try
            {
                if (args.Length == 1)
                {
                    double valor = double.Parse(args[0]);
                    Console.WriteLine("\nEl logaritmo de {0} en base 10 es: {1}", valor, LogaritmoBase10(valor));
                }
                else
                    Console.WriteLine($"\aERROR: El programa solo admite un argumento.");
            }
            catch (FormatException)
            {
                Console.WriteLine($"\aERROR: Parámetro introducido {args[0]} inválido.");
            }
            catch (Exception e)
            {
                Console.WriteLine($"\aERROR: {e.Message}");
            }
        }
    }
}
