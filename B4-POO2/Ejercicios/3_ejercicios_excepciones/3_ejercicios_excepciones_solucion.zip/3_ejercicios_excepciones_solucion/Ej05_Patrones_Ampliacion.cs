using System;
using System.Text.RegularExpressions;

namespace Ejercicio04
{

    static class Patron
    {
        class NotFoundException : Exception
        {
            public NotFoundException(string message) : base(message)
            {
            }
            public NotFoundException(string message, Exception innerException) : base(message, innerException)
            {
            }
        }

        private static Match Obten(string cadenaDeConsumo, string patron)
        {
            Match m = Regex.Match(cadenaDeConsumo, patron);
            if (!m.Success)
                throw new NotFoundException("No se han obtenido coincidencias.");
            return m;
        }

        private static string PatronDNI()
        {
            return @"(?<numero>\d{8})(?<separador>[\s-]?)(?<letra>[A-Za-z])";
        }

        public static string ObtenDNI(string cadenaDeConsumo)
        {
            try
            {
                return Obten(cadenaDeConsumo, PatronDNI()).Value;
            }
            catch(Exception e)
            {
                throw new NotFoundException($"Imposible de obtener un DNI.", e);
            }
        }
        public static string CambiaFormatoDNI(string cadenaDeConsumo)
        {
            try
            {
                Match m = Obten(cadenaDeConsumo, PatronDNI());
                string dniFormateado = $"{m.Groups["numero"].Value}{m.Groups["letra"].Value.ToUpper()}";
                return Regex.Replace(cadenaDeConsumo, PatronDNI(), dniFormateado);
            }
            catch (Exception e)
            {
                throw new NotFoundException($"No se ha podido cambiar el formato del DNI.", e);
            }
        }
    }


    static class Principal
    {
        private static string Menu()
        {
            return
                "1- Introduce texto.\n" +
                "2- Muestra texto.\n" +
                "3- Obten DNI.\n" +
                "4- Cambia formato DNI.\n" +
                "ESC- Salir.\n" +
                "Selecciona una opción\n";
        }

        private static void Main()
        {
            ConsoleKeyInfo opcion;
            string texto = null;

            do
            {
                Console.WriteLine(Menu());
                opcion = Console.ReadKey(true);
                try
                {
                    switch (opcion.Key)
                    {
                        case ConsoleKey.D1:
                        case ConsoleKey.NumPad1:
                            Console.Write("Introduce texto: ");
                            texto = Console.ReadLine();
                            break;
                        case ConsoleKey.D2:
                        case ConsoleKey.NumPad2:
                            Console.WriteLine(texto);
                            break;
                        case ConsoleKey.D3:
                        case ConsoleKey.NumPad3:
                            Console.WriteLine($"El DNI encontrado es {Patron.ObtenDNI(texto)}");
                            break;
                        case ConsoleKey.D4:
                        case ConsoleKey.NumPad4:
                            texto = Patron.CambiaFormatoDNI(texto);
                            Console.WriteLine($"El DNI se ha formateado con éxito.");
                            break;
                        case ConsoleKey.Escape:
                            Console.WriteLine($"Adios");
                            break;
                        default:
                            Console.WriteLine($"Opción o válida");
                            break;

                    }
                }
                catch (Exception e)
                {
                    string mensaje = "";

                    while (e != null)
                    {
                        mensaje += $"{e.Message}\n";
                        e = e.InnerException;
                    }

                    Console.WriteLine(mensaje);
                }
                Console.WriteLine("Pulsa una tecla.");
                Console.ReadKey(true);
                Console.Clear();
            }
            while (opcion.Key != ConsoleKey.Escape);
        }
    }
}