﻿using System;

namespace Ej01_LogaritmoNumero
{
    /* 
    * 01. Crea un programa que tome un número como parámetro en la línea de comandos, y como salida muestra el logaritmo de dicho número.
    * El método main llamara a un método estático al que se le pase el parámetro de entrada y nos calcule el logaritmo, este método
    * devolverá el resultado a la función main.
    *
    * a) Compilar el programa y ejecutadlo de tres formas distintas:
    *      • Sin parámetros
    *      • Poniendo un parámetro no numérico
    *      • Poniendo un parámetro numérico
    * Anotad las excepciones que se lanzan en cada caso(si se lanzan)
    *
    * b) Modificar el código de main para que capture las excepciones producidas y muestre los errores correspondientes en cada caso:
    * Probad de nuevo el programa igual que en el caso anterior comprobando que las excepciones son capturadas y tratadas.
    */

    class Ej01_LogaritmoNumero
    {
        static double LogaritmoBase10(double n)
        {
            return Math.Log10(n);
        }

        static void Main(string[] args)
        {
            try
            {
                double valor = double.Parse(args[0]);
                Console.WriteLine("\nEl logaritmo de {0} en base 10 es: {1}", valor, LogaritmoBase10(valor));
            }
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine($"\aERROR: El programa debe tener un argumento de tipo double.");
            }
            catch (FormatException)
            {
                Console.WriteLine($"\aERROR: Parámetro introducido {args[0]} inválido.");
            }
            catch (InvalidOperationException)
            {
                Console.WriteLine($"\aERROR: No se puede calcular un logaritmo de un número menor o igual a 0.");
            }
            catch (Exception e)
            {
                Console.WriteLine($"\aERROR: {e.Message}");
            }
        }
    }
}
