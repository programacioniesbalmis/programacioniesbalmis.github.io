﻿using System;
using System.Text.RegularExpressions;

namespace Ej04_CuentaBancaria
{
    /* 05. Crea un programa a partir del siguiente UML que permita recoger datos de una cuenta bancaria, crearemos
     * los siguientes métodos y comprobaremos que funcionan. Con respecto al método Reintegro, lanzará una
     * exception SaldoInsuficException, cuando se intente retirar una cantidad y no hay suficiente saldo. Si al
     * llamar al método NumeroCuenta con una cadena, esta no corresponde con una cuenta correcta también se lanzara
     * una excepción NumeroCuentaIncorrecto, para comprobar que el número de cuenta es correcta deberemos primero
     * comprobar que la cadena cumple con el Patrón correspondiente (usando expresiones regulares) y después
     * comprobaremos que los dígitos de control son los correctos. También deberás tratar las excepciones lanzadas.*/

    class SaldoInsuficException : Exception
    {
        public SaldoInsuficException(string mensaje) : base(mensaje)
        {
            ;
        }
    }

    class NumeroCuentaIncorrecto : Exception
    {
        public NumeroCuentaIncorrecto(string mensaje) : base(mensaje)
        {
            ;
        }
    }

    class Cuenta
    {
        private NumeroCuenta numero;
        private string titular;
        private double saldo;

        public Cuenta(string numero, string titular)
        {
            this.numero = new NumeroCuenta(numero);
            this.titular = titular;
            saldo = 0;
        }

        public void Ingreso(double cantidad)
        {
            saldo = saldo + cantidad;
        }

        public void Reintegro(double cantidad)
        {
            if (saldo - cantidad > 0)
                saldo = saldo - cantidad;
            else
                throw new SaldoInsuficException($"Saldo {saldo:C} insuficiente para reintegro de {cantidad:C}.\nEn cuenta: {numero}.");
        }

        public override string ToString()
        {
            string texto = $"Numero de cuenta: {numero}";
            texto += $"Titular: {titular}";
            texto += $"Saldo: {saldo:C}";
            return texto;
        }
    }

    class NumeroCuenta
    {
        private string entidad;
        private string sucursal;
        private string dCEntSuc;
        private string dCNumero;
        private string cuenta;

        public NumeroCuenta(string numero)
        {
            bool cuentaValida = formatoCorrecto(numero);

            if (cuentaValida)
                cuentaValida = dcCorrecto(dCEntSuc, entidad + sucursal, new int[] { 4, 8, 5, 10, 9, 7, 3, 6 });
            if (cuentaValida)
                cuentaValida = dcCorrecto(dCNumero, cuenta, new int[] { 1, 2, 4, 8, 5, 10, 9, 7, 3, 6 });
            if (!cuentaValida)
                throw new NumeroCuentaIncorrecto($"Número de cuenta {numero} incorrecto.");
        }

        static private bool dcCorrecto(string dc, string digitos, int[] ponderaciones)
        {
            int valor = 0;

            for (int i = 0; i < digitos.Length; ++i)
                valor += (int)char.GetNumericValue(digitos, i) * ponderaciones[i];

            int dcAux = 11 - valor % 11;

            dcAux = (dcAux == 10) ? 1 : dcAux;
            dcAux = (dcAux == 11) ? 0 : dcAux;

            if (dcAux == Convert.ToInt32(dc))
                return true;
            else
                return false;
        }

        private bool formatoCorrecto(string numero)
        {
            Regex regex = new Regex(@"(?<Entidad>\d{4})[\s-_](?<Sucursal>\d{4})[\s-_](?<DCEntSuc>\d)(?<DCNumero>\d)[\s-_](?<Numero>\d{10})");
            Match match = regex.Match(numero);
            if (match.Success)
            {
                entidad = match.Groups["Entidad"].Value;
                sucursal = match.Groups["Sucursal"].Value;
                dCEntSuc = match.Groups["DCEntSuc"].Value;
                dCNumero = match.Groups["DCNumero"].Value;
                cuenta = match.Groups["Numero"].Value;
            }

            return match.Success;
        }

        public override string ToString()
        {
            return $"{entidad}-{sucursal}-{dCEntSuc}{dCNumero}-{cuenta}";
        }
    }

    class Ej04_CuentaBancaria
    {
        static void Main(string[] args)
        {
            try
            {
                Cuenta cuenta = new Cuenta("9182-5005-04-0201520831", "David Collado");
				cuenta.Ingreso(15400);
                Console.WriteLine(cuenta);
                cuenta.Reintegro(16000);
                Console.WriteLine(cuenta);
            }
            catch (NumeroCuentaIncorrecto e)
            {
                Console.WriteLine(e);
            }
            catch (SaldoInsuficException e)
            {
                Console.WriteLine(e);
            }
        }
    }
}
