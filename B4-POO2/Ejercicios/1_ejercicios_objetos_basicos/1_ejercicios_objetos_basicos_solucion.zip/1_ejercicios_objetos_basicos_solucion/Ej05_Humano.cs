﻿using System;

namespace Ej04_Humano
{
    /* 04. Crea una clase Humano con los campos, como mínimo, nombre, edad, peso, sexo, 
     * destreza y energía. Los métodos mostrarInformación, SetNombre, SetEdad,...
     * y los constructores que creas necesarios. 
     */

    class Humano
    {
        private string nombre;
        private int edad;
        private float peso;
        private char sexo;
        private int inteligencia;
        private int fuerza;
        private int destreza;
        private int energia;

        public int GetEnergia()
        {
            return energia;
        }

        private void SetEnergia(int value)
        {
            energia = value;
        }

        public int GetDestreza()
        {
            return destreza;
        }

        private void SetDestreza(int value)
        {
            destreza = value;
        }

        public int GetFuerza()
        {
            return fuerza;
        }

        private void SetFuerza(int value)
        {
            fuerza = value;
        }

        public int GetInteligencia()
        {
            return inteligencia;
        }

        private void SetInteligencia(int value)
        {
            inteligencia = value;
        }

        public char GetSexo()
        {
            return sexo;
        }

        private void SetSexo(char value)
        {
            sexo = value;
        }

        public float GetPeso()
        {
            return peso;
        }

        private void SetPeso(float value)
        {
            peso = value;
        }

        public int GetEdad()
        {
            return edad;
        }

        private void SetEdad(int value)
        {
            edad = value;
        }

        public string GetNombre()
        {
            return nombre;
        }

        private void SetNombre(string value)
        {
            nombre = value;
        }

        public Humano(
            string nombre,
            int edad,
            float peso,
            char sexo,
            int inteligencia,
            int fuerza,
            int destreza,
            int energia)
        {
            SetNombre(nombre);
            SetEdad(edad);
            SetPeso(peso);
            SetSexo(sexo);
            SetInteligencia(inteligencia);
            SetFuerza(fuerza);
            SetDestreza(destreza);
            SetEnergia(energia);
        }

        public string Informacion()
        {
            return $"\nNombre {GetNombre()}\nEdad: {GetEdad()}\nPeso: {GetPeso()}\nSexo: {GetInteligencia()}\nInteligencia: {GetFuerza()}\nFuerza: {GetDestreza()}\nDestreza: {GetEnergia()}\nEnergia: {7}";
        }

    }

    class Ej04_Humano
    {
        static void Main(string[] args)
        {
            Humano personaje1 = new Humano("Edgar", 28, 75, 'H', 75, 80, 64, 69);
            //Console.WriteLine(personaje1.Informacion());
            Console.WriteLine("Nombre: " + personaje1.GetNombre());
            Console.WriteLine("Edad: " + personaje1.GetEdad());
            Console.WriteLine("Sexo: " + personaje1.GetSexo());
            Console.WriteLine("Inteligencia: " + personaje1.GetInteligencia());
            Console.WriteLine("Fuerza: " + personaje1.GetFuerza());
            Console.WriteLine("Destreza: " + personaje1.GetDestreza());
            Console.WriteLine("Energia: " + personaje1.GetEnergia());
        }
    }
}
