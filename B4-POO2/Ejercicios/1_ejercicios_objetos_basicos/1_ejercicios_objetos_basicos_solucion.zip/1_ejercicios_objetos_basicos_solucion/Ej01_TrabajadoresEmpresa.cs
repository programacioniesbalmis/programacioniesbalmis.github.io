
using System;


namespace Ej01_TrabajadoresEmpresa
{
    /* A partir del siguiente diagrama de clases, crea las clases necesarias
     * que permitan reflejar los elementos que ves representados en él, y la aplicación para probarlas. 
     * Las categorías de los trabajadores pueden ser: =10, Administrativos=20, JefesDepartamento=40, Gerente=60.
     * Nota: El salario del empleado se calculará a partir de la categoría de trabajo que desempeñe, 
     * las categorías tienen asociadas el incremento en porcentaje que se tiene que hacer al salario base, 
     * que será una constante con el valor de 1200.
     */
    class Empresa
    {
        private readonly string cif;
        private readonly string razonSocial;
        private string direccion;
        private Empleado[] empleados;

        public Empresa(in string razonSocial, in string cif, in Empleado gerente, in string direccion)
        {
            this.cif = cif;
            this.razonSocial = razonSocial;
            this.direccion = direccion;
            SetGerente(gerente);
        }
        public Empresa(Empresa empresa)
        {
            this.cif = empresa.cif;
            this.razonSocial = empresa.razonSocial;
            this.empleados = empresa.empleados;
            this.direccion = empresa.direccion;
        }
        public string NombreGerente()
        {
            return empleados[0].GetNombre();
        }
        public string GetRazonSocial()
        {
            return razonSocial;
        }
        public string GetDireccion()
        {
            return direccion;
        }
        public string GetCif()
        {
            return cif;
        }
        public void SetGerente(Empleado gerente)
        {
            gerente.SetCategoria(Empleado.Categoria.Gerente);
            this.empleados = this.empleados ?? new Empleado[1];
            empleados[0] = new Empleado(gerente);
        }
        public void SetDireccion(string direccion)
        {
            this.direccion = direccion;
        }

        public Empleado[] GetEmpleados()
        {
            return empleados;
        }
        public void Contrata(Empleado empleado, Empleado.Categoria categoria)
        {
            Array.Resize<Empleado>(ref empleados, empleados.Length + 1);
            empleado.SetCategoria(categoria);
            empleados[empleados.Length - 1] = new Empleado(empleado);
        }


        public string DatosEmpresa()
        {
            string mensaje;
            mensaje = $"{GetRazonSocial()}\n" +
                      $"{NombreGerente()}\n" +
                      $"{GetDireccion()}";
            return mensaje;
        }
        public string ACadena()
        {
            string mensaje;
            mensaje = DatosEmpresa() + "\n\n";
            Empleado[] empleados = GetEmpleados();

            foreach (var x in empleados)
            {
                mensaje += "\n" + x.ACadena();
            }
            return mensaje;
        }
    }
    class Empleado
    {

        public enum Categoria { Subalterno = 10, Administrativo = 20, JefesDepartamento = 40, Gerente = 60 }
        private const double BASESALARIO = 1200;
        private readonly string dni;
        private readonly string nombre;
        private readonly int añoNacimento;
        private Categoria categoria;
        public Empleado(in string dni, in string nombre, in int añoNacimento)
        {
            this.dni = dni;
            this.nombre = nombre;
            this.añoNacimento = añoNacimento;

        }

        public Empleado(Empleado empleado)
        {
            this.dni = empleado.dni;
            this.nombre = empleado.nombre;
            this.añoNacimento = empleado.añoNacimento;
            this.categoria=empleado.categoria;
        }
        public string GetNombre() { return nombre; }
        public int GetAñoNacimiento() { return añoNacimento; }
        public string GetDni() { return dni; }
        public void SetCategoria(Categoria categoria)
        {
            this.categoria = categoria;
        }

        public double Salario()
        {
            return (BASESALARIO * (double)categoria) / 100 + BASESALARIO;
        }

        public string ACadena()
        {
            string mensaje;
            mensaje = $"El empleado {nombre} con dni: {dni}" +
                      $" tiene un salario {Salario()} y su categoria es: {categoria}";
            return mensaje;
        }
    }
    class Ej01_TrabajadoresEmpresa
    {
        public static Empleado.Categoria RecogeCategoria(string cadena)
        {
            Empleado.Categoria categoria;
            if (Enum.IsDefined(typeof(Empleado.Categoria), cadena))
                categoria = (Empleado.Categoria)Enum.Parse(typeof(Empleado.Categoria), cadena);
            else categoria = Empleado.Categoria.Subalterno;
            return categoria;
        }

        static void Main(string[] args)
        {
            Empleado Maria = new Empleado("23453456L", "María Soto del Rio", 1995);
            Empleado Juanma = new Empleado("14568712G", "Juanma Perez Ortiz", 1990);
            Empleado Pedro = new Empleado("12346123K", "Pedro Martinez Sancho", 1999);
            Empresa empresa = new Empresa("La Empresa S.L", "C23456732A", Maria, "Calle el Pozo, 34 Bajo");
            empresa.Contrata(Juanma, Empleado.Categoria.Administrativo);
            empresa.Contrata(Pedro, Empleado.Categoria.Administrativo);
            Console.WriteLine(empresa.ACadena());
           
        }
    }
}
