using System;

namespace Ej07_Estrella
{
    /* Utilizando el tipo valor Punto definido en los apuntes, vamos a crear otro tipo valor Estrella formado por un punto, 
     * el caracter * y un color aleatorio de la enumeración ConsoleColor. Seguiremos los siguientes pasos:
     * Deberemos introducir por teclado la cantidad de estrellas a dibujar.
     * Generaremos la posición del Punto y el Color de cada estrella de forma aleatoria.
     * Además almacenaremos los datos en una tabla definida de la siguiente manera Estrella[] estrellas = new Estrella[NumEstrellas];
     * Borraremos la pantalla con el método Clear() de la clase Console.
     * Dibujaremos todo el array de estrellas en cada una de las coordenadas introducidas y con el color generado aleatorio.
     * Nota: para posicionar la estrella en la pantalla usaremos el método de la clase Console void SetCursorPosition(int letf, int top); 
     * que situará el cursor en una coordenada dentro de las 24 filas y 80 columnas que puede tener una consola con origen en 
     * la esquina superior izquierda (para generar los puntos, utilizaremos en Next de la clase Random con el rango entre 24 y 80 ). 
     * Para pintar el color utilizaremos la propiedad, de la clase Console, ForegroundColor.*/
    class Ej07_Estrella
    {
        struct Punto
        {
            readonly public int X;
            readonly public int Y;
            public Punto(int x, int y)
            {
                X = x;
                Y = y;
            }
        }

        struct Estrella
        {
            readonly public Punto Posicion2D;
            public readonly char Simbolo;
            public ConsoleColor Color;
            public Estrella(Random random)
            {

                Posicion2D = new Punto(random.Next(0, Console.WindowWidth), random.Next(0, Console.WindowHeight));
                Color = (ConsoleColor)random.Next(0, 16);
                Simbolo = '*';
            }
        }

        class Program
        {
            static Estrella[] GeneraEstrellas(int numeroEstrellas)
            {
                Estrella[] estrellas = new Estrella[numeroEstrellas];
                Random semilla = new Random();

                for (ushort i = 0; i < estrellas.Length; ++i)
                    estrellas[i] = new Estrella(semilla);

                return estrellas;
            }

            static void MuestraEstrellas(Estrella[] estrellas)
            {
                Console.Clear();
                foreach (var estrella in estrellas)
                {
                    Console.SetCursorPosition(estrella.Posicion2D.X, estrella.Posicion2D.Y);
                    Console.ForegroundColor = estrella.Color;
                    Console.Write(estrella.Simbolo);
                }
            }

            static void Main()
            {
                Console.WriteLine($"Introduce el número de estrellas:");
                int numeroEstrellas = int.Parse(Console.ReadLine());
                Estrella[] estrellas = GeneraEstrellas(numeroEstrellas);
                MuestraEstrellas(estrellas);
                Console.SetCursorPosition(0, Console.WindowHeight - 1);
            }
        }
    }
}

