using System;

namespace Ej06_Baraja
{
    /* Debes definir un tipo valor que represente un Naipe de la baraja Española de 48 cartas.
  * El tipo estará compuesto por dos miembros: un valor y un palo, este último sera de tipo enumerado 
  * con los siguientes valores posibles: Oros, Copas, Bastos, Espada.
  * Crea un método que utilizando el tipo Naipe nos devuelva una baraja con las 48 cartas, 
  * usa una matriz Naipe[,] baraja= new Naipe[4,12] e inicialízala suponiendo que cada fila representa un palo.
  * Crea un método que nos mezcle la baraja para que queden sus cartas desordenadas.
  * Crea un programa que muestre el resultado de la utilización de los métodos anteriores.
  * Nota: Vuelve a repasar los apuntes donde se explica la creación del tipo Valor y sigue las normas que se explican para este tipo.*/
    class Ej06_Baraja
    {
        enum Palo { Espadas, Bastos, Oros, Copas }

        struct Naipe
        {
            public readonly int Valor;
            public readonly Palo Palo;
            public Naipe(int valor, Palo palo)
            {
                Valor = valor;
                Palo = palo;
            }
        }

        static Naipe[,] CreaBaraja()
        {
            Naipe[,] baraja = new Naipe[4, 12];

            for (int palo = 0; palo < baraja.GetLength(0); palo++)
                for (int valor = 0; valor < baraja.GetLength(1); valor++)
                {
                    baraja[palo, valor] = new Naipe(valor + 1, (Palo)palo);
                }
            return baraja;
        }

        static void MuestraBaraja(Naipe[,] baraja)
        {
            int contador = 0;
            foreach (Naipe naipe in baraja)
            {
                Console.Write($"[{naipe.Valor,2},{naipe.Palo.ToString()[0]}] ");
                if (++contador % 12 == 0)
                    Console.Write("\n");
            }
        }

        static void MezclaBaraja(Naipe[,] baraja)
        {
            Naipe intercambio;
            Random seed = new Random();
            int fila, columna, filaIntercambio, columnaIntercambio;

            for (int i = 0; i < baraja.Length; i++)
            {
                fila = seed.Next(0, baraja.GetLength(0));
                columna = seed.Next(0, baraja.GetLength(1));
                intercambio = baraja[fila, columna];
                filaIntercambio = seed.Next(0, baraja.GetLength(0));
                columnaIntercambio = seed.Next(0, baraja.GetLength(1));
                baraja[fila, columna] = baraja[filaIntercambio, columnaIntercambio];
                baraja[filaIntercambio, columnaIntercambio] = intercambio;
            }
        }
        static void Main()
        {
            Naipe[,] baraja = CreaBaraja();
            MuestraBaraja(baraja);
            MezclaBaraja(baraja);
            MuestraBaraja(baraja);
        }
    }
}

