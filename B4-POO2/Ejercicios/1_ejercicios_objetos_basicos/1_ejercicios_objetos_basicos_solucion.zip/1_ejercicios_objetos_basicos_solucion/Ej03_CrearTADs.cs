using System;


namespace Ej05_CrearTADs
{
    /* Crea un proyecto con **los TAD necesarios** para que el siguiente código perteneciente a la Main, 
     * pueda ser ejecutado sin problemas:
     * Compas compas = new Compas();
     * Circulo circulo = compas.DibujaCirulo(3.5f);
     * Rotulador rotulador = Estuche.GetRotuladores()[8]??new Rotulador("Negro");
     * rotulador.Rotula(circulo.Area());
     * Pincel pincel=new Pincel();
     * pincel.SetColor(Color.Verde);
     * pincel.Pinta(circulo.Perimetro());   
     * Nota: Habrá una clase estática con un solo método también estático. La salida por pantalla 
     * del programa podría ser algo como lo siguiente
     */

    class Ej05_CrearTADs
    {
        enum Color { Negro, AzulOscuro, VerdeOscuro, CyanOscuro, RojoOscuro, Magenta, Rojo, Verde, Azul, Cyan, Blanco, Rosa, Morado, Marron, Naranja, Amarillo }

        class Pincel
        {
            private Color color;

            private Color GetColor()
            {
                return color;
            }

            public void SetColor(Color value)
            {
                color = value;
            }

            public void Pinta(float area_cm)
            {
                Console.WriteLine($"Pintada el area de  {area_cm:F2} cm. de color {GetColor()}.");
            }

        }
        class Rotulador
        {
            private readonly Color color;
            public Rotulador(string color)
            {
                if (!Enum.IsDefined(typeof(Color), color))
                    throw new ArgumentException($"Color {color} no válido.");
                this.color = (Color)Enum.Parse(typeof(Color), color);
            }

            private Color GetColor()
            {
                return color;
            }

            public void Rotula(float perimetro_cm)
            {
                Console.WriteLine($"Rotulado el perimetro de  {perimetro_cm:F2} cm. de color {GetColor()}.");
            }
        }
        static class Estuche
        {
            public static Rotulador[] GetRotuladores()
            {
                Rotulador[] rotuladores = new Rotulador[]
                {
                    new Rotulador("Negro"),
                    new Rotulador("Rojo"),
                    new Rotulador("AzulOscuro"),
                    new Rotulador("VerdeOscuro"),
                    new Rotulador("Rosa"),
                    new Rotulador("Marron"),
                    new Rotulador("Blanco"),
                    new Rotulador("Cyan"),
                    new Rotulador("Azul"),
                    new Rotulador("Morado")
                };
                return rotuladores;
            }

        }
        class Circulo
        {
            private readonly float radio;

            public Circulo(float radio)
            {
                this.radio = radio;
            }

            private float GetRadio()
            {
                return radio;
            }

            public float Area()
            {
                return 2 * (float)Math.PI * GetRadio();
            }
            public float Perimetro()
            {
                return (float)(Math.PI * Math.Pow(GetRadio(), 2));
            }
        }
        class Compas
        {
            public Circulo DibujaCirculo(float radio)
            {
                Console.WriteLine($"Dibujado un círculo de rádio {radio}");
                return new Circulo(radio);
            }
        }
        static void Main()
        {
            Compas compas = new Compas();
            Circulo circulo = compas.DibujaCirculo(3.5f);
            Rotulador rotulador = Estuche.GetRotuladores()[new Random().Next(0, Estuche.GetRotuladores().Length)];
            rotulador.Rotula(circulo.Perimetro());
            Pincel pincel = new Pincel();
            pincel.SetColor(Color.Verde);
            pincel.Pinta(circulo.Area());
        }
    }
}