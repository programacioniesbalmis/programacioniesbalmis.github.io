﻿using System;

namespace Ej04_Muebles
{
    /* 3. A partir del siguiente texto:
     * 
     * Una cadena de muebles a nivel nacional tiene tiendas ubicadas por toda la geografía española. Cada una de
     * estas tiendas de muebles almacena información sobre: Sofás, sillas y mesas. De todos ellos es común como mínimo,
     * color(enumeración), peso, dimensiones (estructura), fabricante, y precio. En cambio los sofás incluye información
     * de la tela con el que está tapizado y si es abatible o no, las sillas la longitud del respaldo y las mesas el
     * tipo de madera que está hecho.
     * 
     * Crea una clase mueble que contenga los campos necesarios, Los constructores y los métodos para recoger la
     * información de una instancia de mueble y mostrar esa información. Importante que al recoger los valores de
     * color pertenezcan a la enumeración. */

    class Mueble
    {
        public enum Color
        {
            Blanco, Azul, Verde, Rojo, Rosa, Marron
        }

        private struct Dimensiones
        {
            public int Ancho;
            public int Alto;
            public int Profundidad;

            public Dimensiones(int ancho, int alto, int profundidad)
            {
                Ancho = ancho;
                Alto = alto;
                Profundidad = profundidad;
            }
        }

        private int peso;
        private string fabricante;
        private float precio;
        private Dimensiones dimensiones;
        private Color color;

        public Color GetColor()
        {
            return color;
        }

        private void SetColor(Color value)
        {
            color = value;
        }

        public float GetPrecio()
        {
            return precio;
        }

        public void SetPrecio(float value)
        {
            precio = value;
        }

        public int GetPeso()
        {
            return peso;
        }

        private void SetPeso(int value)
        {
            peso = value;
        }

        public string GetFabricante()
        {
            return fabricante;
        }

        private void SetFabricante(string value)
        {
            fabricante = value;
        }
        public void SetAlto(int alto)
        {
            dimensiones.Alto = alto;
        }

        public int GetAlto()
        {
            return dimensiones.Alto;
        }

        public void SetAncho(int ancho)
        {
            dimensiones.Ancho = ancho;
        }

        public int GetAncho()
        {
            return dimensiones.Ancho;
        }

        public void SetProfundidad(int profundidad)
        {
            dimensiones.Profundidad = profundidad;
        }

        public int GetProfundidad()
        {
            return dimensiones.Alto;
        }

        public Mueble(
            string fabricante,
            int peso,
            int precio,
            int alto,
            int ancho,
            int profundidad,
            Color color)
        {
            SetFabricante(fabricante);
            SetPeso(peso);
            SetPrecio(precio);
            dimensiones = new Dimensiones(ancho, alto, profundidad);
            SetColor(color);
        }

        public static object LeeEnum(Type tipo, string texto, string textoError)
        {
            object valorEnumLeido;
            bool entradaCorrecta;
            do
            {
                string entradaUsuario;

                Console.Write(texto + ", ");
                entradaUsuario = Console.ReadLine();
                entradaCorrecta = Enum.IsDefined(tipo, entradaUsuario);

                if (entradaCorrecta)
                    valorEnumLeido = Enum.Parse(tipo, entradaUsuario);
                else
                {
                    valorEnumLeido = null;

                    Console.Clear();
                    Console.Write(textoError);

                    string[] valoresCorrectos = Enum.GetNames(tipo);
                    Console.WriteLine("solo se aceptan las respuestas:");

                    foreach (string valor in valoresCorrectos)
                        Console.Write(valor + " ");
                    Console.WriteLine("");

                }
            }
            while (entradaCorrecta == false);

            return valorEnumLeido;
        }
    }

    class Ej04_Muebles
    {
        static void Main()
        {
            Mueble m = new Mueble(
                            "IKEA", 
                            12, 58, 210, 250, 140, 
                            (Mueble.Color)Mueble.LeeEnum(typeof(Mueble.Color), 
                            "Introduzca color: ",
                            "\aColor no válido"));

            Console.WriteLine("\n{0}\n{1}\n{2}\n{3}\n{4}\n{5}\n{6}",
                            m.GetFabricante(),
                            m.GetPeso(),
                            m.GetPrecio(),
                            m.GetAlto(),
                            m.GetAncho(),
                            m.GetProfundidad(),
                            m.GetColor());
        }
    }
}
