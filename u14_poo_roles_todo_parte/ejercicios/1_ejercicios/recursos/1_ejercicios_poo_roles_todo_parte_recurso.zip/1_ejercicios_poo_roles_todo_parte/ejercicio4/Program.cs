﻿
using System;
using System.Collections.Generic;
using System.Text;

public class Program
{
    //TODO: Implementa las clases necesarias y la relación entre ellas para resolver el ejercicio

    public static void GestionTelefono()
    {
       Console.WriteLine("Ejercicio 4: Sistema de gestión de teléfonos\n");
        Console.WriteLine("Creando propietario del teléfono...");
        Propietario propietario = new Propietario("12345678A", "Ana García", new DateOnly(1990, 5, 15));
        Console.WriteLine(propietario.ACadena());

        Console.WriteLine("\nCreando compañía telefónica...");
        CompañiaTelefonica compañia = new CompañiaTelefonica("ES001", "Movistar");
        Console.WriteLine($"Compañía: {compañia.Nombre}\nCódigo: {compañia.Codigo}\nId: {compañia.Id}");

        Console.WriteLine("\nCreando teléfono con propietario...");
        string numeroTelefono = "699000111";
        Telefono telefono = new Telefono(numeroTelefono, "iPhone", "15 Pro", new DateOnly(2025, 8, 15), propietario, compañia);
        Console.WriteLine(telefono.ACadena());

        Console.WriteLine("\nAñadiendo contactos al teléfono...");
        Contacto c1 = new Contacto("Luis Pérez", "666111222");
        telefono.AñadeContacto(c1);
        Console.WriteLine($"Contacto añadido: {c1.Nombre} - {c1.Telefono}");
        Contacto c2 = new Contacto("María López", "677333444");
        telefono.AñadeContacto(c2);
        Console.WriteLine($"Contacto añadido: {c2.Nombre} - {c2.Telefono}");
        Contacto c3 = new Contacto("Pedro Ruiz", "688555666");
        telefono.AñadeContacto(c3);
        Console.WriteLine($"Contacto añadido: {c3.Nombre} - {c3.Telefono}");

        Console.WriteLine("\nRegistrando teléfono en la compañía...");
        compañia.RegistraTelefono(telefono);
        Console.WriteLine($"Teléfono registrado en {compañia.Nombre}");
        Console.WriteLine($"Teléfonos registrados en {compañia.Nombre}: {compañia.CantidadTelefonosRegistrados}");

        Console.WriteLine("\n=== ESTADO FINAL DEL SISTEMA ===");
        Console.WriteLine("--- Teléfono ---");
        Console.WriteLine(telefono.ACadena());
        Console.WriteLine("--- Compañía ---");
        Console.WriteLine(compañia.ACadena());

        Console.WriteLine("\n\"Presiona cualquier tecla para salir...");
        Console.ReadKey();
    }

    static void Main(string[] args)
    {
        GestionTelefono();
    }
}
