﻿
using System;
using System.Collections.Generic;
using System.Text;

public class Program
{
    //TODO: Implementa las clases necesarias y la relación entre ellas para resolver el ejercicio

    public static void GestionTelefono()
    {
        Console.WriteLine("Ejercicio 4: Sistema de gestión de teléfonos\n");
        //TODO: Implementar la lógica de gestión de teléfonos y contactos

        Console.WriteLine("\n\"Presiona cualquier tecla para salir...");
        Console.ReadKey();
    }

    static void Main(string[] args)
    {
        GestionTelefono();
    }
}
