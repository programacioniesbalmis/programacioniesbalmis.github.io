﻿

using System;
using System.Collections.Generic;

//TODO: Implementa las clases necesarias y la relación entre ellas para resolver el ejercicio

public class Program
{
	public static void GestionMatricula()
	{
		Console.WriteLine("Ejercicio 2: Agregación Curso-Estudiantes (1 a muchos)\n");
		//TODO: Implementar la lógica de gestión de cursos y estudiantes

		Console.WriteLine("\nPresiona cualquier tecla para salir...");
		Console.ReadKey();
	}

	static void Main(string[] args)
	{
		GestionMatricula();
	}
}
