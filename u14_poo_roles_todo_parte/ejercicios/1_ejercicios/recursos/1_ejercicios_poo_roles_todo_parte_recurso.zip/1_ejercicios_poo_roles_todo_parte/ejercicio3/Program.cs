﻿
using System;

//TODO: Implementa las clases necesarias y la relación entre ellas para resolver el ejercicio
public class Program
{
	static void Main(string[] args)
	{
		Console.WriteLine("Ejercicio 3: Sistema de coordenadas con records\n");
		//TODO: Implementar la lógica de gestión de coordenadas
		Console.WriteLine("Presiona cualquier tecla para salir...");
		Console.ReadKey();
	}
}
