﻿
using System;

//TODO: Implementa las clases necesarias y la relación entre ellas para resolver el ejercicio

public class Program
{
	public static void GestionVehiculo()
	{
		Console.WriteLine("Ejercicio 1: Composición Vehículo-Motor\n");
		//TODO: Implementar la lógica de gestión de vehículos y motores

		Console.WriteLine("\nPresiona cualquier tecla para salir...");
		Console.ReadKey();
	}

	static void Main(string[] args)
	{
		GestionVehiculo();
	}
}
