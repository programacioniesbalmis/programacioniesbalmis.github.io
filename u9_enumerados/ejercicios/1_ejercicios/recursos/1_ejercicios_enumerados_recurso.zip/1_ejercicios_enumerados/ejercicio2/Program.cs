using System;

namespace Ejercicio2
{

    public class Program
    {
        //TODO: Implementar los métodos necesarios
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 2: Control de abono de transporte urbano");
            //TODO: Implementar la lógica necesaria
            Console.WriteLine("¡Gracias por usar nuestro servicio!");
            Console.ReadLine();
        }
    }
}
