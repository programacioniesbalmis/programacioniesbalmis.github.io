using System;

namespace Ejercicio5
{

    public class Program
    {
        //TODO: Implementar los métodos necesarios

        static void Main(string[] args)
        {
            //El método Main se os da resuelto, cuando hayas realizado el resto de métodos
            //puedes descomentar las líneas siguientes
            Console.WriteLine("Ejercicio 5: Sistema de turnos de trabajo con flags");
            Console.WriteLine();
            Console.WriteLine("=== GESTIÓN DE TURNOS ===");

            string nombreEmpleado = "Juan Pérez";
            Console.WriteLine($"Empleado: {nombreEmpleado}");
            Console.WriteLine();

            Console.WriteLine("Turnos disponibles:");
            Console.WriteLine("M = Mañana, T = Tarde, N = Noche, F = FinDeSemana");
            Console.WriteLine();

            Console.Write("Introduce turnos asignados (ej: MTF): ");
            string inputTurnos = Console.ReadLine() ?? "";

            //TurnoTrabajo turnosEmpleado = ParseaTurnos(inputTurnos);

            Console.WriteLine("=== INFORMACIÓN DEL EMPLEADO ===");

            //MuestraInformacion(nombreEmpleado, turnosEmpleado);
            Console.WriteLine();
            string operacion;
            do
            {
                Console.WriteLine("Operaciones disponibles:");
                Console.WriteLine("A = Añadir turno, Q = Quitar turno, M = Mostrar info, S = Salir");
                Console.WriteLine();
                Console.Write("Operación: ");
                operacion = Console.ReadLine()?.ToUpper() ?? "";

                switch (operacion)
                {
                    case "A":
                        Console.Write("Turno a añadir (M/T/N/F): ");
                        char turnoAñadir = Console.ReadKey().KeyChar;
                        Console.WriteLine();

                        /*TurnoTrabajo nuevoTurno = CaracterATurno(turnoAñadir);
                        if (nuevoTurno != TurnoTrabajo.Ninguno)
                        {
                            turnosEmpleado = AñadeTurno(turnosEmpleado, nuevoTurno);
                            Console.WriteLine($"Turno {nuevoTurno} añadido.");
                        }*/
                        break;

                    case "Q":
                        Console.Write("Turno a quitar (M/T/N/F): ");
                        char turnoQuitar = Console.ReadKey().KeyChar;
                        Console.WriteLine();

                        /*  TurnoTrabajo turnoAEliminar = CaracterATurno(turnoQuitar);
                          if (turnoAEliminar != TurnoTrabajo.Ninguno)
                          {
                              turnosEmpleado = QuitaTurno(turnosEmpleado, turnoAEliminar);
                              Console.WriteLine($"Turno {turnoAEliminar} quitado.");
                          }*/
                        break;

                    case "M":
                        Console.WriteLine("=== INFORMACIÓN DEL EMPLEADO ===");
                        //  MuestraInformacion(nombreEmpleado, turnosEmpleado);
                        break;

                    case "S":
                        Console.WriteLine("¡Hasta luego!");
                        break;

                    default:
                        Console.WriteLine("Operación no válida.");
                        break;
                }

                Console.WriteLine();

            } while (operacion != "S");
            Console.ReadLine();
        }
    }
}
