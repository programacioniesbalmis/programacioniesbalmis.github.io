using System;

namespace Ejercicio4
{

    public class Program
    {
        //TODO: Implementar los métodos necesarios

        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 4: Dieta semanal vegetariana");
            Console.WriteLine();

            //TODO: Implementar la lógica necesaria
            Console.WriteLine("¡Que disfrutes de tu dieta vegetariana!");

            Console.ReadLine();
        }
    }
}
