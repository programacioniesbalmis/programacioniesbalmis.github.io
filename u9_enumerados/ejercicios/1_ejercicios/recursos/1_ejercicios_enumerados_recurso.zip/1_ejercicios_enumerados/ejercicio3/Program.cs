using System;

namespace Ejercicio3
{

    public class Program
    {
        //TODO: Implementar los métodos necesarios

        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 3: Gestión de estados de pedidos");

            //TODO: Implementar la lógica necesaria

            Console.WriteLine("¡Gracias por usar nuestro servicio!");
            Console.ReadLine();
        }
    }
}
