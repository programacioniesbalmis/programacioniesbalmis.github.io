using System;

namespace Ejercicio1
{


    public class Program
    {
        //TODO: Implementar los métodos necesarios


        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 1: Sistema de gestión de niveles de dificultad");
            //TODO: Implementar la lógica necesaria

            Console.WriteLine("¡Gracias por jugar!");
            Console.ReadLine();
        }
    }
}