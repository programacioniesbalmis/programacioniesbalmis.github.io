﻿using System;

namespace Ejercicio3
{
    public class Program
    {
        public static Uri[] CreaUris(int urisCount)
        {
            Uri[] uris = new Uri[urisCount];
            string[] ejemplos = {
                "https://www.google.com/search?q=csharp",
                "ftp://files.example.com:21/documents/file.txt",
                "mailto:info@example.com",
                "invalid-url-format"
            };

            for (int i = 0; i < urisCount; i++)
            {
                Console.Write($"Introduce URI {i + 1}: ");
                string entrada = Console.ReadLine() ?? ejemplos[i];

                if (string.IsNullOrEmpty(entrada))
                {
                    entrada = ejemplos[i];
                }

                bool esValida = Uri.TryCreate(entrada, UriKind.Absolute, out Uri? uri);
                Console.WriteLine($"¿Es una URI válida? {esValida}");

                if (esValida && uri != null)
                {
                    uris[i] = uri;
                }
                else
                {
                    Console.WriteLine("URI inválida detectada, se creará URI por defecto.");
                    uris[i] = new Uri("http://localhost");
                }
                Console.WriteLine();
            }

            return uris;
        }

        public static void MuestraInformacion(Uri uri)
        {
            Console.WriteLine($"URI completa: {uri}");
            Console.WriteLine($"Esquema: {uri.Scheme}");
            Console.WriteLine($"Host: {uri.Host}");
            Console.WriteLine($"Puerto: {uri.Port}" + (uri.IsDefaultPort ? " (puerto por defecto " + uri.Scheme.ToUpper() + ")" : ""));
            Console.WriteLine($"Ruta: {uri.AbsolutePath}");
            Console.WriteLine($"Query: {uri.Query}");
            Console.WriteLine($"¿Es archivo?: {uri.IsFile}");
            Console.WriteLine($"¿Es UNC?: {uri.IsUnc}");
            Console.WriteLine($"¿Es absoluta?: {uri.IsAbsoluteUri}");
        }

        public static bool ComparaUris(Uri uri1, Uri uri2)
        {
            return uri1.Host == uri2.Host &&
                   uri1.Scheme == uri2.Scheme &&
                   uri1.Equals(uri2);
        }


        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 3: Sistema de gestión de URIs (TAD de la BCL)");
            Console.WriteLine("Usando la clase Uri de System");
            Console.WriteLine();
            Console.WriteLine("=== CREACIÓN DE URIs Y ANÁLISIS ===");

            Uri[] uris = CreaUris(4);

            // Mostrar información de cada URI válida
            for (int i = 0; i < uris.Length; i++)
            {
                if (uris[i] != null)
                {
                    MuestraInformacion(uris[i]);
                    Console.WriteLine();
                }
            }

            Console.WriteLine("=== COMPARACIONES ===");

            if (uris[0] != null && uris[1] != null)
            {
                Console.Write($"Comparando {uris[0].OriginalString} y {uris[1].OriginalString} ");
                Console.WriteLine(ComparaUris(uris[0], uris[1]) ? "son iguales." : "Son diferentes.");
            }
            if (uris[2] != null && uris[2] != null)
            {
                Console.Write($"Comparando {uris[2].OriginalString} y {uris[2].OriginalString} ");
                Console.WriteLine(ComparaUris(uris[2], uris[2]) ? "son iguales." : "Son diferentes.");
            }
            Console.ReadLine();
        }
    }
}

