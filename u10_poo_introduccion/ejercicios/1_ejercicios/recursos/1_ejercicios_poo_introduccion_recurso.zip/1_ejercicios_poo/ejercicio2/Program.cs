﻿using System;

namespace Ejercicio2
{
    // Clase contenedor con métodos estáticos
    public static class CalculadoraEstatica
    {
        public static double Suma(double a, double b)
        {
            return a + b;
        }

        public static double Resta(double a, double b)
        {
            return a - b;
        }

        public static double Multiplica(double a, double b)
        {
            return a * b;
        }

        public static double Divide(double a, double b)
        {
            return a / b;
        }
    }

    // Clase TAD (permite crear objetos)
    public class CalculadoraTAD
    {
        public double Valor1 { get; set; }
        public double Valor2 { get; set; }

        public CalculadoraTAD(double valor1, double valor2)
        {
            Valor1 = valor1;
            Valor2 = valor2;
        }

        public double Suma()
        {
            return Valor1 + Valor2;
        }

        public double Resta()
        {
            return Valor1 - Valor2;
        }

        public double Multiplica()
        {
            return Valor1 * Valor2;
        }

        public double Divide()
        {
            return Valor1 / Valor2;
        }

        public void CambiaValores(double nuevoValor1, double nuevoValor2)
        {
            Valor1 = nuevoValor1;
            Valor2 = nuevoValor2;
        }

        public void MuestraEstado()
        {
            Console.WriteLine($"Valor1={Valor1}, Valor2={Valor2}");
        }
    }

    public class Program
    {
        public static double PideNumero(string mensaje)
        {
            double numero = 0.0;
            bool esValido = false;

            while (!esValido)
            {
                Console.Write(mensaje);
                string entrada = Console.ReadLine() ?? "";
                esValido = double.TryParse(entrada, out numero);

                if (!esValido)
                {
                    Console.WriteLine("Por favor, introduce un número válido.");
                }
            }

            return numero;
        }

        public static void DemuestraCalculadoraEstatica(double valor1, double valor2)
        {
            Console.WriteLine("Resultados usando CalculadoraEstatica:");
            Console.WriteLine($"Suma: {CalculadoraEstatica.Suma(valor1, valor2)}");
            Console.WriteLine($"Resta: {CalculadoraEstatica.Resta(valor1, valor2)}");
            Console.WriteLine($"Multiplicación: {CalculadoraEstatica.Multiplica(valor1, valor2)}");
            Console.WriteLine($"División: {CalculadoraEstatica.Divide(valor1, valor2):F2}");
        }

        public static void DemuestraCalculadoraTAD(double valor1, double valor2)
        {
            Console.WriteLine("Creando calculadora TAD con valores iniciales...");
            Console.WriteLine();

            // Crear primera calculadora
            CalculadoraTAD calc1 = new CalculadoraTAD(valor1, valor2);
            Console.Write("Calculadora 1: ");
            calc1.MuestraEstado();
            Console.WriteLine($"Suma: {calc1.Suma()}");
            Console.WriteLine($"Resta: {calc1.Resta()}");
            Console.WriteLine($"Multiplicación: {calc1.Multiplica()}");
            Console.WriteLine($"División: {calc1.Divide():F2}");

            Console.WriteLine();
            Console.WriteLine("Creando segunda calculadora...");
            CalculadoraTAD calc2 = new CalculadoraTAD(10.0, 5.0);
            Console.Write("Calculadora 2: ");
            calc2.MuestraEstado();

            Console.WriteLine();
            Console.WriteLine("Modificando valores de calculadora 1...");
            calc1.CambiaValores(20.0, 3.0);
            Console.Write("Calculadora 1 modificada: ");
            calc1.MuestraEstado();
            Console.WriteLine($"Nueva suma: {calc1.Suma()}");

            Console.WriteLine();
            Console.WriteLine($"¿Las calculadoras son el mismo objeto? {ReferenceEquals(calc1, calc2)}");
            Console.WriteLine($"¿Las calculadoras tienen los mismos valores? {calc1.Valor1 == calc2.Valor1 && calc1.Valor2 == calc2.Valor2}");

            Console.WriteLine();
            Console.WriteLine("Estado final:");
            Console.Write("Calculadora 1: ");
            calc1.MuestraEstado();
            Console.Write("Calculadora 2: ");
            calc2.MuestraEstado();
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 2: Calculadora matemática (Clase contenedor vs TAD)");
            Console.WriteLine();

            // Demostrar clase estática
            Console.WriteLine("--- CLASE CONTENEDOR (Métodos estáticos) ---");

            double valor1 = PideNumero("Introduce primer número para TAD: ");
            double valor2 = PideNumero("Introduce segundo número para TAD: ");
            Console.WriteLine();
            DemuestraCalculadoraEstatica(valor1, valor2);

            // Obtener los mismos valores para la demostración TAD
            Console.WriteLine();
            Console.WriteLine("--- CLASE TAD (Objetos) ---");

            valor1 = PideNumero("Introduce primer número para TAD: ");
            valor2 = PideNumero("Introduce segundo número para TAD: ");

            // Demostrar clase TAD
            DemuestraCalculadoraTAD(valor1, valor2);

            Console.WriteLine("¡Hasta la próxima!");
            Console.ReadKey();
        }
    }
}
