namespace Biblioteca
{
    public class LibroEntity
    {
        public int Id { get; }
        public string Titulo { get; set; }
        public string Autor { get; set; }

        public LibroEntity(int id, string titulo, string autor)
        {
            Id = id;
            Titulo = titulo;
            Autor = autor;
        }
    }
}